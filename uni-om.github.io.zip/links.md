---
layout: page
title: Links
---

[Tchái Txana Ixã] 50 segundos

[Ailton Krenak]   59 segundos

[Swami SarvaPryAnanda] 35 segundos

[Sri Mahant Naga Baba Rampuri Ji] 4:50 minutos

[Nhanderuí Chaa´Pe´Y] 9:55 minutos

[Ian Carrol] 42 segundos

[Donald Hoffman] 48 segundos

[Taisha Abelar] 48:43 minutos

[Nyei Murez] 2:34 horas



[Tchái Txana Ixã]:https://www.youtube.com/watch?v=xvwEU7d-8LU

[Ailton Krenak]:https://www.youtube.com/shorts/1FALODzvyVo

[Swami SarvaPryAnanda]:https://www.youtube.com/shorts/sol2nhhVNts

[Sri Mahant Naga Baba Rampuri Ji]:https://www.youtube.com/watch?v=IFM-4slItSc

[Nhanderuí Chaa´Pe´Y]:https://www.youtube.com/watch?v=UakzF88KqiM

[Ian Carrol]:https://www.youtube.com/shorts/Ljbr9xRNrF8

[Donald Hoffman]:https://www.youtube.com/shorts/vddcsnSz6nU

[Taisha Abelar]:https://www.youtube.com/watch?v=aej8oHv9F74

[Nyei Murez]:https://www.youtube.com/watch?v=M4bFRjVzdD0

{% comment %}
entrevista txana Ixa
[Tchái Txana Ixã]:https://www.youtube.com/watch?v=LCO1GyQUJzg

Entrevista Krenak
[Ailton Krenak]:https://www.youtube.com/watch?v=GIz0hRuRXqc
{% endcomment %}
