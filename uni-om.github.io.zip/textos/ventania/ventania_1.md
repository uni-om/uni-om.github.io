---
layout: texto
tags: [pérola]
texto_number: 1
category: ventania
---
Date:Seg Abr 3, 2000 12:28 am
Texto:1
Assunto: Ventania

Primeiro foi a brisa. 
Leve pela tarde, errante, como quem tem em si foco e objetivo, trilhando os caminhos apenas pelo prazer de trilhar. 
Brisa leve, fresca, era o fim de tarde que nela cavalgava, chegando com seu poder e revelando que os quatro cantos do mundo, os quatro elementos, os quatro totens que guardam e sustentam esse céu , tem em cada ser humano, em cada mulher e homem vivente uma expressão de seus próprios poderes. 
A grande aranha dourada teceu sua teia da vida de tal forma que tudo se interliga , tudo está inter relacionado, somos uma teia viva e dinâmica de eventos, há algo que anima tudo isso, chamamos , sem entender do que falamos, essa força animadora de VIDA. 
A brisa se intensifica , deixando aquela agradável sensação que temos quando o perfume da mata profunda, que tal brisa nos traz, entra com a respiração, magia, respiração, em nós. 
Quando inspiramos partilhamos do sentido do mundo, nos enchemos com o AR, o vento é seu cavalo, em seu dorso cavalga o AR com seu poder , com sua magia. 
Inspire e esteja aí, onde o ar entrou, dentro de si mesmo. 
Sim em si mesmo está a fonte, a magia, tudo que vc pode precisar . 
SEgure o ar, sinta seu corpo absorvendo o ar, , ele entrando nos pulmões, entrando na corrente sangüínea , fluindo por todo seu corpo. 
Expire e deixe o ar ir embora, fique vazio. 
Vazio, pare um pouco, fique sem ar, veja quanto tempo aguenta, treine, não seja só um leitor. 
A magia do ARco ïris, de Bifrost não convidou apenas tua mente lendo essa mensagem. 
Sua mente vai embora um dia , vc precisa de algo mais amplo. 
Precisa existir em si. EI ! ( imagine um grito! ) Lembre de você! 
A brisa sopra mais forte e agora é vento. 
O vento é intenso, a brisa da tarde se tornou um vento forte que cada vez mais intenso sopra na mata. 
Folhas dançam, sol brilha forte, os rios correm, as pedras continuam seu caminho, lento, sábio. 
O vento é ainda mais forte é VENTANIA ! 
Vento forte em uma trilha de poder, uma clareira com sua fogueira ao redor da qual aqueles e aquelas que trilham o caminho guerreiro do Xamanismo possam se encontrar. 
Com foco plenitude, fazendo de cada linha escrita um exercício de implacabilidade, astúcia, paciência, gentileza. 
Com sobriedade partilhar os profundos questionamentos que tomam nosso ser quando nos vislumbramos mistérios entre mistérios. 
Quando de fato nos tornamos cientes do que somos e do que podemos ser. 
quando percebemos nossa efemeridade, efemeridades que incidem neste plano da realidade para um brilho rápido, que em extensão é tão curto mas que pode ganhar uma intensidade inenarrável. 
Intensidade, está é a chave da diverença entre a Brisa que soprava à tarde e a VENTANIA . 
Quando cai a tempestade e tem VENTANIA , o caçador raio, seu irmão trovão, irmã mais velha chuva, jogam um jogo de poder. 
A tempestade apaga o fogo mas o Raio continua firme. 
E é ele que pode cair novamente na Terra para reascender o fogo que foi apagado, o fogo do conselho onde antes trocávamos nosso saber. 
Raio, Fohática força. 
Por bites, por combinações de 0 e 1, de Silêncio e Existência nos comunicamos na dimensão virtual. 
Nossa casa não tinha teto, hoje não tem paredes. 
Aqueles que ainda voam e conhecem o segredo de se deslocar entre os mundos saberão se encontrar. 
Os que sabem que a era da Máscara de Jade se foi. Assim como tudo que teve começo teve seu fim. 
Antes o Fogo, um dos níveis de Kundala era nosso elo de contato. 
Agora Fohat, eletricidade nos põem em sintonia. 
Atentem para essa peculiaridade dessa nova forma de contato, ela é Fohática. 
Canalizamos o Raio , para que o Fogo se acenda novamente. 
Para que os Quatro Totens sejam de novo plenos em seu poder. 
A lista está aberta para os que desejam restaurar Bifrost , para que os Deuses e Deusas voltem a viver entre nós. 
Quiçá descubramos que somos nós mesmos tais divindades e deixemos a vida de escravos e robos. 
Liberdade é o que buscamos, no mais profundo e pleno sentido deste termo. 
Um sentido que só é compreendido a quem já tráz essa chama em seu peito. Que já tem esse brilho em seus olhos. 
Por isso o nosso toque de tambor tem um tom e embora todos sejam bem vindos há uma nação a quem esta lista é dirigida, para ela foi criada e em seu benefício pretende agir. 
A nação Arco Íris, cumprindo antiga profecia das culturas nativas: 
"Quando o rio e o ar estiverem sujos, quando o ser humano houver se perdido completamente da linha da vida , quando os animais estiverem ameaçados, as ancestrais árvoras cruelmenet abatidas,quando a doença e a tristeza estiverem dizimando o povo vermelho virá uma nova nação, uma nova tribo. 
Serão em grande número, surgiram de onde não se espera. 
Virão em muitas montarias, sua magia diferente, terão artes que desafiarão a compreensão. 
Serão de muitas cores, por isto essa Tribo será conhecida como TRibo do Arco Íris, eles virão quando o fim parecer certo, eles virão e curarão a Terra." 
Uma lista, uma térmica ascendente onde os urubus possamnos ensinar a ir mais e mais ao alto em nosso vôo, em nossa Orubós. 
Boas vindas! 
Que os quatro ventos do mundo se unam aos quatro ventos cibernéticos. 
Convido a soltarem sua pipas virtuais , para que os ventos com elas brinquem. 
Que a Ventania seja sempre forte em seu caminho apoiando seu vôo, rumo a seus próprios e auto-definidos objetivos.