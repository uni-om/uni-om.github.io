---
layout: texto
tags: [mapa]
texto_number: 101
category: ventania
---
Date:Dom Fev 17, 2002 4:59 pm
Texto:101
Assunto: Re: [terramistica] Tristeza e Poder Pessoal
Mensagem:1761

ALoha lista 
Aloha Lanceloth 
ESta relação de tristeza com poder pessoal é interessante, diria que beira a dialética, tanto o poder pessoal sendo perdido gera a tristeza como a tristeza sendo mantida como postura de vida gera a perda do poder pessoal. 
Uma bruxa que aprendi muito dizia que temos uma "atmosfera psquíca" que são "os ventos que evocamos" com nossos estados mentais. 
Assim, com nossas palavras e atitudes , os ventos que evocamos criam um estado de ser a nossa volta, que pode ser equilibrado ou desequilibrado, harmônico ou confuso, depende de nós. 
Quem só se fixa em coisas densas, pesadas, no passado, acaba vivendo com rancores, com coisas mal resolvidas e assim está sempre pesado, atrasado, deixando passar o aqui e agora. 
Da mesma forma quem se liga só num futuro, na ansiedade do que virá, acaba vivendo com medo e no susto, sempre temendo algo que nunca vai chegar, sempre agindo fora de sincronia e não resolvendo o aqui e agora. 
A tristeza me parece um dos caprichos que temos para não agir, para justificar a preguiça do agir. 
EStou triste, estou down e pronto, não ajo, apenas fico morgando deixando o mundo nos atropelar. 
Eu partilho da visão do xamanismo Tolteca, o que gera o sentimento de tristeza, de incompletude no ser humano é que ele perdeu seu elo de conexão com a Terra , um elo que não é simples de ser recuperado, pois toda a educação tradicional nos afasta mais dessa ligação efetiva com a Terra enquanto ser. 
Perdemos o elo com nossa planta de poder, com nosssa pedra de poder, com nosso animal de poder , perdemos o elo principal que é o elo que temos com a TERRA pois somos célula, parte do organismo vivo e consciente que é a TERRA. 
E a maior parte das pessoas tenta encontrar essa completude em outras pessoas, em relacionamentos e isto é terrível, pois por quantas vezes pessoas que realmente tem a ver se encontram e se completam em tantos aspectos, mas quando tentam realizar na outra esta completude não conseguem, pois o elo com a Terra nao pode ser " mais ou menos" resolvido, então se separam na ilusao que "outra pessoa " vai realizar tal completude, quando a esfera de açao de tal completude é outra. 
Quando recuperamos este elo com a Terra nos invade uma sensaçÃo de tal completude, impossível de ser descrita em palavras. 
A vida fica plena, felicidade é uma pálida palavra para indicar o que sentimos. 
NÃo consigo compreender a tristeza na vida de um (a) guerreiro, não dá, quando agimos tendo cada ato como final, quando sentimos a Terra como o ser vivo, não apenas intelectualmente, mas realmente estamos conectados a ELa, a energia que isto gera é pura alegria, pura completude. 
Um (a) guerreiro (a) encara tudo como desafio, então onde ter tristeza? 
A humanidade adora se ferir com o 'punhal metafórico" que D. Juan cita, as pessoas se dilaceram com este punhal e se julgam tristes, sangrando e partilham desse capricho que é um gasto tremendo de energia. 
Em relacionamentos emocionais então nem se fala, as pessoas adoram sofrer, criar problemas, estes dias ouvi um comentário lapidar de uma pessoa : "tá tudo muito bom nessa relação que to vivendo, alguma coisa não tá certa " risos. 
Considero a tristeza um capricho tremendo, num mundo maravilhoso e assombroso como esse, onde somos mistérios rodeados de mistérios, tristeza me parece um estado de espirito muito caprichoso, que gasta uma energia tremenda e não leva a nada. 
AGora há um outro sentimento que toca os navegantes do infinito. 
A primeira vez que li algo sobre ele tinha uns `14 anos, fazia parte de um grupo templário e estava fuçando na biblioteca que eles tinham quando caiu em minhas mãos um livro chamado "Livro de Mirdad" , não sei se alguém conhece, nunca mais vi o livro fora dali, mas o fato é que o livro falava da "grande nostalgia" que toca os que buscam os mistérios e que uma vez tocados pela grande nostalgia não sossegavamos mais, sabiamos que havia algo além dos véus e a busca se tornava nossa meta. 
Creio que isso é uma sensação comum a nós que navegamos pela Eternidade, quando sentimos a imensidão da REalidade e o nada que somos, D. Juan alerta sobre isso, como de tempos em tempos temos estes momentos de melancolia quando o nosso ser total percebe sua impermanência frente a Totalidade. 
Esta "melancolia" não é acabrunhante, é um arrepio, que vem da eternidade, nos sacode pelo tutano dos ossos e nos deixa perplexos de nossa ousadia, nós que nada somos , ousarmos encarar alegre e voluntariamente a vastidÃo solitária da Eternidade