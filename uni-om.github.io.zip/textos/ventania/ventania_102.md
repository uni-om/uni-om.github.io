---
layout: texto
tags: [pérola]
texto_number: 102
category: ventania
---
Date:Qua Fev 20, 2002 9:09 pm
Texto:102
Assunto: Re: [ventania] Humano-nagual
Mensagem:1777

Aloha Lista 
Aloha Tekunse 
Aloha Lanceloth 
Gostaria de fazer algumas colocações dentro do contexto do Xamanismo Tolteca 
O termo nagual é usado em dois contextos. 
Nagual como oposição/ complementar ao tonal, para designar um outro reino da percepção. 
O tonal abrange tudo que temos como conhecido, tudo que temos como mensurável, tudo que é abrangível pela mente discursiva. 
O Nagual está no reino da segunda atenção , no reino do "segundo círculo do poder". 
Em um certo momento D. Juan Matus chega a dizer que o conhecimento que transmite a CC poderia se chamar "nagualismo" , mas isto tornaria mais confuso algo que já era obscuro por si. 
Há outro sentido para o termo nagual, um nagual é um homem ou uma mulher duplicados. 
Ou seja, ao invés de terem a divisão clássica, comum, de dois lados, tem quatro, os lados esquerdo e direito que compõe um ser humano são subdivididos nestas pessoas o que lhes dá uma energia tremenda. 
ALgo muito importante: um(a) xamã, um(a) pajé, um(a) shabono, um feiticeiro de uma tribo não é necessariamente um nagual. Raramente o é. 
No grupo de D. Juan Matus , Vicente MEdrano, Silvio Manuel, Genaro Flores, Juan Tuma , Emilito e todas as mulheres eram feiticeiros(as) poderosos, xamãs potentes, mestres e mestras em suas áreas de magia e poder mas não eram naguais, nagual era apenas D. Juan Matus. Um nagual é um líder e um guia pela condição de sua energia única, pela condição de ser duplicado. 
É muito raro, muito raro mesmo encontrar um ser humano duplicado, o próprio D. Juan MAtus insiste nisso, os seres humanos duplicados em virtude de sua própria condição são arredios, dissimulados, furtivos. 
NÃo é necessário ser um duplicado para trilhar o caminho da magia, do xamanismo. 
Outra coisa importante, o ciclo dos novos videntes toltecas se encerra com CArlos Castañeda e seu grupo, eles fecharam este ciclo, hoje o "regulamento" é outro, isto é um detalhe muito sério que tenho visto ser olvidado por algumas pessoas que tentam imitar a forma sem entender o conteúdo e ficam procurando reproduzir as palavras dos livros do novo nagual. 
ESpecialmente o regulamento publicado em "O presente da águia" fico vendo pessoas tentarem formar grupos dentro desse regulamento, imitando o que ali está, mas este ciclo se refere ao ciclo que se encerra com CC, um ciclo que já não tem mais sentido para nossa era, o mito hoje é outro. 
Carlos Castañeda avisou em seus seminários e nas várias palestras que deu: com ele o ciclo dos videntes da linhagem que herdara se fechava, ele poderia ter escolhido simplesmente fechar a porta quando fosse embora, mas seu espirito impecável nos premiou com este conhecimento ímpar que é a tradição tolteca, que na mesmice do esoterismo que grassa por aí se destaca como algo realmente novo e valoroso. 
NÃo podemos tentar "imitar" o que Carlos Castañeda viveu, isso foi para ele, cada um tem um caminho único e singular. 
O que existe hoje é a tradição dos "novíssimos videntes" os herdeiros do intento do novo nagual e seu grupo, algo que devemos tanto a Carlos Castañeda como ao sonhar da/o Desafiante da Morte , o "Inquilino" que sonhou esta possibilidade de revelar às pessoas o ancestral conhecimento que ela/e guardou por milhares de anos até nossos dias, esperando um nagual com a conformação energética adequada para a realização dessa tarefa monumental que foi trazer o mito tolteca, o Sonhar ancestral à realidade de nosso cotidiano. 
Creio que é importante chamar a atenção para esses pontos para uma correta compreensão dos paradigmas Toltecas, que são muito singulares.