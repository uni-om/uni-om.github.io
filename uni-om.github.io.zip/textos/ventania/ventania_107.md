---
layout: texto
tags: [pérola, prática, mapa]
texto_number: 107
category: ventania
---
Date:Ter Fev 26, 2002 8:55 am
Texto:107
Assunto: Re: [ventania] Re: Filosofia Esotérica
Mensagem:1802

Aloha Retawe, 
Bem vindo de volta a fogueira virtual. 

Crises são comuns aos que desafiam o infinito, D. Juan Matus sempre alertava que quando contemplamos a Eternidade e nosso corpo toma ciência do nada que somos, efêmeros, frente a avassaladora vastidão da Eternidade o ser em nós que vai morrer entra em parafuso mesmo, cabe a nós administrar essas crises e como Fênix , renascermos mais fortes e plenos a cada uma dessas crises. 

Tu tocas num ponto interessante no teu mail, sobre sermos a continuidade de nossos ancestrais. Sem dúvida, carregamos em nós a experiência e a força da vida de toda nossa ancestralidade. 

PAra quem pensa que ao negar a reencarnação de um atma, de uma alma o xamanismo Tolteca empobrece a experiência humana é bom lembrar que o Xamanismo tolteca nos revela outras possibilidades incríveis. 

Além das experiências e vivências de nossos ancestrais trazemos também as 'fibras" de vidas que foram vividas por outros "tapetes" , temos em nós essa riqueza de experiências diversas. 

Mas o Xamanismo tolteca vai mais longe, nós também vivemos em várias realidades, somos seres multifacetados, vivendo em diversas dimensões simultaneamente. 

Isto abre possibilidades fascinantes, por isso um praticante do caminho precisa se trabalhar tanto, remover os egocentrismos e as interpretações antropomórficas da realidade para poder entrar nestas possibilidades incríveis que temos.
 
PAra o Xamanismo tolteca há um eterno "agora" na realidade, e estamos inseridos neste agora, não há passado , nem futuro, há um eterno presente no qual estamos inseridos. 

Quando temos experiências que julgamos estar viajando para um passado, visitando um lugar no passado o que está acontecendo na realidade é que estamos indo a um mundo na segunda atenção, este tema é muito sério, há muitos lugares na segunda atenção criados pelo intento de feiticeiros(as) poderosos(as) e muitas vezes somos atraídos a esses lugares para alimentarmos com nossa intenção, a energia do local. 

Temos de estar bem atentos em nossas viagens pelo infinito, especialmente nós homens, pois existem armadilhas tremendas no caminho até conquistarmos a plena autonomia em agir com o corpo de energia. 

Por isso precisamos nos libertar das fantasias e ansiedades, das carências e medos, para que não sejamos por eles manipulados, para que não entremos em outros mundos procurando "consolo". 

Por isso o Xamanismo Guerreiro é tão árduo, tão intenso em seu treinamento, para nos tornar capazes de irmos a Eternidade sem sucumbir a Ela.