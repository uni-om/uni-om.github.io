---
layout: texto
tags: [sombrio]
texto_number: 108
category: ventania
---
Date:Ter Fev 26, 2002 12:33 pm
Texto:108
Assunto: Filosofia Esotérica- mantendo o escopo da lista
Mensagem:1807

ALoha lista 
ALoha Tekunse 
ESte material que vc está enviando não tem relação com o xamanismo, é teosofia, um caminho completamente distinto. PAradigmas completamente distintos e sem relação com o Xamanismo que estudamos aqui. 

É interessante conhecer outros pontos de vista, saber como outros caminhos abordam a questão. 

A primeira parte teve seu valor de despertar todo o questionamento que estamos vendo ser debatido sobre a questão da reencarnação que é um tema importante. 
Mas não creio que tenha a ver continuarmos a estudar teosofia na lista, esta lista é uma lista de Xamanismo, não de Teosofia 

EXiste um propósito nesta lista, uma proposta de Intento e sintonia com a Intenção dos antigos videntes, por isso temos todo um cuidado com os temas que enviamos a lista para estejam sempre no escopo da mesma: Xamanismo Guerreiro. 

Quando trabalhamos com temas como budismo, taoismo e similares aqui o fazemos nos pontos que tais caminhos tem em comum com o Xamanismo Tolteca. 

Já a abordagem da Teosofia tem quase nada a ver com o Xamanismo Tolteca, são abordagens completamente diferentes, assim como o espiritismo não tem nada a ver com o Xamanismo tolteca. Mesmo garimpando muito pouco ou nada vamos encontrar de comum entre a abordagem teosófica de mestres, corpos e tal com o xamanismo tolteca, lhe digo isso com base, fui teosofista por anos, participei da sociedade teosófica e tal e os paradigmas teosóficos são completamente distintos dos do xamanismo tolteca. 

A Teosofia teve seu papel, sua importância, mas é um paradigma que não tem afinidade com o xamanismo tolteca que é o tema desta lista. 

A abordagem do Xamanismo tolteca em muitos pontos diverge nitidamente da abordagem teosófica e sua visão Vedanta da realidade. A idéia de um Atma que reencarna e tudo que isto implica é estranha as propostas do Xamanismo Tolteca, saber que existem outras abordagens da realidade tem um grande valor, saber que existem outros caminhos é sempre interessante, mas o tema da lista é um estudo profundo do xamanismo tolteca. 

Sei que toda restrição é meio chata, pode parecer um certo sectarismo, mas existe uma proposta nesta lista e nós temos procurado manter a lista neste escopo, tanto que comentamos que tem épocas que a lista fica sem mensagens e nenhum problema nisso, o importante é que o “INTENTO" da lista esteja ligado ao Xamanismo Tolteca, a seus paradigmas e estudos correlatos ao mesmo, existem muitas boas listas na net dispostas a estudar outros temas, mas esta tem um foco, pois é também uma experiência. 

A abordagem teosófica é de outra qualidade, o que D. Juan Matus e Carlos Castañeda passam, assim como ramos paralelos de xamanismo tem outra abordagem, muito distinta e em muitos pontos completamente contrária. 
Reencarnação, mestres, avataras são conceitos que não fazem parte do xamanismo tolteca, são estranhos e por vezes contraditórios com as propostas do mesmo. 

Creio que para mantermos o escopo da lista as pessoas interessadas nestes temas podem lhe escrever pessoalmente e tu envia o material em pvt para elas, este espaço, por várias razões que já citamos anteriormente, deve ser mantido para o estudo do xamanismo e de temas afins, especialmente do xamanismo tolteca e todo tema correlato que entra é quando o tema tem relação com os paradigmas destes caminhos, como o Budismo, o Taoismo, certas escolas de Yoga e estudos como a fenomenologia, assim como a física moderna e outros campos correlatos. 

É muito fácil uma lista perder seu foco e seu escopo e esta lista é um experimento, temos um intento aqui, a lista não é para debater esoterismo em geral, mas apenas xamanismo, assim me parece que o tema teosofia não tem a ver com a proposta da lista. 

Quando colocamos nosso cocar e nos sentamos para ler os mails desta lista a proposta é que estejamos nos alinhando ao intento do Xamanismo Tolteca, por isso insisto que o tema da lista, o escopo, seja mantido e o tema é Xamanismo. 
Assim, que as pessoas fiquem a vontade de lhe escrever para que envies a quem interessar o material sobre teosofia , conhecimento é sempre interessante e válido, mas o espaço da lista deve ser mantido para o assunto Xamanismo e temas correlatos. 

Essas correções de curso são importantes para evitar que percamos o foco de nosso objetivo nesta lista, estudar o Xamanismo Guerreiro, o Xamanismo Tolteca.