---
layout: texto
tags: []
texto_number: 109
category: ventania
---
Date:Qua Mar 27, 2002 7:06 pm
Texto:109
Assunto: Re: [ventania] Intento
Mensagem:1889

Olá lista 

Esta questão de ciclos é interessante 
Primeiro mostra como somos criaturas de sintaxe e como viramos , mexemos, enfeitamos, colocamos purpurina e confetes mas continuamos presos aos mesmos paradigmas. Ano, começo de ano, fim de ano, mudança de ano, a meu ver ainda é o mesmo paradigma. 

Com certeza entrando o outono muitas energias mudam, pelo menos aqui no sul de Minas foi sincronizadissima essa mudança, no dia do equinócio o tempo já mudou aqui e desde então o clima já tá outro, nitidamente diferente do que vinha no Verão. 

Agora começo de ano eu já não diria, pois isto é um hábito europeu, uma vez que na Europa entrou a primavera , depois dos rigores do inverno tem tudo a ver saudar esse momento como um "recomeço" , um "retorno" da vida que tava escondida sob a neve, mas aqui no hemisfério sul ? 

Ok, quem trabalha com astrologia pode dizer que o ano começou de novo, mas estamos de novo falando de uma convenção , convenção estabelecida no hemisfério norte. 

As estações de fato determinam diferentes e objetivos ciclos, mas não seria esse conceito de "ano novo' e tal apenas uma continuidade dos mesmos paradigmas, apenas fantasiando de forma diferente? 

Alguns questionamentos que me vieram a mente pondo em dia minha caixa de mails