---
layout: texto
tags: []
texto_number: 112
category: ventania
---
Date:Sáb Mai 11, 2002 11:51 pm
Texto:112
Assunto: Mudanças
Mensagem:1971

Aloha. 

Meu mail anterior para a lista foi motivado por este último período que passei. 
Vou comentar alguma coisa sobre estes últimos meses , que causaram uma modificação profunda na minha forma de ser , estar e sentir o mundo, modificações que ainda estão pipocando. 
EStes eventos que vou comentar fazem parte de meus momentos memoráveis, por isso considero interessante partilhar. 
. 
Tive a tremenda sorte de conhecer uma Taoista com a qual estudei nestes últimos meses. 
Posso dizer sem exagero que uma pessoa morreu neste período e outra surgiu, a que está escrevendo agora. 
Ainda estou em profundas mudanças como resultado deste trabalho todo , mas agora com uma nova perspectiva de 'varias coisas. 
O fato é que para atingir mesmo os desafios de caminhos que levam ao desenvolvimento do corpo de energia e tal precisamos de fato nos tornar muito ciosos de nossa energia pessoal, sem gastá-la com tolices. 
Bem, logo que a conheci ela me colocou numa sinuca, me disse que estaria disposta a partilhar seu conhecimento comigo mas se eu seguisse a risca o que ia recomendar. 
Tenho aquela natureza indisciplinada que se disfarça de "livre", por isso fiquei meio cabrero com este "seguir". 
Bateu o medo de me expor a alguem que pouco conhecia e a um conjunto de práticas que poderia ser apenas mais um esquisoterismo dos tantos que correm por aí. 
Ela riu de minhas dúvidas e se manteve irredutível, ou tudo ou nada, mais ou menos ela nao queria. 
Treinamos uma tarde inteira numa mata virgem que tem nos arredores do sítio onde nos conhecemos, saímos para uma "caminhada" e ela me deu o maior caldo em termos de agilidade, rapidez, resistência e tal. 
PErcebi que nào estava diante de uma pessoa cheia de 'teorias e espiritualismos" mas de alguém que realizava na prática o que sabia e me deixei ir. 
Dentro da orientação dela , vou chama-la M. parei total com alcool, dei um tempo no sexo, dormia quase todo dia antes da meia noite ( no horário de verão antes da uma), pelo menos duas vezes por semana tinha que dormir antes das 10 da noite, devido a certos ciclos de energia que vao passando pelos meridianos da gente, enfim , dei uma mudada radical , percebendo que apesar de trabalhar muito contra isso, ainda tinha um monte de rotinas, apenas rotinas mais elaboradas. 
Foi uma mudança radical de vida, quem me conhece sabe que gosto de sair, de curtir danceterias, de beber um bom vinho e um bom wisky, enfim, vários estilos de vida que consomem certa energia mas os quais sempre me permiti.. 
Ela me passou muitos, muiiiiiiitos exercícios, o dia tava todo empenhado, risos, mas o fato é que percebi nitidamente alguns pontos fundamentais, idéias que tavam faltando virar prática . 
Ela me forçou a rever tudo que julgava "conhecido' e é neste ponto que tenho algo a partilhar aqui na lista. 
Eu reli a obra do Nagual nestes meses, toda ela, das mulheres do grupo, as centenas de paginas copiadas da net, muitas enviadas aqui prá lista e percebi que em toda a obra do NAgual não há incoerência, ao contrário, há uma elegância profunda dos conceitos apresentados e a quase totalidade dos conceitos ali apresentados experimentei em meu corpo, levando minha concordância a uma "sociedade" com a descrição de mundo que ele apresenta. 
No livro da Taisha , Clara apresenta uma idéia que também comprovei, a similitude impressionante da obra do Novo Nagual com o Taoismo, especialmente certos ramos mais ancestrais do Taoismo que depois da revolução cultural e suas perseguições ideológicas, é dificil de encontrar mesmo na China. 
MAs assim como o saber Tolteca sobreviveu em linhagens muito específicas e fechadas este saber Taoista também'está seguindo sua criptica trilha. 
A prática das propostas lançadas na obra do novo Nagual leva a uma redimensão de nossa energia pessoal que afeta diretamente nossa percepção da realidade e de nós mesmos. 
E como em certas escolas Taoistas o caminho Tolteca pretende nos ajudar a ir além das "máscaras sociais' , da sociedade que temos com as convenções que geram este mundo que chamamos por REal, a proposta é ir diretamente a percepção da energia, que nos permite vislumbrar a realidade tal qual ela é, nao nos limites que nos ensinaram e moldaram nossa percepção. 
Notem bem, não se trata de seguir, sim de praticar, aliás seguidores sao sempre os traidores de uma obra, não é disso que estou falando, falo sobre a prática. . 
Há dois meses atrás ela lançou outro desafio, ela me disse que ia prá Guatemala e me convidou para ir com ela. 
Me colocou como condição que eu só poderia , neste tempo da Guatemala , manter contato esporádico com minha familia, por razões óbvias, evitar preocupaçoes, no mais eu devia me afastar de todo mundo, TODO mundo, inclusive meu meio de trabalho cotidiano. 
TEnho uma empresa de consultoria, trabalho em Sampa, Minas e no RGS, hora, quem conhece o competitivo meio dos consultores sabe como é dificil esta escolha, deixar TUDO que construí e tal, mas percebi que valia a pena. 
Por "coincidência" um amigo de infância voltou dos EUA , com especialização em áreas similares as minhas e se tornou meu sócio, podendo assim passar prá ele as empresas que tavam comigo , sem quebrar a continuidade do TRABALHO. 
TEm uma hora que a gente tem que escolher se vai continuar sendo um "estudante" do caminho Tolteca ou se vamos ser "praticantes" . 
Notem bem, praticar Tensigridade não significa praticar o caminho Tolteca, muita gente pratica Tensigridade para viver melhor, ter mais energia, ter mais saúde e tal, isto é válido, mas o Caminho Tolteca, em sua plenitude, na proposta de atingir a Terceira Atenção tem exigÊncias sutis, basta ler sobre a vida do novo nagual e de suas companheiras e mesmo os relatos do grupo inicial, aquele com Pablito, NEstor, La Gorda, as Irmanitas e outros (As). 
Ora como praticante tenho que assumir que já morri para o mundo e tudo mais, que a meta hoje é outra, entao não havia o que titubear e , por impecabilidade, arrumei as coisas para poder me afastar . 
Por orientaçào dela me afastei progressivamente das pessoas com as quais tinha alguma .relação de aprendizado/ensino e fui me preparando para ir embora. 
Coloco isso aqui porque algumas pessoas nesta lista tinham uma relação de aprendizagem comigo e podem ter se sentido " ignoradas" , não expliquei nada porque fica aí a chance de cada um trabalhar a importância pessoal e tal. 
Eu estava com um livro pronto também e foi pedido que o "segurasse um pouco" . 
Bem , chegamos ao presente, ela já foi embora, me deixou como tarefa terminar o livro com as revisões devidas frente ao meu modo atual de conceber tudo que aprendi e depois que cumprir alguns ítens vou para onde ela está. 
Isto pode demorar um mês ou um ano, ou mais,ou menos, o fato é que gostaria de aproveitar este tempo por aqui para fortalecer a proposta desta lista, estudar o xamanismo Tolteca. 
RElendo a obra do novo nagual e suas companheiras , assim como as notas de conferências e seminários e entrevistas que existem na NET, notei que temos um complexo e pragmático trabalho aqui, que merece ser estudado com atenção. 
Fica dado o recado, se sumir de repente não se assustem, apenas aprendi a ser poeira na estrada, poeira estelar. 
Até lá vou partilhar um pouco da redimensionada que tive reestudando o saber Tolteca sob orientação desta mulher que aprendi a ter como mestra, amiga e companheira de Caminho.