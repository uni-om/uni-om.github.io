---
layout: texto
tags: [pérola, prática, mapa, sombrio]
texto_number: 114
category: ventania
---
Date:Qui Jul 4, 2002 10:17 am
Texto:114
Assunto: Re: [ventania] Sabemos, realmente, que somos mortais ?
Mensagem:2046

Aloha lista 
Aloha Natanael 

Concordo com teus questionamentos, um dos pontos mais difices no caminho Tolteca , como em outros similares é justamente esta questão da morte 
O fato da morte, da dissolução ao final desta exixtência nos coloca em um ponto completamente diferente de todos os caminhos tidos por espiritualistas e esotéricos hoje em moda. 

Excelente sua pergunta: " Espreitamos a nós mesmos como seres mortais ou imortais? " 

A diferença do enfoque desta espreita é determinante em nossa posturas existenciais. 

Conversando com muitas pessoas em situaçoes diversas noto muitas delas alegando que trabalham com os paradigmas toltecas, mas neste ponto da continuidade da existência tentam sempre elocubrar, tergiversar, enfim, há sempre um "medo" de encarar a morte como o evento que dissolve nossa existencia individual. 

Concordo contigo na reação a esse fato, há um "sobressalto" inicial, por vezes assustador , mas logo depois vem a certeza que tudo que temos é esse "aqui e agora" . 

É tão profundo este jeito de viver, de se relacionar com o mundo, cada instante, cada momento, pode ser o momento final, pode ser o ponto final em nosso discurso existencial, assim, para alguém que lida com esta abordagem do caminho, não há dúvida que cada instante é tudo que temos e a qualidade de nossa vida em cada momento determina se estamos fluindo pelo Mar Escuro da consciência ou continuamos na condição de navegantes num rodamoinho artificial, que nos leva para o fundo tendo a ilusão que estamos indo para algum lugar. 

Está demonstrado que a energia disciplinada e focada é "ruim" para os predadores , eles não apreciam esse estilo de comportamento, assim agir com foco e disciplina é impregnar nossa energia pessoal de um "gosto" que não agrada os predadores. 

Quando nos conscientizamos que só há o aqui e agora, tudo muda. 

Descobrimos que não podemos perder tempo, não podemos nos manter num caminho sem coração, pode não haver um amanhã ou um " depois" para dizermos a quem amamos, o tanto que amamos, para fazer em cada momento de nossas vidas o que queremos e não o que querem por nós. 

Precisamos olhar a nossa realiidade circundante e corajosamente questionar : estou num caminho com coração? 

É aqui que gostaria de estar?

Se houver um não como resposta a questão é : por que não mudamos já? 

Ou estamos esperando papai do céu? 

É radical, é revolucionária a proposta de vida daí resultante. 

Sem dúvida alguma é a plena compreensão desta abordagem que nos dá a força e a integridade para fazermos de cada ato um gesto para o infinito, um gesto para a Eternidade.