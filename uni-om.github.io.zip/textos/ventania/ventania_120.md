---
layout: texto
tags: [mapa, sombrio]
texto_number: 120
category: ventania
---
MENSAGEM 2123
Texto:120 (118,5)
Sent: Thursday, August 01, 2002 1:28 PM 
Subject: [ventania] Sobre a viagem astral e o corpo sonhador
 
Aloha lista 
Aloha Natanael ! 

O tema "viagem astral" é bem vasto e sem dúvida está ligado a questão do corpo de energia, desse "outro" que podemos desenvolver em nós. 
Em diferentes tradições vamos encontrar esse tema. 
Um detalhe significativo é que para muitos povos o trabalho com o corpo energético é "superior"" mais "espiritual'. 
É muito interessante estudar isso, tanto nos caminhos Toltecas como em ramos do Taoismo encontramos fases que lidam com esta "superioridade" de lidar cm este lado tido por espiritual 
Entretanto os novos e novissimos videntes, assim como praticantes de caminhos taoistas e similares tem abordagem diferente, consideram que o chamado "plano espiritual" é apenas o outro lado da moeda deste plano. 
No caminho Tolteca temos o conceito de Tonal para esta realidade e de Nagual para as outras realidades 
Assim sendo operamos neste mundo com o tonal, vasto, complexo e atuamos com o Nagual nos mundos outros que não este. 
Levamos anos para desenvolver este segundo corpo, como também levamos anos para atingir um grau mais amplo do nosso tonal, uma vez que no dia a dia, estamos presos a procedimentos robotizados, bem aqüem das reais habilidades que temos . 
Os Toltecas e alguns outro ramos desenvolvem uma abordagem bem complexa desse tema, da possibilidade que temos de gerar e desenvolver este "corpo sonhador' . 

É interessante observar diversos ramos que lidam com este tema, desde os 'cursos de projeciologia" com sua temática espírita até chegarmos nas abordagens mais complexas como no xamanismo e taoismo. 
No sistema de Gurdjieff como em outros há uma proposta bem diferente da proposta de outros mais "espiritualista" . 
Nestas práticas lidamos com o "formar'" e desenvolver do corpo sonhador, algo que existe potencialmente em nós mas necessita de trabalho, árduo, longo, para apresentar resultados efetivos. 
Tanto no Tai Chi Chuan como na Tensegridade vamos encontrar práticas objetivando desenvolver o corpo de energia, o "outro" que está potencialmente em nós. 
Mas temos sempre que nos lembrar que o "sonhar' está impregnado da energias dos antigos, com todos os riscos que isto representa, por isso ao lado do "sonhar ' precisamos ter sempre bem trabalhado o 'espreitar" para que o equilibrio seja sempre alcançado. 
Quanto a questão dos "vampiros' que sugam nossa energia é um tema amplo, num outro momento podemos voltar ao assunto.