---
layout: texto
tags: [pérola, mapa, sombrio]
texto_number: 14
category: ventania
---
Date:Seg Set 4, 2000 8:10 am
Texto:14
Assunto: Um novo sonho.

Saudações nos quatro cantos do mundo Ventania;

Como tenho viajado muito a trabalho tenho estado um pouco ausente de participar na lista, mas tenho procurado ler e me inteirar dos temas aqui presentes. 
Em primeiro lugar boas vindas a todos (as) que chegaram. 
Sejam bem vindos(as) a lista tem por objetivo ser um espaço virtual dedicado ao estudo do Xamanismo, da tradição nativa de vários povos. 
O xamanismo é um caminho e como cada caminho tradicional só é compreendido quando trilhado. 
A plenitude vem quando caminhante e caminho se tornam um só. 
Estamos aos poucos entrando num mundo diferente do que vínhamos vivendo. 
Sem cair nas profecias esquisotéricas vemos que de fato o mundo esta' surgindo, um mundo novo e complexo está aparecendo e uma parte importante deste mundo é a realidade virtual. 
Aqui estamos, em bite, em zero e um, trocando informações, vencendo tempo e espaço para nos encontrarmos nesta fogueira virtual, onde trocamos impressões e vivências sobre nossa luta no mundo, nossa vida como adeptos de uma trilha de liberdade num mundo de escravos. 
Para nós que trilhamos os caminhos nativos é evidente a escravidão deste mundo. 
Há dois mundos coexistindo. 
Um deles está nitidamente se acabando. 
Outro está começando. 
Há um novo ciclo civilizatório se iniciando agora e ao mesmo tempo o antigo sistema tudo faz para tentar manter seu poder. 
Uma xamã com a qual estudei nos dizia que o mundo que está terminando é um mundo da Era do Gelo. 
Tudo nele foi construído em gelo e este mundo se manteve porque nosso plano da realidade esteve isolado , eclipsado digamos, de certas energias que emanam do centro da galáxia. 
Agora estamos saindo desse eclipse. 
Os que estabeleceram seu poder durante a ERa do Gelo fazem de tudo para tentar perpetuar seu poder. 
Vivemos nesta luta. 
Grupos inexcrupulosos continuam a manipular sistemas pelo mundo inteiro perpetuando a mesma sandice imperialista que levou Roma a exterminar vários povos nativos do continente Europeu, depois a Igreja Românica a continuar este genocídio, que veio para nosso continente e levou a extinção de mais de uma civilização complexa e ancestral. 
O que percebemos é que não é necessário lutar contra a Era do Gelo. 
Ela está se esvaindo por si, como o gelo parte quando o sol primaveril retorna. 
Mas do que adianta o sol da primavera voltar se a semente nào estiver pronta. 
A esperança da colheita reside na semente e é esta percepção que temos ao trabalhar ativamente para lidar com essa semente no interior de cada um. 
O Xamanismo é um caminho de reconexão. 
REconexão conosco mesmo, o resgate de nós mesmos da condição de sonâmbulos robotizados, a qual fomos condicionados pelo sistema dominante. 
Nossos antepassados espirituais foram presos e marcados a ferro em brasa, nossa escravidão é mais sutil, porém presente. 
A marca hoje é nos olhos, olhos apáticos, ansiosos em futuros , rancorosos em passados, mas inexistentes no brilho que caracteriza o estar pleno no aqui e agora. 
As amarras, as correntes, mais sutis, insidiosas, ideológicas. 
E lutar contra os paradigmas que nos escravizam é a trilha do Xamanismo guerreiro, não lutar contra outras vítimas da escravidão que se fizeram capatazes, algozes de seus iguais para servir a um sistema que também os mantém escravos. 
Há armadilhas muito sutis, há formas insidiosas de prisão. 
Os mecanismos de aprisionamento estão sempre prontos a usar nossa própria ânsia de liberdade para seus próprios fins. 
Assim não é raro ver surgir caminhos que se pretendem "xamânicos", "espirituais" mas que na realidade apenas perpetuam a condição de escravidão que já estamos. 
PAra nós , praticantes do xamanismo, a luta é diária, mas uma luta tranqüila, não inquieta, não raivosa, nào ansiosa. 
É o combate do (a) guerreiro(a) que sabe o porque luta e assim encontra-se frente a atrocidade do mundo com calma e equilíbrio. 
Este combate é travado em várias frentes e cá, nesta lista, temos um desses campos de luta, onde por idéias e partilha crescemos em conjunto, cumprindo a antiga lenda da Tribo do Arco Íris, onde homens e mulheres de diversas cores e tradic'~oes se reuniriam para curar a Terra. 
Cada momento de nossas vidas é um desafio nesse sentido. 
A maneira pela qual agimos a cada instante no mundo onde existimos é nosso sinal de força para esta nova realidade que sentimos surgir ou um ato subjugado a perpetuar o antigo mundo. 
Cabe a cada um de nós escolher de que lado nos alinhamos e palavras apenas tem muito pouco valor aqui. 
É na realidade de nossas atitudes que revelamos nossa realidade interior. 
Que a LIBERDADE seja sempre nossa meta. 
Que cada mínimo ato possa ser estratégico, uma combinação sóbria de implacabilidade, astúcia, paciência e gentileza. 
Se meditarmos sobre o sentido desses termos, se impregnarmos nossos atos deles, com certeza começaremos a vislumbrar com mais intensidade este outro mundo que aqui já está e seremos colunas, alicerces da construção dessa nova realidade. 
Este é um sonho novo, diferente do sonho de mundo que aí está. 
O desafio é sonhar consciente