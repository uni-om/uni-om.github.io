---
layout: texto
tags: []
texto_number: 2
category: ventania
---
Date:Sex Abr 7, 2000 11:54 am
Texto:2
Assunto: Re: Re: [ventania] Saudações Xamânicas 

Saudações nos quatro ventos.
Estou começando a enviar para a lista alguns mails que foram temas em
outros momentos, em outras listas, envolvendo a questão xamanismo e sua
relação com outros caminhos pagãos.
é um material de apoio aos temas que estamos tratando aqui.

Paz e Luz!

Nuvem que passa