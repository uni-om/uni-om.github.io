---
layout: texto
tags: [pérola, mapa, prática]
texto_number: 28
category: ventania
---
Date:Qui Dez 28, 2000 2:09 pm
Texto:28
Assunto: Re: [ventania] Déjà vu & Xamanismo

Saudações Ventania; 
Saudações Wurch; 
Vamos a esse tema. 
o Déjà vu é o nome que damos a sensação de já termos vivido algo antes. 
Somos muito inconscientes da riqueza de nossas sensações e percepções interiores, temos muitas habilidades dentro de nós e só usamos uma gama limitada. 
Assim toda vez que "esbarramos" com percepções vindas do interior nos assustamos um pouco e a descrição de mundo dominante tenta recuperar o controle perdido. 
Aí racionalizamos, fazemos interpretaçòes, linearizamos o que antes era uma percepção de muitas dimensões. 
Do cubo só percebemos a linha e damos um nome a essa experiência. 
Intuição é algo assim. 
Operamos com outras facetas de nossa condição e então o resultado surge, uma certeza que não veio pelos mecanismos que normalmente usamos, como raciocinar ou emocionar. 
O déjà vu é uma dessas sensações. 
A estranha sensação que temos num déjà vu nos aponta que algo ali, naquela cena nos é profundamente conhecido, estamos de alguma forma tendo um reencontro com algo, o que nos ocorre agora nos toca num nível mais profundo e estrutural , ao ponto de termos certeza que aquilo já aconteceu antes. 
O déjà vu é um momento de dupla presença, de repente tu estais mesmo ali presente na cena e sente que já estivestes ali antes, que aquilo já foi ouvido antes. 
Aliás no caso de ouvir ou ler algo despertar essa sensação chamamos isso de "déjà entendeur" mero afrancesamento para dizer: isto que estão dizendo, ou estou lendo, eu já vi isso antes! 
Veja o exemplo que citas , quando lestes minhas colocações no mail outro tivestes algo como um déjà vu. 
O tema era segunda atenção. 
Quando um guerreiro xamã escreve coloca em suas palavras não apenas o pensamento, mas seus sentimentos, o ato é uma forma de expressar seu intento. 
A sutileza é também impregnar o que se está falando com as lembranças pessoais das vivências efetivas do que se expressa. 
Aí, assim como numa mensagem de muitas camadas, teremos outras camadas na mensagem, camadas para tocar o corpo energético ainda embrião ou já em gestação avançada. 
Assim como as palavras tocam o Tonal, junto, com bite , com Ø e 1 , em pulsos eletromagnéticos estou experimentando se também podemos pelo mundo virtual enviar mensagens da segunda atenção, se tais conexões são possíveis. 
Quando estou dando uma vivência ou palestra, ou falando com pessoas que considero buscadores(as) sinceros da ARTE procuro sempre fazer isso, falar para o Tonal e vibrar meu corpo de energia na mesma informação para que a mensagem se impregne também em outros níveis de quem participa. 
Da mesma forma as experiência que estamos conduzindo aqui nesta lista é sobre este mesmo nível de comunicação, pois só quando os dois corpos podem igualmente comunicar-se é que se pode falar de xamanismo, pois xamanismo é assunto do corpo esquerdo e direito e em cada um tem uma amplitude e magnificiência. 
Sua questão e a sensação que teve nos dão pistas que de fato estamos conseguindo essa sutil confirmação. 
O corpo tem sensações das mais desconhecidas ( e interessantes!!!) esperando para serem descobertas, mas ficamos insistindo em repetir certos estados emocionais já vivenciados, ficamos querendo repetir um passado que julgamos melhor ou tentar um futuro utópico , onde julgamos que está a felicidade ou o nome que damos a este objetivo fantasioso que substitui em tantos a busca da Liberdade Total. 
O trabalho do (a) xamã, enquanto na ARTE da Loucura Controlada ( prefiro este termo à espreita) deve ser observar, como um ator ou uma atriz se estudam e estudam o modo de ser do mundo a sua volta para compreender a composição de um personagem. 
Há muita similitude num verdadeiro trabalho de Artes Cênicas e o aprender a compor personagens na Arte da Loucura Controlada. 
A diferença é que o(a) guerreiro(a) xamã faz isso com um propósito e o faz deslocando seu ponto de aglutinação, portanto na arte da loucura controlada o (a) guerreiro xamã não finge algo, ele (a) É esse algo, daí a necessidade de realmente entender isso e ter um (a) mestre (a) afiado nesta arte e não ficar usando a desculpa de espreitar para adotar comportamentos que apenas reforçam ainda mais o ego e autocomplacência. 
Observar a nós mesmos é perceber além dessa camada superficial e linear de lidar com o mundo, é mergulhar no mundo de forma profunda, intensa, apaixonada. 
Só depois que amamos profundamente este mundo, ele se abre e revela seus segredos para nós. 
Vejo tantas pessoas em fuga de si e do mundo usar do xamanismo como desculpa para suas fugas. 
O caminho do xamanismo é um caminho de fuga, sim, mas de fuga dessa condição de anulação existencial na qual escravizaram a humanidade, de fuga dessa prisão conceitual que chamam realidade única. 
Mas o xamanismo não pode ser uma fuga de si mesmo, já que a primeira prova iniciática, o primeiro portal, a pinguela inicial para a trilha do xamanismo é o encontro e reconhecimento de si mesmo. 
Esse momento que nos reconhecemos entes perceptivos e singulares na existência começamos um novo ciclo em nossas vidas. 
Até então éramos lagartas. 
Agora estamos na crisálida rumo a borboleta, sabendo que nela também temos passagem não lugar de chegada. 
Ir profundamente ao encontro de nós mesmos requer coragem, requer abandonar a arrogância e a preguiça e então corajosamente reconhecer o nada que somos. 
E este , dizem os(as) Toltecas, é o desafio supremo, nós que nada somos, encararmos alegre e voluntariosamente a absoluta vastidão e solidão da Eternidade. 
Deixe-me contar um pouco de onde estou. 
Estou escrevendo num lap top que instalei o Outlook. 
Desde o solstício de Verão tenho andado pelas serras na região onde costumo ficar. 
Eu escrevo esses mails ainda nestes lugares que para nós são lugares de poder e depois quando chego na cidade conecto e envio. 
As vezes nem sou eu que vou na cidade conectar e enviar então se alguma resposta demorar não se encanem. 
Hoje estou nos arredores da cidade , mas nos p'roximos dias devo me afastar de novo. 
Mas vamos continuando essa troca de idéias que está muito produtiva. 
Tenho recapitulado junto com Melina muita coisa da época que Oomoto, Marta e todo o pessoal vivia por aqui. 
Ela está indo embora prá China de novo . 
Quando conheci toda essa trupe era adolescente , Melina, alguns anos mais velha que eu, já uma jovem, bonita e fascinante que era minha amiga e por um tempo a face da Deusa amante. 
Para um cara de 15 anos ter uma "amiga colorida" ( risos) como ela era muito prá cabeça e ela me encantava, seduzia e assustava na mesma proporção. 
O que mais me incomodava é que tentava criar esquemas românticos e tal, traduzindo, tentar prendê-la para "tê-la" para mim e aqueles emocionalismos todos e ela conseguia ser mais lisa que mandi. 
São os únicos momentos que me lembro da minha vida que ficava triste. 
Eu me "martirizava" ( risos) "Ela não gosta de mim" e tudo mais que vem junto. 
Por sorte tinha um amigo mais velho, Márcio, que me dava uns toques no como responder a estas situaçòes. 
Eles eram aprendizes de Oomoto e do Clã dele mas eu nem imaginava isso, nem sabia que isso existia. 
Ela e Márcio estavam com Oomoto e todo o pessoal já há alguns anos. 
No começo , como estavam mais próximos da minha idade foram os que se aproximaram e se tornaram meus amigos, até me levarem para o clã. 
Da amizade criada como estratégia veio a verdadeira que brota por uma afeição que nasce num nível onde nada existe de expectativa ou ansiedade, só pura afeíção, uma alegria imensa por aquelas pessoas existirem e o prazer de poder partilhar da presença delas. 
Depois outras pessoas da nossa "geração" foram chegando e este grupo que se formou e por anos vivemos juntos até que foi disperso quando Oomoto e a galera dele foram embora para a Ásia, onde ainda estão. 
Andar por essas serras e vales, pelas cachoeiras, passar por grotas e nascentes , como a Mina do Beija Flor, onde toda primavera um beija flor armava seu ninho, isso tudo tem colocado minha energia a zilhão. 
Embora nessa época estivesse fuçando atrás de rosa cruzes, cabalistas, magistas, teósofos, Martinistas, templários e congêneres não tinha a experiência para compreender como um clã ancestral pode se esconder por eras , desparecendo da história. 
Levou um tempo para eu atingir esse lugar de desapego que alguns (as) xamãs chamam posição da não piedade, que chamo de lugar impessoal. 
Antes de chegar nesse estado como a gente consegue ser imbecil e se preocupar com o que não existe , gastar nosso poder pessoal com futilidades. 
Por isso questiono qualquer pessoa que nào tenah ainda atingido essa posição e se diga apta a viajar entre mundos. 
Como vai saber se não está sendo manipulada a partir de suas carências básicas por seres tão sutis que nem sequer percebidos são? Que podem atuar em sua mente como se fossem seus próprios pensamentos? 
Antes de conhecermos a nós mesmos somos marionetes nas mãos de poderes diversos, que vão dos astros às mensagens que carregamos em nossos genes . 
Se não atingimos a autonomia existencial, no mais profundos sentido deste termo, teremos apenas trocado de senhores. 
Por isso os(as) xamãs guerreiros(as) insistem: xamanismo não é ritual e cerimônias, não é fantasia e adoração de entes ou mesmo de antropomorfização de poderes naturais. 
Xamanismo é uma forma sofisticada de ser e estar neste mundo e em outros, que resgata as aptidões mais amplas que temos. É liberdade de perceber nào apenas o humanamente concebível, mas ir mesmo além, entrar no não humano. 
TEnho meditado muito sobre o valor da vida e sobre como agora, mais que nunca , a Vida como um todo está ameaçada. 
AGora enquanto escrevo estas palavras que vejo o potrinho que nasceu mês passado deitado sob a sombra da árvore, ele que antes só ficava perto dos pais agora já se atreve a explorar toda a área da serra que lhe é acessível. 
Há pouco corria serra acima e abaixo, desfrutando de suas habilidades crescentes, ele que agora já ousa ir tão longe de sua mãe e pai que lá embaixo perto da nascente pastam calmamente. 
Nuvens de chuva vão pelas serras de norte, a luz do sol bate no pasto a oeste em fachos difusos, onde estou está nublado mas ainda não chove, se o vento que sopra continuar é o tempo aberto de sudoeste que vai pegar e ainda vem sol prá cá. 
Tudo isso , todos esses incontáveis tons de verde, essas árvores espalhadas pela Serra, algumas das quais são aquelas que comentei do projeto de proteção a mananciais, as árvores que trouxemos de caminhonete , árvores que foram mudas e que se deslocaram fazendo até 140 km por hora e que agora são seres fixos, crescendo, como será a consciência dessas árvores quando forem maduras? 
Alguns grupos de magistas locais que tem contato com a gente tem feito ritos nos lugares onde foram plantadas algumas mudas, nas luas cheias, interessante pensar as energias de egrégora e a força totem que estas árvores estão ganhando. 
Tudo isso está ameaçado. 
Efetivamente. 
Poluição, depredação, armas nucleares, tudo isso está sobre nós como uma bomba já acesa, apenas com um pavio longo que nos leva a ignorar o perigo esquecendo de centrar forças em removê-lo. 
EStamos nos aproximando do momento da reconexão com Hunab Ku. 
O sol da primavera só cumpre plenamente seu papel se a semente está pronta. 
REflexões de Nuvem que passa, contemplando muitas nuvens passando pelas serras e vales.