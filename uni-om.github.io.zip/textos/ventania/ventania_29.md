---
layout: texto
tags: [pérola, mapa]
texto_number: 29
category: ventania
---
Date:Sáb Dez 30, 2000 4:34 pm
Texto:29
Assunto: Re: [ventania] Ventos

SAudações Listas. 
Saudações Attain; 
O tema " ventos" é um tema bem vasto e faz parte daqueles temas que só podemos aludir sobre, especialmente nós homens, pois nós homens podemos travar amizade com os ventos, mas só uma mulher pode convidar um vento a morar em seu útero. 
Quando falamos de vento estamos e nào estamos falando do que conhecemos como vento. 
Falamos da sensação do vento, do vento forte e da brisa, do vento trazendo frescor no fim de tarde de verão, no minuano e seu frio implacável. 
Esse vento fato é do que falamos. 
O vento / conceito intelectual, o que é vento, deslocamente produzido pela fricçào de massas quentes e frias e tal é um conceito que pode ser ampliado. 
Calor e frio, yang e yin se friccionando para fazer surgir algo que nào estava ali antes. 
Vento. 
Ontem a noite quando íamos sair para uma caminhada nas serras estava bem escuro para o lado noroeste, lado que íamos e lado de onde tradicionalmente vem chuva. 
Eu era o único homem do grupo, Melina ia levar algumas mulheres que trabalham comigo aqui, para uma certa formação rochosa que tem aqui perto que é um lugar de poder de energias femininas. 
Eu ia acompanhá-las até atravessarem a primeira serra, atravessarem a rodovia e entrar na serra já do lugar de poder. 
Como não estava muito calor também senti o que as gurias do grupo sentiram, risos, o corpo meio ficando com preguiça, chuva, molhado, cansado, exausto, frio, já tinha sentido isso. 
Observei como temos um conjunto de eus extremamente preguiçosos, pronto a justificar de mil formas sua não vontade em TRABALHAR. 
SAímos na caminhada e quando a noite caiu ventos diversos sopararam, e a noite foi abrindo, as nuvens indo embora e uma lua barca surgiu . 
O céu revelou-se em estrelas e a noite toda não choveu. 
A Terra é um ser vivo. 
OS ventos fazem parte do poder da Terra. 
Nós somos seres de energia. 
Podemos transmutar energia. 
Nós somos seres de consciência. 
Podemos transmutar a consciência. 
Nós somos seres vivos. 
Podemos transmutar a vida. 
Um dos pontos fundamentais enquanto entes perceptivos é notar esses três níveis de existência que temos. 
Existimos enquanto energia em si, energia que metabolizamos e devolvemos ao meio. 
Existimos enquanto consciência. 
A consciência que maturamos e ampliamos em complexidade , que enriquecemos enquanto vivemos nossas experiências. 
Existimos enquanto força vital e a força vital não é requerida pelo vasto mar escuro da consciência. 
Estas pistas serão de grande utilidade no trabalhoprático rumo a liberdade total. 
O que foco aqui como tema é o tema Ventos. 
Os ventos são poderes, chamá-los de ventos é aludir a algo que está lá mas só pode ser " compreendido" se for sentido. 
Quando se está desenvolvendo o treinamento os (as) treinandos são agrupados em sistemas funcionais, assim existem alguns modelos de agrupamento e associação entre aprendizes para potencializar o aprendizado. 
O primeiro é a i'deia que o número oito quando atingido ajuda a quebrar as correntes da egoticidade. 
Existem outras i'deias de apoio a isto, coisa que existe também no Taoismo. 
O caminho dos Ventos é o mais arriscado de ser trilhado sem orientação . 
É como tentar aprender a dirigir sem alguém lhe ensinando. 
Temerário dependendo do tipo do relevo a sua volta. 
Assim é lidar com os ventos. 
Como luto prá ser um xamã nuvem os ventos sempre foram um dos meus campos de estudo. 
Estudar os Ventos é ir ao encontro do mistério feminino. 
Pois os ventos como entes masculinos, mais correto seria dizer Yang, buscam as mulheres como parceiras e com o auxilio dos ventos podemos descobrir mais sobre essas parceiras fantásticas na trilha do conhecimento que são as mulheres. 
Quando ainda na imaturidade de suas existências perdem muito de seu poder em atitudes das mais tolas, como nós homens também perdemos, por termos sido condicionados a assim agir. 
Mas se encontram a si mesmas e descobrem seus potenciais as mulheres podem chegar num nível de profundidade no Xamanismo que nós homens podemos nos aproximar , não igualar. 
Isto, para meu clã e outros que conheço é um fato. 
Sem nenhum problema de "guerra dos sexos" . 
Homens e mulheres aqui na Terra trazem em si essas energias Yang e Yin que estamos falando e existem homens Yin e mulheres Yang, podendo manifestar ou nao essa polaridade também sexualmente. 
O que ocorre é que a lógica do rebanho ainda perpetua na'civilização dominada e as pessoas são úteis quando produtoras e consumidoras das futilidades que o sistema oferece e úteis quando reprodutoras. 
Uma mulher plena, que não tenha "furos" no corpo energético, uma mulher que tenha enfrentado e integrado sua sombra, pode , após ter feito o rito do sol e trazido a semente do sol para morar em seu útero, convidar o "seu vento " ( cada mulher tem "um" vento próprio.) para vir morar em seu útero. 
Os xamãs homens desenvolveram o feitiço da cabaça , para nela "guardar" um ente a partir do mirar de como as mulheres usavam suas cabaças internas para nela guardar poder. 
E a diferença que o que está na cabaça é um ente, como um saci ou um ser inorgânico de outra extirpe, enquanto que a mulher guarda dentro dela um vento, um poder natural. 
Falamos disso mails atrás, da diferença do poder de um ente e de um poder Natural, que tem sua fonte na própria força do ser Terra. 
Dependendo da sua conformação energética e da quantidade de energia vital em si, podemos nos unir a "mulheres ventos" , numa associação que nem pode ser citada pelas palavras, pois as palavras estão impregnadas de emocionalismos piegas e desarrazoados, de carências e irresoluções e este tipo de relação entre um Homem e uma Mulher pela troca de ventos internos é algo que transcende a tolice sem par do romantismo moderno, feito de carências e cinismo . 
É um sentimento que vem das esferas da não espectativa, do não apego. 
Chegar aos ventos antes de ter se resolvido, antes de ter-se feito nuvem é arriscar ser parede que barra o vento, ser buraco que em sua própria natureza se afunda fugindo do vento, que ainda assim pode percorrer seu interior. 
É o que vejo as vezes no encontro dito " amoroso" das pessoas, onde cobranças , medos, ciúmes e ansiedades preenchem o que poderia ser o partilhar da maravilha de estar vivo entre seres que se sentem felizes pela vida do outro. 
Há muitas complexidades no caminho dos Ventos, mas ele não pode ser trilhado por "busca do amor perfeito" ou por quaisquer outros interesses egoticistas. 
PAra poder fluir com os ventos temos de ser nada, para nele flutuar temos de ser inteiros. 
Quando as gurias voltarem se estiverem dispostas a comentar do ponto de vista feminino algo sobre os ventos eu escrevo sobre .