---
layout: texto
tags: [mapa]
texto_number: 31
category: ventania
---
Date:Dom Jan 7, 2001 10:27 pm
Texto:31
Assunto: Re: [ventania] Hunab Ku - mais perguntas
Mensagem:506

Olá Ventanias
Olá Maria;

Vamos as tuas questões;

Primeiro sobre as "trilhas energéticas na cidade" .

Uma cidade também é um organismo coletivo.
Hoje nossas cidades são amontoados de casas , feitas de acordo com o "gosto"
pessoal de cada um, de acordo com as "posses" e tal.
Mas nem sempre foi assim, entre os antigos caldeus e babilônios , por
exemplo, uma cidade era uma "flor" que era construída para que os deuses e
deusas, como "beija flores" se sentissem por ela atraídos e viessem de seu
voo nos céus até a mesma.

Uma cidade é composta pela somatória da energia de todos que nela vivem e
tem uma frequência energética.
Nós deixamos rastos na energia da cidade quando nos locomovemos por ela.
Os caminhos que usamos,os lugares que vamos, todos ficam impregnados de
nossa energia e é claro, dos outros que usam o lugar também.

Assim temos "trilhas" de energia numa cidade, lugares que tem a ver conosco
e lugares que tem energia danosa a nossa realidade, não são "lugares ruins"
apenas lugares não harmônicos a nossa realidade, como uma pessoa com rinite
alérgica vai achar ruim uma estante de livros toda empoeirada na biblioteca
, enquanto que outra sem problemas vai ficar ali e até achar o lugar
"aconchegante".

Um dos treinamentos do xamanismo urbano é reconhecer essas trilhas e
aprender a quebrar as trilhas que fazemos mecânicamente , que nos prendem e
nos ligarmos a outras trilhas que podem nos energizar.



"Vivemos essa batalha, pois existem os que desejam que
não ocorra a conexão
com O centro galáctico no momento certo."

Por quê ? O que é que eles ganham ? Eu me sinto
estremamente ingênua perguntando isso, mas tenho que
peruntar ... Por quê?

Eu trabalho com cursos em empresas e uma das frases que é quase um bordão é:
não existe pergunta boba, existe a bobeira de não fazer perguntas.

Esse assunto é muito sério e poucos sentem a real seriedade e complexidade
desse tema.
Existem interesses de diversos grupos em impedir que a espécie humana
reestabeleça o contato com Hunab Ku.
Por que?

Creio que os porques dessa resposta vão muito além da nossa compreensão,
estamos falando entre outras coisas da ação direta de entes alienigenas
nesse conluio entre forças humanas e não humanas para manter o mundo no
estado deequilibrado que está.
O que sei é que reestabelecendo o contato com Hunb Ku teríamos mais energia
harmônica no organismo Terra, que seria como um corpo tomado por parasitas,
por vermes por exemplo, que de repente se reestabelecesse e com seus
próprios meios poderia então se libertar dos vermes.

O corpo da TErra está doente, se nós humanos recuperarmos a sintonia com
Hunab Ku trazemos de volta um tipo de energia que ajuda a Terra se curar,
curada a Terra expurga certos entes parasitas que só estão aqui porque
conseguiram desestabilizar a força da vida, nào é a toa que a presente
civilização, totalmente escrava desses grupos, tenha em todas suas
atividades chaves ações de destruição completa da natureza.

"Os Zuwias correspondem aos Zinor da Árvore da Vida dos
ancestrais povos do
deserto, cuja leitura seccionada está entre os
cabalistas."

Quais povos do deserto ? Que Zinor da Árvore da Vida?

ESta resposta fugiria ao tema da lista, vou ver se acho algo aqui prá te
enviar em pvt, mas aí eu teria que ir prá cabala e história dos antigos
povos que habitavam o hoje chamado oriente médio.

O xamanismo que estudo parte do principio que existiu uma civilização
planetária na antiguidade, os monumentos astronômicos de 'varios povos
apontam para 10500 anos atrás o auge dessa civilização.

Ai vem seu tema sobre "continuar vivo" .

Os xamãs dizem que tem dois tipos de "desafiantes da morte" .

Os(as) que o fazem por medo da morte.
Os(as) que o fazem pelo amor a vida.

Em cada caminho a resposta é diferente.

Eu amo a vida, amo o mistério e os leves vislumbres que tive da Eternidade,
mesmo fria e assombrosa, me levam a buscar continuar enquanto ente singular
para ir mais longe nestas descobertas.

Mas respostas aqui existem muitas.