---
layout: texto
tags: [mapa]
texto_number: 32
category: ventania
---
Date:Seg Jan 8, 2001 11:53 pm
Texto:32
Assunto: Re: [ventania] Hunab Ku, Sexto Sol, "144" mil gatos
Mensagem:514

Saudações Ventanias; 
Saudações Wurch; 
O tema Hunab Ku é interessante porque é um mito das origens. 
Aqui começa o primeiro ponto a ser bem trabalhado na nossa abordagem do tema, para que tal abordagem não seja limitada, obliterada e até falseada pelos paradigmas ainda dominantes de nossa cultura. 
Os mitos de origem que temos falam de um deus criador, que não tem começo e que cria tudo e todos e ao criar o ser humano o faz senhor de toda criação, depois começa a escolher um tipo de humano contra outro( povo eleito) , depois favorece o povo eleito no deserto e a religião dominante foi difundida em um clima de total intolerância com morte e destruição para todos que dela discordavam. 
Temos uma religião dominante que vem de um deus do deserto, interessante este dado pois como deus do deserto ele está dissociado da vida e da natureza e onde quer que q religião do deus do deserto exista há sempre uma degradação absurda da vida. 
Hunab Ku não é um Deus criador nos mitos originais, ele é a Fonte. 
A Fonte é de onde tudo emana, mas a fonte em si nào cria. 
Quando Hunab Ku toma a lama ( terra e água) e cria os seres originais estamos lendo de novo um mito recorrente em vários povos, um momento em que as forças criadoras emanadas de Hunab Ku, seu sonhar podemos dizer, unem elementos criando vida que além de ser a expressão da Fonte pode se tornar auto consciente. 
Ir além dos conceitos limitados de Deus é fundamental na compreensão do Xamanismo Guerreiro que aqui estudamos e na comprensão da forma de sentir e pensar o mundo destes povos ancestrais. 
EStamos presos ao arquétipo do Deus judaíco cristão que é "pai", "pastor" , que é antropomorfizado, pois tem "vontade" , "ouve os fiéis" , " castiga os infiéis" e por aí vaí. 
A busca desse tipo de Deus é bem estudada pela psicanálise quando se refere ao "pai psicológico" . 
Toda criança tem sempre um adulto por perto, isso cria a ilusão que sempre haverá alguém para "salvar do perigo" , "eliminar o desconforto" . 
A vida revela que na realidade não temos isso, estamos expostos a uma realidade predadora que não tem porque nos proteger. 
Assim a tremenda carência que surge é superada por poucos, a grande maioria recorre ao sucedâneo de um "pai psicológico" e / ou uma mãe psicológica, um Deus ou Deusa, um partid político, um messias, enfim alguém a quem o crente, o (a) seguidor atribui este papel de "cuidar" dele, esta carência nào superada. 
Esse verdadeiro deus tribal elevado a categoria do abstrato conceito de Divindade cria problemas demais e faz com que as pessoas passem a vida dedicando sua energia a algo que é no fundo um conceito, pois o fato TRanscendente, a real divindade que este conceito quer aludir está bem longe do que hoje este conceito representa. 
No xamanismo a divindade não é feita a imagem e semelhança do homem e assim o elege para rei da criação, no Xamanismo somos panteístas, vemos a Eternidade manifestar-se em cada face sua,em cada sinal de vida, na natureza, no sorriso da outra pessoa que conosco interage, no por do sol, na chuva e no vento forte. 
Mas sabemos que há algo além, um algo que é tão tremendo e transcendente que mal aludimos ao mesmo , para não falsear com palavras . 
Mas existe, está lá, pronto para ser contactado, é uma consciência da Eternidade, sempre ali, sempre mudando, à qual podemos acenar através de atos impecáveis e reestabelecer nosso elo de conexão com a Totalidade. 
Até hoje só conheci duas palavras que não falseiam esta realidade além das realidades, essa fonte das fontes: 
Tao e Intento . 
Bem... aí a pergunta 1... falou-se aqui de Hunab-Ku ser a primeira constelação de certo ciclo do universo que duraria 26.000 anos... o texto refere-se ao mesmo como um deus... alguém poderia dar uma ajuda neste ponto? 
A maior parte dos mitos antropomorfiza o que em leituras mais esotéricas vamos reconhecer como princípios. 
Um mito do passado hoje descrito por "pesquisadores" está para a realidade do mito vivo e presente na sua cultura de origem como uma foto em PB está para uma pessoa viva e atuante. 
Alude, diz que existe, mostra até alguns contornos, mas só, nada mais . 
Quando falamos que Hunab Ku gerou o primeiro homem e a primeira mulher do barro é uma forma de falar que das emanações dessa fonte vieram as forças que levaram a energia e a consciência a se organizarem em sintonia com a força da vida até surgir o que chamamos vida humana. 
E os mitos Maias são conscientes dos ciclos, pois só esta civilização dominante que nega os ciclos, para tentar criar sua própria continuidade, todos os povos anteriores sabiam que tudo era ciclíco, não se refugiavam em teorias que nào funcionavam. 
É interessante e seria cômico se nào fossem trágicos os efeitos, ver esta civilização dominante se dizer racional e mais evoluída, mais "instruída" e "prática" . 
Hoje dentro de uma "universidade" centro pensante oficial do mundo oficial, se investiga a natureza da matéria, os genes, a mente, o espaço distante, mas a verdade é que ainda "é mais dificil quebrar um preconceito que o núcleo do átomo." 
Os povos ancestrais tinham um conhecimento muito prático da realidade e os calendários Maias e de outros povos devem ser vistos assim. 
Cada criaçào de vida, cada reino , cada filo que surge, cada familia, cada gênero, cada espécie é um momento de criação , de algo novo que surge entre a interação constante da consciência com a força vital. 
Os (as) xamãs se interessam em observar atentamente a vida e suas manifestações. 
A consciência é algo real e sensível , como o TEmpo e o Espaço, para os(as) xamÃs. 
Interagindo com a força vital surgem formas de vida que até então não existiam. 
Em nossa época isso é mais raro, os grupos que destròem formas de vida, que extinguem espécies , estes tem mais poder sobre a consciência coletiva . 
Minha questão 2 vai sobre o que se disse aqui "Sexto Sol"... isso propõe outros 5... é a determinação de uma "era"? Dura ela 26.000 anos?? Eis outra questão... 
Essa coisa de 26 .000 anos é muito, muito relativa e não pode ser pensada em termos de anos lineares, é só um jeito de falar de coisas que são muito complexas. 
O jeito de medir o tempo dessa era é por voltas da Terra ao redor do Sol. 
Cada volta completa é um ano, o detalhe é que cada Kin é um período que vai do nascer ao por do Sol, assim sendo cada Kin é único em si e também tem um padrão que se repete. 
Quando lidamos com calendários como o dos maias, vamos ter em cada dia um tom dominante, uma força regente e por aí vai, tudo vai estar ligado a uma busca de saber quais são os tipos de energia que nos chegam e como melhor aproveitá-los. 
A organização de um povo assim é completamente diferente dessa organização ainda resultante da era industrial que temos em nossas cidades. 
Levantamos mais ou menos na mesma hora, comemos na mesma hora, dormimos na mesma hora, tudo para fazer valer os principios organizacionais que pretendiam servir a Era Industrial. Fomos padronizados. 
Para uma abordagem pelos calendários ma'gicos dos antigos nossa relação com o tempo seria outra. 
Mas o fato é que estamos aqui, nesta Era pós industrial ainda sob paradigmas que sabemos ineficientes, que sabemos conduzir a degradação da vida em todas suas formas, mas que ainda servimos. 
Os maias marcaram 20 signos e 13 vibraçòes. 
Por que 20? 
SErá porque contavam os dedos dos pés e das mãos?
Nós só contamos das mãos e temos 10 como base . 
Já o 13 é um número mais complexo, primo, não se apresenta facilmente , mas o calendário lunar tem no 13 sua marca, são 13 luas um "ciclo lunar completo" . 
As pessos ficam criando " cabalas" com esses números mas eles são o que são, marcos, medidores, revelam ciclos objetivos, de energia. 
Como estariam nossas Artes e Ciências se fosse a compreensão matemática dos Maias e não a dos helenos que tivesse sido usada como base ? 
Os maias sabiam marcar o tempo como sabemos marcar num mapa um caminho a percorrer. 
ELes deixaram um rota, uma rota de tempo para nos conectarmos a fim de escaparmos da escravidão. 
Tempo é uma coisa que foi muito deturpada em nossas habilidades perceptivas. 
O tempo linear no qual somos forçados a acreditar é totalmente ilusõrio, embora dentro dele a mandíbula das horas nos cerceie como uma armadilha para ursos. 
Mas a mudança de sincronização com o Tempo, que tem relação com conectar-se a Hunab Ku, à Fonte, isto pode ser feito como forma de nos libertarmos da condição de escravos na qual fomos colocados, podemos nos libertar percebendo que a percepção é a chave. 
Assim um kin em 787 a.c; Séc X e 1976 são tempos muito diferentes. 
Em 1976 o Tonal dos tempos, a forma fundamental da realidade era similar a nossa, já no século X esta'vamos em outro tonal dos tempos, ali, sem muito trabalho, poderia entrar numa névoa e sair num mundo paralelo, já no ano 787 a.c. dependendo da área do mundo que estivesse estaria entre os reis sacerdotes, as rainhas magistas que sabiam ser condors e serpentes, que sabiam ir e vir entre os mundos, poderia estar entre uma das tribos que estava ali começando sua jornada a outros mundos, sabendo que a conexão com Hunab Ku estava frágil demais para lidar com os Conquistadores que em alguns katuns chegariam. 
O desaparecimento "misterioso" dos Maias está muito mais ligado a sua migração consciente para outras realidades cientes dos perigos que se aproximavam. 
O fato que suas cidades, seus livros de pedras, deixados para serem lidos por um futuro então distante, hoje presente, o fato que essas cidades foram depois ocupadas por outros povos faz com que muitos queiram ter "descoberto" nos achados dos restos, desses povos ocupando os locais, pistas do "fim dos maias" . 
Aconteceu uma mudança na realidade, como o outono prenuncia à fartura do verão que tempos de escasses se fazer vi'siveis no horizonte e assim quem sabia foi, quem entendeu migrou e quando veio a destruição puderam escapar. 
Foi um ciclo, esse ciclo se encerra em algum momento de 2012, o momento exato é fruto de ca'lculos muito sutis, ainda sendo determinados, porque o tempo flui"aparentemente" de forma uniforme, mas tem dia que passa mais depressa, tem dia que passa mais devagar, tem dia que tem mais tempo nele, tem dia que tem menos tempo nele. 
Tudo isso interfere até o momento cósmico no qual o sistema solar vai entrar noutro feixe de vibrações oriundas de Hunab Ku. 
O que os (as) xamãs perceberam é que tudo está em sintonia com tudo, algo que nossos cientistas mais arrojados tem percebido também, estamos dentro de sistemas que se inserem em sistemas mais amplos e temos uma teia de interconexões inenarrável em sua complexidade. 
Fazemos parte disso, portanto temos que saber que cada rito que os ancestrais criaram, cada momento do xamanismo é um processo complexo, relacionado com o Todo. 
Acessar o animal de poder, aprender um caminho de trabalho mágico, tudo isto faz parte de reestabelecer conexões muito complexas com a Totalidade. 
Os Maias sabiam que tem Kin ( período do nascer ao por do sol) que tem níveis e tipos de tempo diferentes de outros. 
Tem Kins que são portões, tem kins que são dias em que certos tipos de emanaçòes chegam na Terra e em certas regiões da Terra que mexem com o tempo de forma muito própria. 
O poder de um Kin no qual ocorre um solstício ou um equinócio é diferente de um outro kin, assim cada kin tem sua vibração própria, tem sua "onda" e sua "harmônica" que são palavras que aludem a estados diferentes de diferentes energias em momentos planetários diferentes. 
Vou parar esse mail por aqui que tá armando a maior tempestade, vem vindo forte, nuvens cinzas e vento de noroeste, ainda tá sol aqui onde estou, mas vejo as nuvens cinzas chegando, fortes, 
Voltando agora depois da Tempestade. 
O que seria um erro agora seria virarmos "maistas" isto é seguidores dos maias. 
TEmos que recuperar o paradigma maia, este é interessante, esse calendário lunar que trabalha sincronicamente com pulsos da vida, da vida telúrica e da vida emanada de Hunab Ku. 
Mas os Maias vieram e tiveram seu tempo, deixaram seus relatos e sinais como um farol, para que escapemos dos rochedos e voltemos a navegar no vasto mar escuro da consciência e não apenas nos laguinhos perceptivos precários que nos prenderam. 
Agora vai quanto ao sonho de mil gatos... 
(3)Teria esta história toda a ver com os 144mil ditos por Crownley? E com os veneraveis da Blavatsky?
A idéia dos 144 mil está em vários tipos diferentes de tradição, 144, 144 mil, tem várias idéias sobre esse número, o "numero de eleitos" ou algo assim.
NÃo creio que seja um número exato, creio que é aproximado e é uma noção de algo. PRecisamos atingir certa massa crítica, temos que conseguir gerar um padrão de consciência coletiva que vibre em tal frequência que nos coloque em sintonia com Hunab Ku.
Tem gente que vale por dois, tem dois que não vale um , em termos de consciência esse número 144 deve ser a somatória de seres com um nível desperto no mínimo, cujo poder de sonho pode ajudar a humanidade a sair desse pesadelo onde está presa e ir para um sonho.
Existe um exemplo, podemos dizer que Hunab Ku vai soltar uns tentáculos, uns tubos em direção a Eternidade, estamos no caminho desses tubos, mas temos que criar um lugar para esse tubo se fixar, criar uma "rugosidade " no tecido da realidade, que está liso e sem um lugar onde o filamento enviado por Hunab Ku possa se enganchar.
Temos que mudar nossa compreensão do espaço, existem modelos da astronomia contemporânea que podem nos ser úteis, como aqueles que comparam o universo a um vasto colchão dágua e os planetas e astros em geral são bolas que curvam esse espaço da superfície do colchão, criando curvaturas dimensionais.
Podemos dizer que os fluxos qe queremos conectar em Hunab Ku vão passar a certa distância de nossa posição, mas se "curvarmos" o espaço e o tempo de forma suficiente esses fluxos virão fluindo até onde estamos.
A "AMORC" (prefiro chamar de "R+" dá menos trabalho...) fechará suas portas em 2012 tb... tem algo a ver? Em sumo a pergunta seria: Até onde isto para no Xamanismo e até onde outros grupos "detectaram" isto espontaneamente e até onde outros grupos souberam disto por estudos e têm planos para tal??
Se tu estudas os movimentos do sol e dos planetas vai perceber as mesmas coisas que outros que fazem o mesmo estudo,independente do nome que de ao sol e aos planetas. Da mesma forma grupos diversos herdeiros de tradições ancestrais sabem quando algo realmente importante vai acontecer no planeta e se preparam para isso.
As idéias que quero tirar da ultima pergunta são duas: 
1-O que há "por trás da gramática" 
Isso foi um koän?
2-Possiveis grupos "misticos" (guiados por entes ou não) agindo contra a reconexão. 
"Qualquer um que não foi libertado da Matrix é um agente em potencial "
Morpheus
Eu Nuvem que passa falei, passo o bastão para que o assunto prossiga, enquanto com meu cocar espero nova mensagem