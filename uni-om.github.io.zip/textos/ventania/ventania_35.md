---
layout: texto
tags: [mapa]
texto_number: 35
category: ventania
---
Date:Seg Jan 22, 2001 1:15 am
Texto:35
Assunto: Tempo
Mensagem:548

Olá Ventanias: 
Cá estamos novamente unidos no mundo virtual. 
Onde o tempo flui de forma diferente, a textura do tempo com o qual interajo para redigir essa mensagem deixa algo de si nestas palavras que surgem e num certo momento vão te sensibilizar, em outro espaço e também em outro tempo. 
Quando lemos uma mensagem na lista criamos um elo com quem a enviou. 
Estamos aqui nos estruturando realizando várias experiências no mundo virtual. 
Como organismo virtual podemos fortalecer nossas habilidades individuais, assim fazer parte da lista de fato, é fazer parte de uma egrégora, que quando a ela estamos conectados ampliamos nossas habilidades cognitivas por partilhar do INTENTO da lista? 
E de onde vem o INTENTO da lista? 
Vem de dois trilheiros do xamanismo que se encontraram um dia na beira do mar e resolveram que era hora de realizar este experimento , que neste momento se prepara para mudanças. 
A pergunta que tentamos responder ao criar essa lista: 
É possível criar no mundo virtual um espaço onde possamos trocar experiências e informes sobre a realidade xamânica, em seus ramos guerreiros , principalmente? 
Estamos nos aproximando do final do ano lunar, Dragão deixando e surgindo serpente. 
Como comentamos aqui seria interessante comentarmos alguns calendários lunares para compreendermos melhor a forma de sentir o tempo desses povos que usavam esses calendários. 
Quanto ao calendário Maia, Eu prefiro não usar a interpretação do ARgüeles diretamente. 
É uma visão bem dele, respeitável, muito válida, mas creio que antes de entrar em qualquer visão de alguém é mais interessante sentir a ideía em si, o que é um calendário lunar. 
E o que é um calendário. 
Por que não começamos sentindo o que é um calendário para nós, o que usamos mesmo. 
Fazemos a maior parte das coisas como robôs, precisamos antes de queremos compreender o que está além , compreender de verdade, na presença de nós mesmos , o que está a nossa volta. 
Assim, como usamos um calendário? 
Vc marca um compromisso com alguém. 
No prédio da rua A com esquina S . 
No terceiro andar, apartamento 34 
O espaço é esse. 
O espaço já estava lá, continua lá. 
Aí marca: as 14 : 30. 
Várias vezes o relógio vai passar nesse ponto, vários dias. 
Mas vc diz, 
Na segunda dia 23 de Fevereiro de 2001 
AGora determinou um momento no tempo também, um momento preciso que está vindo, vai chegar e nunca mais se repetirá desta forma. 
É fascinante meditar sobre o tempo. 
Faça uma experiência , marque um momento e um lugar e se proponha estar nesse lugar no momento marcado. 
TEnte fazer isso e escreva prá lista contanto o que sentiu. 
Explicando: marque um dia , uma hora , um local, prá começar pode ser hoje ou amanhã, depois repita marcando uma data mais distante. 
Fique consciente a maior parte do tempo que tal momento vai chegar e dpeois saque o momento, quando chegar. 
Quando os primeiros comentários chegarem para a lista comento mais. 
Mas vamos ao tema, TEMPO. 
Alguns povos ainda seguem calend'rios lunares. 
Eles vem contando o tempo com precisão e marcam seu tempo pelos ritmos naturais, não ritmos artificiais como do calendário com o qual fomos doutrinados. 
Esta questão de tempo é fundamental para compreendermos melhor como nos libertarmos dos paradigmas vigentes no mundo. 
Por isso é tão importante saber se virar neste mundo aqui e agora. 
O xamanismo guerreiro leva a um viver plenamente no aqui e agora, por isso não pode ser um caminho para quem quer fugir da vida e seus desafios ao invés de enfrentar estrategicamente cada momento, expressando-se em atos que chamam a atenção desse Intento misterioso, desse TAO que paira além e entre os mundos, além e entre nós, além e dentro de nós. 
Tenho meditado muito esses dias. 
EStive no Rock In Rio, foi um rito pagão, o estereótipo de um, mas um rito. 
As pessoas estavam ali soltando toda sua energia acumulada, em certos momentos era impressionante sentir o propósito de milhares ( milhares mesmo, mais de dez mil) vozes entoando "OOOOOOOOH" . 
Os músicos levaram a platéia a delirios, imaginem isto canalizado para a TErra, acupunturando a TERra... 
As possibilidades que temos de atingir a famosa "massa crítica" , o sonho de 144 mil gatos(as) me parece algo mais plaúsivel por este lado. 
A ARTE é um caminho amplo, grandes rituais coletivos de amplo e profundo apelo energético podem ser estruturados , podem acontecer já hoje, basta que o modus operandi seja eficiente. 
Porém,quando vejo empresas estatais querendo destruir matas ciliares, alegando que vão plantar grama para evitar erosão tenho percepção que os que pastariam em tais gramas tem mais senso da vida que os pretensos "racionais" que destroem ecosistemas que protegem o bem mais disputado deste século XXI , "água" . 
Aï pergunto: 
Colocou seu cocar para ler essa mensagem? 
Percebe que são sutilezas que criam a magia? 
Estamos falando de energia lidando com energia e estamos trabalhando em direção a uma nova visão de mundo. 
Isto é o revolucionário que estamos criando, estamos nos empenhando em gerar vibrações de tal magnitude que vai além da capacidade de reter dos dominadores. 
EStamos gerando idéias que vão além das ondas contrárias que existem implicitas em cada programa do sistema que chamamos realidade. 
Entretanto a forma de termos certeza que estamos operando dentro dos níveis sóbrios de atuação é justamente mantendo nossa ação dentro da realidade em níveis altos de eficiência 
Se aplicarmos as idéias de sermos implacáveis, isto é agir pelo agir em si, sem falsas projeçòes dos medos, carências e culpas dos egos condicionados, sermos pacientes, sem com isso sermos procastinadores , sermos astutos, sem sermos cruéis ou desleais, gentis, sem cairmos na subserviência, teremos formas de agir que nos permitiram estar presente com equilíbrio em qualquer situação da realidade. 
Assim quem usa das idéias do xamanismo para fugir de sua realidade circundante provavelmente nào vai resistir também as armadilhas dos primeiros portões do sonhar, que são os primeiros alçapões para fora deste mundo. 
Logo na saída do alçapào, há certamente classes de prisões muito parecidas, apenas levemente diferentes, formas sutis de aprisionamento que podem tentar quem se acostumou a vida em extreitas gaiolas. 
Só o firme intento de liberdade, a profunda necessidade de liberdade e uma curiosidade sem limite em conhecer tudo que há para ser conhecido tem servido de fato para levar homens e mulheres além desses alçapões edessas armadilhas e permitir-lhes lançar-se efetivamente ao vôo fora das gaiolas várias, dos viveiros em várias camadas que fomos aprisionados(as). 
Como 'pássaros por longa data presos antes de sairmos temos de treinar o voar, ou acabaremos presas fáceis dos predadores que existem lá fora. 
Ísto é o xamanismo enquanto caminho, um treinar de nossas asas e percepção para que possamos voltar a sentir o prazer da liberdade ,fora dessa gaiola perceptiva a qual nos reduziram, mas que possamos também lidar com os desafios que isso representa. 
O mundo que vivemos está em crise. 
Mas temos datas para o final desse ciclo. 
Não quer dizer que quando ocorrer a conjunção energética em 2012 um mundo acaba e começa outro, mas como a primavera chegando , a força da era de gelo terá perdido ímpeto e tudo em termos gerais contribuirá para sua derrocada. 
O terror é que os conquistadores armaram seu sistema de dominação para drenar ao máximo a força da Terra até essa data, basta observar com cuidado a destruição sistemática dos recursos naturais, a poluição do meio e a destruição da camada de ozõnio e o caos social progressivo, fazer as contas e constatar , estupefactos (as) que os conquistadores sempre souberam que o poder de sua era ia até tal data, assim criaram sua agenda oculta para esgotar o mundo até essa data. 
E cá estamos, cumprindo essa agenda oculta, para "sobrevivermos" . 
Construímos nossas covas para ganhar dinheiro para sobreviver até decretarem nossa morte. 
Parece trágico e paranóico? 
Creiam-me, não o bastante. 
AGora os EUA vem para a Amazônia, com a desculpa do combate ao narcotráfico. 
Nova Roma envia seus legionários para controlar a Amazônia. 
Sofrerão os povos nativos ainda mais, como já estão quase dizimados os povos da América Central? 
Após o oeste assistiremos nosso continente virar novo lugar " de conquista e expansionismo" , onde as populaçòes nativas serão exterminadas, onde os poucos que ousarem resistir serão mortos por novos generais Custers? 
O Xamanismo é o resgate do caminho nativo, é entrar em sintonia com um novo tempo e gerar um novo espaço existencial. 
O que precisamos sentir é que este modelo de mundo, seu modo de produzir está em colapso, cada vez mais evidente. 
A economia foi reduzida a mero monetarismo, a democracia a um jogo de classes dominantes que usam da mídia e de meios outros para tentar manter-se no poder . 
Assim podemos falar em aristocracias políticas que contrariam a própria essência do sistema que é ser representativo, ter todas suas faces representadas. 
A ciência social diagnostica mas não cura os males da sociedade urbana, que como panela de pressão incha, com riscos de explosòes constantes. 
Existe um sistema social que é resultante de um processo histórico, só que esse processo histórico foi direcionado por grupos que desejam manter seu poder sobre todos nós e isto cria uma perseguição a todos os sistemas de magia nativos, pois representam visões de mundo que contrariam a "agenda" que os grupos dominantes querem impor. 
O xamanismo é um sistema de ação válido e eficiente, que precisa apenas ser realizado em sua plenitude. 
Não pode ser visto como filosofia, nem como ciência apenas. 
Pois é comprovado que existem filósofos que investigam profundamente a realidade mas nada aplicam de suas conclusões a sua própria vida ou à realidade a sua volta, ao passo que para um (a) xamã , só é conhecimento o que ele (a) expressa em atos. 
O xamanismo é profundamente pragmático. 
É interessante que a ciência com suas teorias ideais, como as teorias químicas que estudamos no colégio, suas aproximações e agora a percepção que a percepção positivista era bastante incompleta, a quântica mudando a forma de ver o mundo, com tudo isso alguns do cmpo científico tenham considerado a priori o caminho dos povos nativos algo inferior. 
é com certo descaso que um físico clássico falaria com um xamã sobre a natureza da realidade. 
O que um pobre homem inculto, que come com as mãos, se embebeda para falar com deuses, que dança como um animal ao redor do fogo, que crê que deus está nas árvores e nas cachoeiras, o que poderia este tolo e supersticioso homem discutir com ele, homem de ciência, letrado, anos de estudo, dominando a matemática como poucos... 
Hoje um físico quântico vai estar profundamente interessado nessa história "ingênua" , para detectar insights vigorosos, oriundos de outra interpretação da realidade, que pode levar quem investiga a notar nuances da realidade que não estão ali porque as perguntas certas não foram feitas no ato de preparar o experimento. 
A qualidade de nossas perguntas , a forma como encaramos a realidade precisa ser repensada, re - sentida, re -vivida. 
TEmos um elo de conexao com a ETERNIDADE< mas precisamos antes "arrumar" a ilha do Tonal, pois se plugarmos na energia da Fonte sem ter nos resolvido antes, caíremos no erro dos antigos que se ampliaram antes de se trabalharem, indo a outros mundos com seus estilos complacentes e preguiçosos, caprichosos e auto indulgentes, resultando em seu fácil enredamento em redes de sutis caçadores que uma realidade predadora tem. 
Desenvolver um comportamente de impecabilidade, de implacabilidade, de paciência, de astúcia e gentileza a cada instante exige atenção ,e xige que de fato estejamos no momento,no aqui e agora. 
Só quando começarmos a estar de fato aqui e agora, não diluídos em passados rancorosos ou futuros ansiosos, só então começaremos de fato a entender o tempo, não decorar nomes prontos de dias e tabelas prontas, mas sentir em nossas vísceras a realidade desse mistério TEMPO.