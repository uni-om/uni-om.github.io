---
layout: texto
tags: [prática]
texto_number: 36
category: ventania
---
Date:Ter Jan 30, 2001 10:44 am
Texto:36
Assunto: Quando mil gatos(as) sonharão?
Mensagem:557
Gostaria de participar de uma inquietação com vcs.

Estava meditando, procurando sentir a Terra, sentir como os movimentos
sísmicos na India foram no Ser TErra.
Meditando sobre isso me senti unido ao Ser Terra e estava então nos mares do
Pacífico e ïndico.

Já os sintonizei antes, quando das explosões nucleares , os testes, da
França, em suas "colônias" . Nosso clã, em conjunto com outros, trabalhou
magicamente para ajudarmos o SER Terra a metabolizar a tremenda energia que
é liberada com a explosão.


O ser humano que enverada por este caminho dos senhores da guerra acaba
perdendo toda a noção de decência e respeito a vida, pois testar algo com
tal poder com a clara intenção de que isto seja uma arma, isto é, destruir
vidas, é estar por demais distanciado de qualquer chance de se dizer humano,
em coisa foi transformado , em coisa que odeia a vida, que provavelmente
desconhece o amor e então odeia toda sua espécie e faz da guerra, antes um
confronto entre heróis, um jogo de mercenários, onde a vida , a VIDA, com
toda sua singularidade, com toda sua magia, é posta a serviço de interesses
mesquinhos e sacrificada.

O que me preocupa agora?

Os testes nucleares são feitos em poços submarinos.
Como é esse teste?
Um fosso é aberto, lá dentro uma bomba instalada e sensores são colocados,
depois tudo é lacrado com materiais que devem deter a radioatividade.

Explodem a bomba.
E dentro do poço lacrado, por coisa de 500.000 anos, ( QUINHENTOS MIL ANOS<
tem noção o que é isso ? PERPLEXIDADE!!!!!!) a radiação vai ficar ali,
pronta a contaminar tudo que é vivo. TEStes criam containers de radiação,
fora os efeitos que tem sobre a estrutura energética do planeta, aspecto que
é completametne ignorado.

TEmos todos em nós resíduos das experiências nucleares feitas em desertos e
áreas como florestas na antiga URSS, onde se conta que soldados foram
mandados marchar sobre a área ainda em chamas após a explosão da bomba, para
avaliarem os os efeitos da radiação.

A realidade vida nem é levada em consideração.
Imaginem um desses soldados, um jovem, cheio de vida, de curiosidade sobre o
mundo e seus mistérios, devia amar alguém, ser amado e então vai a um
treinamento, lhe dizem que vão treinar combate em meio a um incêndio.
A adrenalina ferve com seus amigos, seu bando, a energia jovem que flui em
suas veias , o poder do sonho que tem então vão ao treino, alguns se
machucam , outros julgam que se saem bem, mas então.

Cabelos caem, feridas abrem e nao fecham, cânceres dos mais diversos e
horrendos tipo, demência, perda imediata da vista, dores que nem a morfina
remove.

Seres humanos passando por isso.

ALgo mais recente, Guerra do Golfo.
Ali usaram um tal de urânio empobrecido, para revestir munição, aumentando
seu poder de furar blindagens,
Soldados estão morrendo, doentes, vidas condenadas e o governo dos EUA não
os indeniza porque oficialmente esta doença não existe.
Isto é imoral e está agora acontecendo na chamada "Pátria da Liberdade" que
em breve estará enviando tropas para invadir a floresta, onde nossos povos
irmãos ainda vivem.
Vamos deixar que transformem a Amazônia em seu novo oeste? Que novos
generais Custers venham dizimar o que ainda resta dos povos nativos?

TEmos muitas coisas acontecendo ao nosso redor que precisam de um pouco de
nossa atenção, no sentido ativo da palavra, no sentido de agirmos de alguma
forma coerente para que geremos ondas de energia rumo a uma outra
possibilidade existencial.
Isto é o que os (as) Xamãs da Tribo do Arco ÍRis propõe.

Uma ação focada , objetiva e mágica.

TEmos a realidade a nossa volta, uma das muitas realidades que podemos
abarcar.
Mas no xamanismo guerreiro, não nos deslocamos fugindo desse mundo antes de
resolvermo-nos aqui e agora.

A estratégia de treinamento dos(as) xamãs da atualidade começa pelo
desabrochar de suas habilidades na realidade que estão inseridas.

Por um conjunto de fatores que nunca mensuraríamos todos, vc nasceu num
certo ponto do tempo e do espaço.
TEve um familia com toda uma história e tem toda uma históricidade que te
traz até este momento existencial, no qual está lendo este mail.

Este conjunto de situações aos quais vc foi exposto foram gerados pelo TAO,
pelo INTENTO, em si mesmo, sem nenhuma intereferência.
Assim , os (as) xamãs sacaram que o primeiro e mais eficiente campo de
treino e teste é a vida cotidiana, é o conjunto de eventos , de situaçòes
que ocorrem conosco que foram ali colocadas pelo próprio TAO.

Dentro desta idéia sempre me ocupo com a realidade do mundo circundante e
este foi o tema que me levou a escrever este mail.

Os testes nucleares em fossos.

Agora toda esta radiação está dentro de um fosso cavado em rocha e revestido
e tal.

Os últimos testes da França foram nos atóis que tem certa proximidade com a
Índia, local de forte terremoto.

NÃo poderão terremotos deslocar e mesmo desmoronar a proteção desses poços
criando fissuras que podem liberar a radiação no mar?

Imaginem a potência das bombas que esses loucos testam nesses lugares.

E o efeito nas placas tectônicas e seus delicados equilíbrios.

As vezes gostaria de acreditar que existe mesmo um governo secreto, uma
conspiração oculta para destruir a humanidade ou impedir que nos
equilibremos para receber focados e consciente a energia que está vindo de
Hunab Ku., por que a opção a esta hipótese, de um governo em conluio com
forças que são hostis a vida, é perceber que tudo isso é pura estupidez
humana, movida pelo orgulho e arrogância de alguns.

E conivente com esta destruição toda a humanidade, tornada estúpida e
alienada de si, por ato ou omissão colabora com esta agenda de esgotamento
do Ser Terra..

Quando mil gatos/as sonharão?