---
layout: texto
tags: [mapa]
texto_number: 37
category: ventania
---
Date:Sex Fev 2, 2001 3:28 am
Texto:37
Assunto: En: [Entre_Mundos] Lammas
Mensagem:562
Lammas

A Festa Solar.

Para um povo profundamente ligado a Terra e a suas benesses imaginem que
momento triunfal era o momento da colheita.
A certeza da comida, do trigo, do arroz, do milho,enfim da espécie que
aquele povo escolhera para ser seu alimento base.
Ao lado da caça a colheita era a garantia da vida.

Enquanto a caça era uma luta com outras espécies, a colheita veio como o
domar da Terra, como a caça foi domada e tornada rebanho.

E então, todo ano, vinha o tempo da colheita.
A semente foi plantada, foi evocada a força dos Deuses, das Deusas, da
natureza, cada um dos que vivem num clã sabe que sua própria sobrevivência
depende da colheita, assim é com total gratidão que se vai a colheita, com
a certeza que o resultado do árduo trabalho, do arar da Terra, do cuidar da
planta, tudo aquilo agora está presente ali, naquela espiga madura que vai
ser colhida e transformada em alimento, estocada para os momentos de seca
ou frio, de acordo com o local onde vive esse povo.

REsgatar esse sentimento de perceber a Terra, como nossa doadora de Vida
em tantos níveis e sentidos é fundamental para uma celebração de Lammas.

Lammas é receber, é ter da Terra o resultado de nosso plantio, é hora de
reavaliar nossa vida, fruto de nosso plantio diário e ter a coragem de
mudar definitivamente naquilo que não nos leva a crescer nem a viver melhor.

Por hábito, preguiça ou vaidade acabamos por vezes repetindo o mesmo
estilo de vida que apenas nos mantém distante de nossas metas, assim é na
colheita que também nos percebemos enquanto plantadores e podemos aqui nos
propor a sermos de fato a chama que trazemos em nosso peito, não as
programações que nos mandaram ser.

Lammas.

Os festivais pagãos não podems e resumir a festa de um dia.
Nenhum povo colhe tudo em um dia.
A festa dura durante toda a colheita, é uma festa que vai da lua
crescente
até a Lua Cheia, é claro que não podemos medir uma festa pagã pelo
calendário gregoriano.

Por isso todo esse ciclo, até a Lua Cheia, para quem celebra o paganismo
telúrico, o paganismo ligado a força da Terra onde estamos, é momento de
celebrarmos as festas da primeira colheita .

De agora ,até o outono chegar com sua força de recolhimento, colheitas
das mais diversas acontecem.

ESte poder manifesto é o poder da maturidade

Se na Primavera a Virilidade do Chifrudo era festejada e sentida, agora
é sua força madura, manifesta, presente, calma e ao mesmo tempo profunda,
como um rio profundo, de correntezas intensas e que ainda assim apresenta calma
superfície, como a fogueira crepitante, bela e intocável.


A Deusa está pródiga, está também plena e a Face da Mulher plena se
manifesta, depois que a Jovem fogosa da Primavera veio com seu poder
redespertar quem dorme, animar a vida de quem no frio e árido inverno
ainda estava.

Com a Colheita farta a vida se torna mais tranquila, por isso agora é um
tempo que o homem e a mulher que araram a Terra, puseram a semente,
velaram o broto, apoiaram a tenra planta e vigiaram a espiga amadurecendo, ao
colherem, teu seu sono tranquilo , tem seu descanso merecido, pois a
colheita veio.

A esperança da colheita, contida na semente , se realizou.


Celebrar Lammas é preparar um bolo , de milho.

Começar queimando alecrim, deixando a fumaça rodar a casa, varrer toda a
casa,d o fundo prá frente, com a vassoura de poder, é tomar um banho com
suas ervas de poder e colocar sua roupa de TRABALHO.

É ralar as espigas , enquanto prepara sentir que o milho foi semente,
ousou ir além, aprendeu como raiz , ousou sair da Terra e ser broto,
cresceu
e no milagre de sua existência, o grão virou espigas, espigas que ralamos
com amor e carinho , agradecendo e honrando a Deusa e o Galhudo que com
seu poder tornaram aquela magia , o milho que nos alimenta, possível.

Assar o bolo e então servir, para pessoas queridas, deixando um lugar
vago` à mesa, onde deve ser servido o bolo para todas as forças da
Natureza que fizeram da semente espiga.

Em todo esses momentos o foco no poder daDeusa e do Galhudo nos levam a
celebrar em sintonia.

É em Lammas que consagramos novamente a colher de Pau.

A colher de Pau é consagrada a força da Virilidade do Galhudo, quando na
primavera, agora é a força da prosperidade e da prodigalidade do Galhudo,
à força do Sol Maduro, do Sol de Meio dia que é consagrada a Colher.

Dentro da Bruxaria telúrica consagramos a colher e o caldeirão aos
Quatro Aspectos, isto é as quatro energias, uma de cada estação, do Galhudo e da
Deusa.

O caldeirão agora é a cornucópia pródiga da Deusa, no Caldeirão o fogo
simboliza a Deusa Dragão, a Mulher que trás o fogo em seu Útero, que gera
sonhos e mundos.

Na primavera a jovem deusa dragão trazia o fogo sendo expelido, seu
poder era externo, a Deusa dragão em sua face madura está tranquila, serena, em
seu útero repousa o poder do Fogo celestial e Telúrico .


É Lammas, a promessa da Semente se cumpriu, a esperança se renovou, a
vida continua , ainda podemos ir além dos limites que nos foram impostos e
realizar plenamente a Chama que trazemos em nossos peitos.