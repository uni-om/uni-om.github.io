---
layout: texto
tags: [mapa]
texto_number: 38
category: ventania
---
Date:Qui Fev 8, 2001 4:59 pm
Texto:38
Assunto: REflexões
Mensagem:574

Saudações Ventania; 
Nuvem que passa em contato via Mail da Cris; final de tarde, após um dia de muito trabalho agora partilhando com vcs, alguns questionamentos. 
Hoje foi um daqueles dias que deu prá sentir bem a diferença entre o "paganismo" , o ritmo pagão de viver e a "urbes" cidade, ritmo urbano. 
Acordei bem cedo, ainda no interior de Minas, caminhei pelas trilhas em volta da cidade, fui tomar água na nascente, subi pelo pasto até chegar de volta na cidade, céu aberto, claro, vento bom, calor crescente, ar puro, natureza forte a volta. 
As pessoas indo num ritmo calmo e tranquilo para seus afazeres. 
Voltei para a casa onde fico com total sossego, em harmonia com a Vida e seus fluxos. 
Então aproveitei a carona com meu primo e viemos para Sampa. 
Chegar em Sampa, dormi durante o caminho , de repente estava em Sampa. 
TRânsito na entrada, engarrafamento, rio com um mau cheiro terrível, rio morto, sem vida, pessoas estressadas, neuróticas, carros jogando poluentes na atmosfera. 
É isso que chamam de "progresso e civilização" 
Fomos presos num mito, um mito de supremacia, o mito de que estamos no "único mundo possível" , o mito de que todos nós temos que "deixar acontecer" o que está aí, porque não podemos fazer nada para mudar e então arrumamos uma desculpa para aliviar nossa própria consciência e ficamos acomodados onde estamos. 
O fato que vivenciamos é que este modelo civilizatório chegou no seu limite. 
EStamos no limite, estamos num nível de degradação ambiental e social que não dá prá permitir que as coisas continuem como estão só por falta de coragem em mudar. 
E onde começam as mudanças? 
As mudanças começam em nossas posturas, em nossas atitudes, são nossos atos e não nossas palavras que podem mudar o mundo efetivamente. 
Herdamos um cinismo tão gritante das tidas filosofias existencialistas que o ser humano, ao reconhecer seu real papel de nada e efêmero frente a eternidade ao invés de transformar esta constatação em um meio de se alavancar rumo a auto realização, apenas ajudou no fortalecer desse homicida egoísta que a maior parte das pessoas parece gostar de ser. 
Havia um sentimento de "stand by" até o ano 2000. 
As pessoas estavam na "sindrome do milenarismo" o mundo estava mesmo se aproximando do fim, ia acabar tudo mesmo, alguém lá de fora viria nos salvar e tal. 
Mas estamos em 2001, a data das profecias se foram , estamos em pleno século XXI e agora é hora da gente perceber que só nós podemos trabalhar ativamente por um mundo melhor, através de atitudes concretas . 
Um risco que vejo em certas interpretações do calendário maia e' que 2012 virou um novo milenarismo e podemos ficar presos de novo em fantasias sem fim, nos esquecendo que o Sol da Primavera pode vir, mas o sucesso da colheita depende da semente ter sido preparada e este é o nosso papel. 
É assim que mil gatos(as) vão sonhar, sonhando acordado, agindo, não apenas elocubrando complicadas teorias , fazendo como os teóricos que alinham o mundo em sofisticados modelos, mas se retiram do escritório ao final do expediente, deixando trancado ali todo seu sofisticado modelo de mundo, lidando com a realidade com a mesma perfomance de quem nunca teve um momento de reflexão na vida. 
Por isso o Xamanismo é antes de mais nada um caminho de despertar, sem despertarmos desse estado hipnótico no qual nos encontramos vamos servir sempre a esta " Matrix" que é apenas a "descrição" da realidade que aceitamos. 
TEmos que tomar muito cuidado para não cairmos em posturas neuróticas crendo que a Matrix seja algum ente todo poderoso a nos perseguir, que estamos "sendo vigiados" ou algo assim. 
A MAtrix é um simbolismo forte para todo esse condicionamento que recebemos, mas grande parte dele é apenas fruto da estupidez humana, cuidado para não cairmos em paranóias nesse termo, fantasiando coisas sem sentido e querendo que essa fantasia seja xamanismo. 
Precisamos ter muita estrutura para lidarmos com estes outros niveis de consciência, ou vamos mesmo nos confundir irremediavelmente. 
Por isso insisto tanto que só após resolvermos de verdade o aqui e agora podemos ir ao além, do contrário não teremos base para lidar com aquilo que está além de toda a descrição. 
Lidar com a mudança de nós mesmos é algo realmente muito complexo e não pode ser feito com base em "achismos"" muito menos por mera "boa vontade" . 
É muito dificil de fato mudarmos. 
Temos TV, rádio, revistas , jornais, enfim um sem número de "agentes" tentando nos programar com o que pensamos . 
Mas só vamos mesmo vencer tudo isso se começarmos a nos observar de fato, aqui e agora , a cada instante, para que possamos saber o que é real e nào o que fantasiamos ser real. 
Algumas reflexões antes de pegar um trânsito bravo até Cumbica.