---
layout: texto
tags: [pérola, mapa, prática]
texto_number: 39
category: ventania
---
Date:Dom Fev 11, 2001 9:25 am
Texto:39
Assunto: Pontes
Mensagem:582

Olá Ventanias; 
Vamos trocar algumas consideraçòes. 
ESTa mensagem enviada sobre a "morte" de D. Juan é fantástica, quando li este livro fiquei meio em estado de choque, eu já tinha vivido minha morte , um dia conto sobre isso, faz parte daqueles assuntos que tenho um "pacto" de só falar depois de 2005. 
O que sinto é que só depois dessa morte podemos dizer que estamos mesmo no mundo dos(as) xamãs , antes disso estamos abordando o tema, mas de uma forma que sempre é possível desistir de tudo e voltar para a pseudo segurança de uma vida "normal" . 
Queria explicar que o seu fracasso fora devido a não saber que os feiticeiros nunca podem construir uma ponte para juntar-se às pessoas do mundo. Mas, se as pessoas desejam faze-lo, devem construir uma ponte para juntar-se aos feiticeiros . 
Por favor, os "xamãs sindicalizados" poderiam falar um pouco sobre o assunto? 
SE tomarmos "sindicalizados" como conectados ao ESPIRITO, vamos aí. ; - ) 
r* Isto me lembrou a passagem de "A bruxa e a arte do sonhar", onde a feiticeira Mercedes se apaixona pelo homem que mais tarde traria a morte do seu filho e marcaria a sua vida para sempre, num momento de dor e sofrimento. 
Uma das coisas mais complexas de compreender no xamanismo guerreiro é que ele não é para todos. 
Por isso nada mais aberrante que tentar fazer proselitismo do Xamanismo, nada mais aberrante que tentar convencer outras pessoas a se aproximar do caminho. 
O preço tremendo que precisa ser pago para entrar no Caminho não pode ser pago por todos e só alguém já completo em si pode ajudar outra pessoa a este transitar rumo a nova condição de vida que caracteriza o mundo dos (as) guerreiros(as) xamãs. 
O caminho dos (as) guerreiros(as) foi desenvolvido como forma de estruturar o ser para suportar o lidar com a Vastidão da Eternidade. 
ESTá impregnado do Intento dos antigos(as) Xamãs e trilhá-lo significa deixar progressivamente para trás toda a condição de vida enquanto "humano normal e padrão". 
O caminho do(a) Guerreiro (a) é solitário. 
Nascemos sós, morreremos sós, se não soubermos mudar nosso destino, assim não é algo acabrunhante ser o caminho solitário, é um fato. 
O caminho não é triste nem deprimente, aliás ser triste e deprimido é o tipo de capricho que não funciona no Caminho, ao nos reconectarmos a Terra enquanto ser vivo e consciente afastamos de nós toda chance de tristeza e passamos a viver num nível de plenitude indizível a quem ainda não cruzou essa fronteira. 
Quando começamos a trilhar o Caminho estamos nos distanciando das condições normais de vida, que são as condições dos escravos, uma vez que é nítido ser este mundo um mundo de escravos, em níveis dos mais diversos. 
NÃo vou nem comentar, mas só citar, o fato que a humanidade está numa condição bem desfavorável, devido a natureza predadora da Eternidade, esta a humanidade com sua viagem pela Eternidade interrompida, presa nessa condição que chamamos realidade. 
Deixando progressivamente a condição de escravo(a) fica díficil partilhar dos mesmos objetivos de quem julga que o mais importante é alimentar a importÂncia pessoal, é competir com tudo e todos, é dominar, é ter o carro do ano, a roupa de griffe e outras tolices mais. 
Por isso os (as) guerreiros(as) usam da "loucura controlada" , sabem que o mundo é uma loucura sem par, mas ao invés de ficarem dando murros em ponta de facas, ao invés de agirem como rebeldes sem causa e ficar gritando para o mundo o que ele nao quer ouvir apenas continuam suas vidas, em seus próprios termos e quem vive ao lado pouco ou nada percebe as maravilhas que um (a) guerreiro (a) já presenciou em seu Caminho. 
TEmos que começar resolvendo nossa vida cotidiana , não adianta fugir dela, aliás é no contexto bem comum que temos os maiores desafios. NÃo se trata se ficar limitado ao mundo cotidiano, mas fazer dele nosso primeiro campo de treino. 
A medida que caminha um(a) guerreiro(a) sabe que sua vida comum ficou para trás, sabe que os arranjos perceptivos que o caracterizariam como alguém normal , ficaram para trás e um novo mundo, desafiante e predador se abre a sua frente, um mundo que pode se abrir de repente e destruir o (a) guerreiro de formas diversas. 
Assim ninguém pode convidar ninguém para trilhar o Caminho, isto é loucura não controlada, pois só o ESPIRITO pode decidir quem tem ou não condições para realmente enfrentar esta empreitada. 
ASsim os (as) guerreiros (as) xamãs só agem por sinais, por augúrios, por presságios, nunca por palpites ou achismos pessoais. 
Existe uma frase no mundo de D. Juan Matus que choca alguns: 
"Voluntários não são bem vindos" . 
TEnho meditado muito sobre isso e na minha prática pessoal confirmado isso com constância. 
Existem pessoas que se aproximam do caminho, mas nao querem agir como o Caminho recomenda, querem adaptar tudo a seus "achismos", tais pessoas já acham que sabem tudo, que tem tudo pronto, só vão "pegar algumas coisas e adaptar a sua forma de ser" . 
Hora é para essa " minha forma de ser" que preciso morrer antes de mais nada, pois tudo que chamamos "eu" ao chegarmos ao Caminho é fruto do condicionamento que recebemos. 
Quando estudamos profundamente o Caminho vamos descobrir que o que somos quando Nele chegamos é fruto de um condicionamento que apenas nos faz células de um vasto organismo social no qual estamos inseridos, onde tudo que chamamos de "emoção" , "razão" , meu "estilo de vida" e "eventos da minha vida" é apenas o metabolizar de substâncias cósmicas que estão vindo da Eternidade e indo prá Terra e vice versa. 
É muito dificil que alguém aceite isso, que todas suas "caras" emoções, seus "intelectualismos" que todas suas reações na vida, que julga ser tão "suas" tão "próprias"é apenas uma forma de metabolizar energias que chegam dos astros, planetas e de fontes outras para o SER Terra. 
O ser humano nem existe enquanto ente singular quando chega no Caminho, tudo que pode vir a ser depende de seu trabalho. 
Gostaria de lembrar que para choque completo de muitos Xamanismo Guerreiro não fica preso a idéias de "outras vidas" nem considera que exista uma "dimensão espiritual" melhor que esta. 
É um trabalho árduo e pode ser mesmo mortal, tentar entrar na Trilha do Guerreiro(a). 
Conheçi pessoas que enlouqueceram, que morreram mesmo nas batalhas do Caminho, portanto seria muito terrível se nos alinhássemos aos esohistéricos de plantão e colocássemos o Xamanismo Guerreiro como um caminho desses insonsos a mais, onde "ficamos bons e evoluímos através das vidas " e fantasias outras . 
EStamos falando de algo que está fora dos paradigmas dos "esoterismos " ocidentais conhecidos, se formos encontrar similitudes entre o Caminho do Guerreiro e outras abordagens que buscam levar o ser humano para fora de sua condiçao de escravo teremos que ir ao Taoismo por exemplo. 
Aí chegamos a frase : os (as) guerreiros não podem estender pontes a quem está no mundo, se as pessoas quiserem estender estas pontes tudo bem" . 
É um fato, a carência fundamental de nossa condíção humana, quando má resolvida, nos leva a estilos de vida dos mais tacanhos, ficamos a vida toda procurando "amor" , " afeição " e esquecemos que só quando estivermos mesmo inteiros e plenos poderemos AMAR< que é algo muito diferente desse emocionalismo hormonal que as pessoas lidam. 
O passaporte de um (a) guerreiro(a) para o mundo do poder é sua morte. 
Esta colocação deve ser lida com muito cuidado, daqui a pouco tem gente se matando , risos, sim o ser humano adora fazer bobagens para seguir idéias prontas. 
Só pode morrer quem está vivo, portanto a primeira coisa que um (a) guerreiro (a) faz é acordar no aqui e agor, é estar vivo(A) no mundo cotidiano. 
E o que vejo é que as pessoas querem fugir, tem medo de serem "normais" , de terem vidas "normais" . 
E onde está a primeira magia senão no dia a dia, senão no cotidiano? 
Só quando nos resolvermos nestes níveis poderemos 'ir além deles. 
Outro problema é que adoramos usar as pessoas como desculpa para nossas covardias. 
Não faço isso porque tenho filhos(as) , tenho mulher(marido) , meu pai(mãe) depende de mim e uma série de desculpas onde colocamos o outro como desculpa ou motivo de nossa inabilidade em irmos além dos limites nos quais estamos. 
Por isto é que um (a) guerreiro (a) não estende pontes, está ciente de seu caminho e dá o melhor de si para percorre-lo.