---
layout: texto
tags: [mapa, prática]
texto_number: 40
category: ventania
---
Date:Dom Fev 11, 2001 11:19 am
Texto:40
Assunto: O desafio do Aqui e Agora
Mensagem:583

Os (as) guerreiros(as) xamãs , buscam para si os melhores campos de treinamento, onde possam desenvolver suas habilidades a fim de desenvolverem um conjunto de estilos de ação que lhe sejam úteis quando estiverem em suas viagens pela Eternidade. 
Os (as) xamãs descobriram que o melhor campo de batalha que pode existir é exatamente onde estamos, pois fomos colocados ali por forças alheias a nossa. 
Assim estaremos lutando com o que não temos controle. 
Situaçòes que nos mesmos criamos são sempre de alguma forma , condencendentes. 
ESte é um dos papéis dos que podem ajudar outros na Trilha do Guerreiro(a) , criar situações de treino as habilidades de quem começa a trilha, mas lembrando que só quem perdeu a forma humana pode mesmo ajudar alguém, do contrário será a velha his'toria do querer impor ao outro o que julga certo para si. 
Por isso, o melhor ao invés de ficar delirando com idéias tiradas de filmes de ficção e livros que lemos , mas pouco entendemos dos cernes abstratos e nos perdemos na "letra que mata" é bom olhar em volta e perceber o fantástico campo de treino que a ETernidade deixou a nossa volta, as pessoas que aqui estão fazem parte deste momento é hora de aprendermos com ela ao invés de ficarmos em crises , que são apenas projeçòes de crises que temos conosco mesmos. 
Este me parece o desafio, o resto é fuga