---
layout: texto
tags: [mapa]
texto_number: 41
category: ventania
---
Date:Seg Fev 12, 2001 11:11 am
Texto:41
Assunto: Re: [ventania] Pontes
Mensagem:589

Oi Guerrero...:-) 
Oi Cabelos de Fogo; 
Tudo bom, amigo? 
Brilho de olhos, respiração profunda, trilha sonora de Conan no fundo, manhã fria, gostosa, um beija flor esteve a pouco nos jasmins da janela, aqui e agora, tudo excelente, amiga. 
De fato, a mudança, a chamada "morte" acontece das formas mais inusitadas. Percebo que diversos fatos vão se acumulando e, de repente, há uma aceleração, que nos desloca para bem longe. 
Seria impressão minha ou as mulheres se reciclam com mais facilidade? 
Com muito mais facilidade, a fluídez da mulher é incomparável, nós homens precisamos de muito treino e árduo trabalho para chegar onde a mulher naturalmente está. 
Se notar bem todas as religiòes dogmáticas e baseadas na luta pelo poder afastaram a mulher de seu centro. 
O Islamismo em seus ramos mais ortodoxos chega a níveis de violência brutais contra a mulher em nossos dias mesmo, o cristianismo, onde a mulher pode ser apenas virgem ou mãe, onde as mulheres tidas por santas ou admiráveis são sempre as que se submetem a um Deus machista e opressor, ou a seus profetas e desde Eva com a maçã , passando por Dalila e Salomé, é sempre pela mulher que o mal vence , o Judaísmo, onde apesar da linhagem ser determinada pela linha materna e a mãe ter uma influência tremenda nos arranjos familiares ( nos EUA existem muitas piadas sobre màes judias levantando esse lado) tem profundos preconceitos quanto à mulher aprender sobre as escrituras ou a Qabalah. 
Em todos esses ramos a mulher é impedida de exercer o sacerdócio e é sempre considerada secundária, de forma óbvia, ou dissimulada. 
Assim a mulher em nossa cultura sai para a batalha do Conhecimento com o mesmo peso que a raça negra sai para a batalha da igualdade social. 
Pesa-lhes as costa , uma escravidão longa e desfigurante de sua própria e bela natureza, de suas reais forças e formas de ser. 
Estão alienadas, pois foram alienadas e muitas vezes tudo que uma mulher tem para ser forte é o exemplo de homens que admira, mas são fortes pelo modo dominador de ser, assim temos mulheres que para manifestarem a tremenda força que trazem em si negam sua feminilidade e se tornam "homens de saias" . 
O caminho feminino foi perdido de forma tão profunda que hoje assistimos até mesmo movimentos voltados para a Deusa impregnados de conceitos nitidamente masculinos, quando não piores, pseudo masculinos, pois , não pensem que foi apenas o feminino que foi deturpado pelos conquistadores, mas também a própria masculinidade, confundida com machismo agressivo e dominador. 
Pois a feminilidade, o poder do feminino permeia a própria Eternidade e quando a mulher é completamente feminina seu poder é naturalmente uno com a Eternidade. 
É como se nós homens tivessemos baterias que se carregassem com a energia solar, assim quando estamos plenos de carga nossa energia é potente e plena. 
Para as mulheres seria como ter aquelas células foto voltaícas que transformam a luz solar diretamente em energia, sem precisar estocar. 
Por isso que num grupo de xamãs guerreiros (as) se tem sempre o dobro de mulheres que de homem. 
Pequenas mortes, pequenos recomeços, a cada lua, cada vez que entrega seu sangue à terra... Faz sentido? 
O poder da menstruação. 
A mulher adquire um poder tremendo quando está menstruada. 
Nas mais diversas tradições existem tabus no tocante a menstruação. 
Me parece aqui que a mulher abre um poder tao amplo, tão grande , tão inconcebível e incontrolável a nós homens , que o tabu foi posto principalmente por medo. 
As mulheres tem TPM porque não sabem controlar seu poder. 
Minha irmã praticante de TAi CHi Chuan nunca teve TPM , como irmão convivi o bastante com ela para confirmar isso. 
Para ela a chave está em fazer a energia sempre fluir da forma harmônica e devida. 
ESte é um tema para ir mais fundo noutro momento, o poder da menstruação. 
A mulher, ao contrário do homem, tem todo mês um período em que não é fértil, ou seja, naturalmente ela é desligada do impulso biológico de reproduzir. 
Um homem do começo ao fim de sua capacidade reprodutiva ativa, embora tenha ciclos mais fortes e menos fortes, está sob o controle do impulso biológico: 
"Misture os genes" "REproduza" . 
A mulher tem um período todo mês que não. 
Isto lhe dá um poder que poucas usam , pois não tiveram a chance mínima que para os (as) xamãs guerreiros (as) é saber que isso acontece. 
As sonhadoras nesse período vão a lugares díficeis de as acompanhar e as espreitadoras, é um prazer ainda maior conviver nestes momentos com elas, os véus dos mundos se abrem . 
Isto também me lembra os rituais onde cortamos os cabelos, mudamos de nome ou somos trancados em câmaras escuras. Todos fazem alusão à morte ou ao novo ser que passa a existir. 
Os caminhos iniciáticos plenos começam com testes para sentir se quem vem aprender está de fato pronto, depois uma fase de aprendizado e então o momento definitivo onde o(a) neófito morre par a antiga vida e começa uma outra. 
Isso virou mera formalidade em muitos cultos e ritos, onde as pessoas cortam uma mecha "simbólica" do cabelo, fazem algum retiro pró forma, e "descobrem" algum nome rocambolesco, que diz mais a seu orgulho que a sua essência. 
Nos caminhos que respiram os ares ancestrais a mudança é real , nos caminhos que apenas induzem a um sono mais pesado e roboótico é meramente formal. 
É muito sério esse ponto da mudança. 
Quando nascemos nascemos com um "destino" . 
O destino é resultante do script que os poderes que nos criaram desejam que representemos aqui. 
ESte ser que nasceu nasceu para morrer, é um dos únicos fatos certos. 
Pois bem, temos então que deixar que ele morra e renascermos, de nós, por nós , para a LIBERDADE. 
Sö quando nascemos de novo podemos caminhar rumo a Liberdade, pois no segundo nascimento nascemos por força da VONTADE< alinhada com o INTENTO. 
Assim , não é mudar de nome, raspar a cabeça, ficar preso em algum lugar ou qualquer ato externo que de fato determina isso, os atos externos sao apenas apoio, apenas símbolos, apenas sustentáculos para algo muito mais profundo e real que está de fato ocorrendo. 
EStamos invalidando nossa antiga continuidade e tudo que dela faz parte para de fato iniciarmos uma nova vida. 
Venho aprendendo que em todo processo de transformação o mais importante é o intento. É como se o mundo em volta, de repente, se adaptasse à realidade interna que passa a atuar em nós. Como o que chamamos de "realidade" é maleável, ela se molda de acordo com o novo ponto de coesão dos nossos objetivos. Já dizia o mestre da ordem: o verdadeiro iniciado pode entrar em qualquer lugar a qualquer momento porque ele é quem influi no ambiente e não o ambiente nele. Faz sentido... 
O poder pessoal de cada um é tudo que determina suas possibilidades de realização. 
Tudo que temos é nosso poder pessoal . 
Sem a pretensão de ser "verdadeira iniciada", tenho testado estas teorias na prática e observado os seus resultados. 
Iniciado(a), 'por definição, é quem se iniciou , quem está dentro de um processo de trabalho, iniciado não quer dizer "realizado(a)" quer dizer o que diz: iniciado(a), no budhismo usam um termo muito interessante: entrou na correnteza. 
Outro ponto que vc comenta e que achei interessante "pitacar" foi em relação à mudança de valores: 
Deixando progressivamente a condição de escravo(a) fica díficil partilhar dos mesmos objetivos de quem julga que o mais importante é alimentar a importÂncia pessoal, é competir com tudo e todos, é dominar, é ter o carro do ano, a roupa de griffe e outras tolices mais. 
Bem, será sempre assim? Fico aqui imaginando o seguinte: para quem está muito longe de poder competir, de dominar, de ter carro do ano e roupa de griffe, não seria vantagem alguma não dar importância a estas coisas, não? Eu tenho a impressão que o mundo se manifesta de uma forma estranha e misteriosa... vivemos em um tempo onde a maioria das pessoas se voltam para o materialismo: os pobres querem ficar ricos, os ricos querem ficar mais ricos e ambos desejam carro do ano e roupas de griffe... Então as regras costumam ser feitas para a maioria. Mas talvez, em algum ponto da história, o mesmo desejo que faça estas pessoas correrem atrás de seus carros e roupas falte em pessoas que se conformam muito facilmente com o que têm. 
Tanto quem corre atrás por desespero, como quem se conforma com o que tem estão apenas se entregando a algum capricho. 
Para quem tem outras metas isto nem é levado em consideração. 
Dei estes exemplos para exemplificar como os valores diferentes de quem trilha o caminho podem nos tornar aparentemente "frios" e "insensíveis" para quem ainda tem isto como importante. 
Podemos ir mais longe, podemos ser cruéis, para algumas pessoas, por não darmos a mínima para os profundos dramas de suas vidas, que batendo o olho sacamos que não existe, que foi apenas a pessoa que criou tudo aquilo para ela mesma para chamar a atenção. 
Por isso temos a Gentileza como equilibrio da Implacabilidade. 
Ser gentil é diferente do conceito clássico de bondade. 
A Bondade clássica está sempre associada a algum tipo de ganho, aqui na terra ou no "céu" , um bom karma, tem sempre um ganho. 
A Gentileza é um conceito oriundo da essência do Caminho do (a) Guerreiro. 
É o ato feito expontaneamente , sem espera de nenhuma recompensa, nenhum retorno, é um ato sem nenhum propósito ulterior de ganho, um ato feito e oferecido ao ESpírito. 
O resumo desta idéia seria: muitas vezes por trás do materialismo e da ambição existe um componente que pode ser muito útil no caminho do guerreiro e que não existe em pessoas que não são muito fixadas em valores materiais. 
Por tra's de uma emoção desregulada, uma pessoa muito agressiva por exemplo, por trás de uma pessoa obstinada, atrás de toda uma luta desvairada pelo ter, sim atrás de tudo isso pode estar a energia que podia estar sendo usada para os propósitos de um (a) guerreiro(a) e por desconhecimento acaba sendo gasta nos estilos que o mundo ensina. 
Aqui está um dos pontos mais díficeis de uma pessoa que treina outras. 
TEm que saber ajudar o (a) treinando (a) a eliminar o estilo de comportamente destrutivo , sem destruir essa energia tremenda, que será útil quando bem canalizada. 
Muitos caminhos reprimem a pessoa e então bloqueiam tal energia, por vezes de forma muito prejudicial à própria vida cotidiana da pessoa. 
Seguindo esta linha de raciocínio, fica claro que quem não consegue manter a casa em ordem e ganhar o mínimo para o seu sustento está longe de ser um "xamã sindicalizado". 
Sim. O Sindicato dos(as) Xamãs guerreiros (as) tem uma noção clara que precisamos ser eficientes aqui e agora, para depois começarmos a tentar ir para outras realidades. 
Bem aplicadas, as noções da espreita e do conhecimento silencioso levam necessariamente nossa vida a graus de auto suficiência progressivos. 
Isto não significa que não possam acontecer revezes, perdermos tudo e termos de começar tudo de novo. 
As vezes, se tu sinceridade e propósito no Caminho são efetivos, nós mesmos provocamos isso, se formos realmente fluídos e seguirmos os sinais do Intento. 
Vou lhe dar um exemplo pessoal: 
Estava com todo um projeto pronto no sul do país, quase indo morar lá, em Porto, com trabalhos em 'varias cidades na Serra e nos Pampas e tudo com muito retorno financeiro, alto mesmo e de repente os sinais vieram: se afasta dali, 'não é momento, " volte mais tarde" . 
Sinais sutis como hipopótamos flatulentes em loja de essências florais! 
Sumi de lá, tem gente que gostaria de comer meu fígado por lá, especialmente o pessoal que gosta de se dizer "iniciado" depois de um curso e que te aluga como alegoria, risos. 
Muitos me consideraram irresponsável e dentro do padrão deles fui mesmo. 
Mas alertas são alertas, e se o fosse a Caçadora Suprema que nestes dias estaria por ali? 
Os sinais precisam ser seguidos é a única coisa que existe depois que os escudos do mundo não mais servem. 
hehehehehehehhehe.... Esta é a minha pequena guerra pessoal.... Um desafio que para muitos é o simples cotidiano, mas que ganhou uma conotação de verdadeira jornada interior. 
O cotidiano é para todos nós o mesmo desafio da Jornada Interior, quando caminhamos em nosso interior e no cotidiano com a mesma eficiência eliminamos a primeira força de MAia, da Ilusão, o separativismo. 
Já a solidão do caminho é algo muito claro e talvez atinja pessoas que não gostam de ficar sozinhas, mas de um modo geral é tremendamente importante para o fortalecimento da Vontade. E esta solidão deve ser compreendida o mais amplamente possível, ou seja, ela nada tem a ver com as pessoas que por acaso estejam em volta, que compartilhem seus momentos. A solidão é uma condição natural e de certa forma uma benção e não um castigo. 
Sim, não existem recompensas ou castigos aqui, há apenas poder pessoal, atos impecáveis e o Intento Firme da Liberdade. 
A solidão do caminho é apenas o reconhecimento de nossa condição singular dentro da Eternidade , o fato que ninguém morreu por nós, ninguém vive por nós, somos entes com um potencial incrível, capazes de ir além da própria morte e via de regra perdemos tudo isso apenas por desconhecermos , por não sabermos que somos Entes Mágicos.