---
layout: texto
tags: []
texto_number: 42
category: ventania
---
Date:Qui Fev 15, 2001 12:11 pm
Texto:42
Assunto: Teçam essa teia comigo.
Mensagem:614

Saudações viajantes do mundo virtual;

Hoje pela manhã recebi uma visita inusitada, uma pessoa que tem uma
significação ímpar em minha vida.
A conheci há tanto tempo atrás e de forma tão inusitada que por vezes este
ser fica mais no referencial dos sonhos que da memória cotidiana.

Mas há momentos que a memória cotidiana abarca um pouco mais que o
conhecido e nos lembramos que estamos aqui para algo , que assumimos
compromissos conosco mesmos em momentos de consciência mais ampla e muitas
vezes os esquecemos no robotismo do cotidiano.

Neste ponto existem duas formas de nos perdermos de nossos próprios
objetivos.

Ou caímos em vidas sofridas, onde a mera luta pelo sobreviver consome toda
a energia , deixando-nos exausto para qualquer busca mais ampla rumo a
significação da magia de estar vivo, de sermos conscientes.

Ou nos tornamos hedonistas completos , quando as condições de vida nos
levam a viver num fluxo constante de auto satisfação e indulgência. Aqui
também há a exaustão da energia para tal sondar da realidade mais profunda
que somos, ao invés de contentar em estar neste mundo escravizado.

Existe um livro que devo publicar, que deve ser entregue a uma editora
antes do Equinócio.

Eu tenho um livro que está quase pronto, mas para este livro me propus ser
absolutamente livre nos prazos.

Ainda mais agora que estou recompondo a densidade emocional dos
personagens, isto não dá prá ser feito com prazos, aqui quero ter a
amplitude de agir a cada instante como único e sem limites.

Mas havia este trato com este ser, que já foi uma pessoa um dia, mas hoje
faz parte de uma linha de vida, livre e realizada enquanto essência
perceptiva, que tenho interesse em me aproximar. ELe , conhecedor de meu
íntimo, veio me avisar que eu não ia terminar o livro a tempo e que então
deveria ser mais experto que perder a chance de me aproximar da galera dele,
por mero capricho de "sou livre" .


TRato é trato para eles(as) .

Então resolvi que vou publicar um livro,como lhes prometi há 13 anos
atrás, mas ao invés de publicar já o que estou escrevendo, vou publicar uma
coletânea de todos meus artigos que circularam e circulam pela net.

Toparam o trato .

O tema será Xamanismo Urbano.

A idéia é relatar minhas experiências que envolvem de cursos virtuais, que
a Comunidade Virtual Mundo Imaginário viabiliza, a observações colhidas em
anos de convívio em chats de esoterismo e afins.

Tudo isso tendo como fundo meu caminho no Xamanismo e no Taoismo.

Por que estou lhes contando tudo isso?
>
>
Ao invés de selecionar quais artigos e mails eu iria publicar ou não
resolvi fazer de outro jeito.

Gostaria que quem tivesse salvo algum mail meu , um artigo que lhe tenha
chamado atenção , me mandasse este artigo.
Prá facilitar seria legal ao in'ves de mandar o nome do artigo, já mandar
o artigo que se salvou e'stá na área.
Pode mandar , com observações até se quiser, dependendo do teor vão junto
na edição.


O "Intento" por trás da obra, a modalidade da roda do tempo que vai estar
agindo para a confecção da obra estará operando de outra forma se os textos
que forem fazer parte da segunda parte do livro ( onde vão os mails mandados
para a rede , para a Teia "web") vierem de quem os selecionou como algo que
tocou fibras relativas ao Infinito, à Eternidade em si.


Aliás esse é o nome do livro,


" Em canto para a Eternidade"

No subtítulo : "Xamanismo Urbano - Experimentos Virtuais."


Agradeço desde já quem ajudar, é só mandar o mail que por ventura tenha
salvo como interessante .


A batalha da tribo do Arco Íris é como o Arco Íris.

O sol revela-se em sua ígnea natureza , na gota d'água pela qual passa.