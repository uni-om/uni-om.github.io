---
layout: texto
tags: [prática]
texto_number: 43
category: ventania
---
Date:Dom Fev 18, 2001 2:58 am
Texto:43
Assunto: Energia; Poder Pessoal, Liberdade. ( txt longo)
Mensagem:631

Olá Ventanias; 
Olá Cabelos de fogo; 
Olá Wurch; 
Cá estou chegando na Serra Mineira, com uma chuva maneira. 
Acabei de acertar o relógio do Pc, eram 2: 46, agora é 1:46. 
Acabei de ganhar uma hora no tempo do sistema. 
Uma hora que haviam nos surrupiado na primeira noite do horário de verão. 
Todo mundo na maior parte do Brasil( em termos populacionais) adotou este horário. 
Há meses atrás tiram uma hora do nosso dia, hoje a devolvem. 
Por que? 
Principalmente por razões de economia de energia elétrica, entre outras coisas tentar evitar o hiper consumo, quando muitas pessoas estão chegando em casa, ligando luzes , ligando chuveiros, TVs, etc. 
Assim a questão do Tempo, do calendário e medir este tempo e confiabilidade deste calendário para nos sincronizarmos tem profundamente a ver com o mail da Cabelos de Fogo, que fala exatamente sobre energia e liberdade. 
Energia é a base de tudo que um (a) xamã trabalha. 
Sem energia não estaríamos aqui, nesta lista. 
Energia . 
O termo foi muito fantasiado como tudo que caiu no domínio do esohisterismo, mas vamos resgatar o sentido deste termo. 
Energia, em nossa vida cotidiana podemos substituir energia por disposição. 
Quando dou cursos em empresas e grupos faço sempre isso para melhorar a compreensão. O termo energia ficou carregado de um sentido muito " místico" . 
Energia está no mesmo campo que termos como elétron, partícula/onda, Liberdade e Amor, falamos mas raramente alguém que usa o termo sabe do que está mesmo falando. 
Alude a algo que sabe existir, mas a experiência direta é outra coisa. 
Disposição. 
Quando temos energias estamos dispostos, bem dispostos, com "pique" prá o que quer que tenhamos para fazer. 
Por exemplo, agora nesse instante, 1: 52 da matina, eram 2: 52 até eu "acertar" o relógio. 
Acabei de chegar de Sampa, vim dormindo, gosto muito de viajar de ônibus por isso, ao invés do treino de estar atento na estrada, que também é muito bom, um relaxamento completo e um sentir desse relaxamento com o corpo em movimento médio de 80, 100 km /h. 
EStes exercícios puseram minha energia em fluxo. 
Cá estou escrevendo este mail. 
Energia, disposição, sem isto não estaria aqui, sentado, usando o teclado, tecendo idéias e sentimentos em palavras. 
Sem energia, sem disposição não estaria você, neste outro tempo e espaço, lendo, meditando, com seu cocar, presente neste contato virtual. 
Assim energia não é algo de somenos importância, é vital para tudo , é vital para a Vida, que pareça redundante. 
A Energia Vital é uma modalidade da Energia da Eternidade. 
É um tema para outro momento, mas uma das chaves para a LIBERDADE TOTAL é a compreensão entre a diferença entre a ENERGIA VITAL e a CONSCIÊNCIA. 
O MAR ESCURO DA CONSCIÊNCIA vai nos pedir de volta , ao final da vida , à CONSCIÊNCIA , que nos emprestou para que a enriquecessemos com o processo de estar vivos. 
MAs a ENERGIA VITAL nÃo interessa e é neste trunfo que os (as) xamãs tem se apoiado para ir além dos designios do nascer e morrer e continuar cientes, no que toscamente chamamos de TERCEIRA ATENÇÃO. 
Não há como almejar a LIBERDADE sem energia, o simples conceito de LIBERDADE tal qual abordamos aqui é inacessível em termos de compreensão efetiva se não temos energia suficiente. 
Os (as) xamãs Toltecas definem "Poder pessoal" como energia acumulada. 
E tudo que somos é um ponto de aglutinação que ativa certas emanações de consciência que nos foram emprestadas, tudo que temos é o poder pessoal que desenvolvemos durante nossa vida. 
O conceito de acumular energia é deveras dúbio, temos que ter cuidado para não reprimir ou distorcer a energia em sua manifestação. 
FAzemos muito isso, vejam quantos adolescentes brilhantes cheios(as) de energia , por vezes manifestam isso de forma não sóbria e ao tentar corrigi-los(as) acabamos bloqueando a energia ao invés de apenas mostrar como usar melhor a energia. 
Todos temos energia, todos temos poder pessoal para alguma coisa. 
Os (as) guerreiros (as) xamãs aprendem a canalizar essa energia para longe dos estilos indulgentes e indolentes de ser e aproximar tal energia das formas estratégicas de ser e estar no mundo. 
Quer seja este mundo, quer em mundos outros que não esse. 
Quando começamos a trabalhar melhor esta questão da energia em nós vamos descobrindo que o primeiro ponto que bloqueia nossa energia, impedindo sua plena manifestação é o fato que não estamos aqui. 
A mais importante magia a ser aprendida por quem começa o Caminho é a magia de estar Aqui e Agora, a MAgia da Presença. 
Passamos a vida diluídos em passados frustados ou rancorosos e futuros ansiosos ou cheios de medo. 
E raramente estamos aqui e agora, onde de fato existimos. 
Todo ato praticado no foco do Aqui e Agora não gasta simplesmente energia, na realidade amplia essa energia. 
Todo ato praticado num estado robótico, ausente de nós mesmos, dissipa a energia nele empregrada. 
ESTa diluição evita que a energia se manifeste, assim o primeiro ponto que os (as) xamãs notam, como empecilho a plena manifestação do nosso poder pessoal é que não existimos de fato, para manifestar esse poder. 
Somos possibilidades virtuais errantes em lembranças ou expectativas com raras incidências no aqui e agora de nossa efetiva existência. 
Por isso a consciência corporal é tão importante, por isso todos os caminhos xamÂnicos insistem nisso: Consciência Corporal. 
Andar muito, se exercitar, ter o corpo " em dia" , "em movimento" . 
O xamanismo é oriundo de povos em movimento, não povos com alto grau de sedentarismo, não devemos nos esquecer disso. 
AGora, nesse instante , você está onde está, aí, lendo este texto, neste instante. 
A Eternidade se foca em sua localização. 
Imagine um vasto cone, ou um rodamoinho, como aqueles que se formam num tornado ou quando abrimos a pia para a água sair. 
Na esfera inferior deste vasto rodamoinho está você e saindo de você se ampliando para a Eternidade está ele, rodando. 
Sua posição é o ponto onde a Eternidade te toca e estar aqui e agora é estar conscientes de onde estamos corporalmente. 
Se queremos expandir a consciência temos que antes tê-la. 
Onde você está? 
Olhe a sua volta. 
Que cheiros lhe sensibilizam? Calor ou frio? Há vento? Sons? 
Sinta sua presença no lugar onde está, mexa em algo, algum objeto que exista a sua volta. 
Você criou uma alteração no espaço, mensurável, o que você tirou do lugar só outra pessoa ou um fenômeno natural ( vento, terremoto, ...) pode mexer daí. 
Então a sua presença enquanto corpo físico é sensível e causa alterações no meio. 
Isso é muito importante prá começarmos a falar de ENERGIA e TEMPO. 
Mexa seu mouse. 
Mexa agora, concretamente. 
Faça a experiência! 
Veja , com esta sugestão acima você alterou o espaço aí, num outro momento. 
Eu estou escrevendo este mail, são 2: 03 da matina, uma hora a menos eu programei no relógio quando cheguei, porque eu adotei a convenção dominante. Domingo, 18 de Fevereiro de 2001. 
Quando você ler este mail e fazer o movimento do mouse que sugeri acima será outro tempo, outro momento. 
Podemos transmitir idéias que causem alterações sensíveis da realidade além do tempo e do espaço. 
Mas esse dia 18, esse "Fevereiro" e esse " 2001 " foram convencionados. 
É dia 18 de um mês que perdeu um de seus dias para que o mês do Imperador Augustus não ficasse com menos dia que seu antecessor César ( Julho) . 
Mera vaidade de déspotas alterando o tempo ou algo já mais armado, não podemos nos esquecer que Júlio César queimou propositadamente setores da biblioteca de Alexandria e se aliou a Cleópatra para criar um Império onde os reis fossem Deuses e embora a REpública aristocrática tenha sobrevivido com seu assassinato, seu protegido Augustus cumpriu a tarefa. 
FEvereiro há cada quatro anos um dia a mais é acrescentado a este mês , para corrigir o calendário, um dia, resultado da soma das horas que sobram todo ano ( aproximadamente 6) . 
É interessante que numa civilização que finge ser exata, precisa, asséptica, racional , nada seja muito exato, muito preciso... 
CONVENÇÃO. 
Poucos(as) param prá perceber como vivemos escravos das convenções mais diversas, mantendo acordos que nos impuseram a revelia de nossa vontade. 
Uma das definições de vida dos (as) Toltecas é que não devemos honrar acordos que nos impuseram. 
Você mexeu seu mouse? 
Agora, relaxe e convoque o poder mais forte que conhece, o poder mais intenso que concebe, lembre-se que você está com seu cocar, está num momento de poder, então faça sem medos. 
Evoque esse poder e peça que este poder evocado mexa o mouse, mas com um detalhe, sem usar NADA da sua energia. 
Creio que já sabe o resultado, mas faça o teste. 
Nenhum poder externo a este mundo, por maior que seja, pode se manifestar aqui sem usar da sua energia. 
A menos que venha para cá com toda sua fisicalidade, este um mistérios dos fenômenos que se convencionou chamar de ufológicos, que um dia falaremos. Seres que vem para este mundo com toda sua fisicalidade. 
Por hora o foco do nosso tema é: 
Em nossa realidade cotidiana, a manipulação do espaço só pode ser realizada com o uso da nossa energia. 
Algum poder moveu seu mouse? 
Pode ficar um tempo aí esperando se quiser,ou vamos seguir nesta linha de investigação. 
Somos agentes sensíveis desta realidade, podemos alterar o espaço a nossa volta. 
Tudo que está a sua volta pode ser alterado por seus atos, mas se ficar só pensando ou sentindo o que deve ser feito a alteração não ocorre também. 
Portanto, pensamentos e sentimentos, embora nos movam, só se realizam pelo ato. 
E o ato é o corpo se manifestando. 
ASsim na contra mão de todo esohisterismo reinante, não temos o corpo como algo "inferior" , ou como "prisão do espirito" ou algo assim. 
O corpo,no começo de nossa jornada é tudo que temos. 
Se atuarmos com diligência, disciplina e foco quiça um segundo corpo, o corpo de energia radiante teremos, mas prá começar os(as) xamàs reconhecem como base de todo o trabalho este corpo que temos, o que você usa para ler o que , usando-o , escrevi. 
Por isso os(as) xamãs guerreiros (as) dizem que somos materialistas antes de mais nada, começamos pela matéria, pelo que somos e temos de fato, e depois vamos ampliando nosso campo de possibilidades existenciais. 
Quando falo ou escrevo o que penso partilho do meu pensar e sentir e este pensar, este sentir age sobre outras pessoas. 
Se eu pedir de novo para que mexa o mouse , você pode ou não fazer isso, assim dependo de sua anuência para que o que peço: 
"mexa o mouse" se realize no tempo e espaço onde você está. 
Da mesma forma a açao dos entes de outros mundos em nossa realidade depende da nossa energia e a quantidade dessa energia determina se vamos mesmo conseguir auxilio ou não. 
Não é o tipo de rito, a palavra mágica em língua perdida que vai determinar meu sucesso em contatar e operar em conjunto com seres de outros mundos. 
É o poder pessoal, isto é, a energia que temos. 
Por isso tantos (as) xamãs escapam de situações de pleno perigo, como a perseguição sistemática que os "bandeirantes" em suas diversas formas realizam , com o auxilio de tais entes e outros tantos nada conseguem além da morte atrós ou escravidão. 
O poder pessoal determina tudo e de acordo com a quantidade de poder pessoal um (a) xamã pode ajudar os entes que tem contato a se manifestarem tangívelmente neste mundo ou não. 
Se o poder pessoal determina é determinante lidarmos com a questão do poder pessoal , seus fluxos e como maximizá-lo. 
O EStar aqui e agora, plenamente no que se está fazendo, sem ficar divagando em passados ou futuros, determina se existimos para ampliar essa energia que se torna poder pessoal ou não. 
E aí , quando estamos no aqui e agora entramos na questão do tempo, o AGORA dinâmico que existimos. 
Nós construímos uma continuidade temporal, chamamos de ontem, anteontem e damos datas e horas para o que já foi, lembramos e reinterpretamos o que já aconteceu, a partir do que julgamos ter acontecido ficamos bem ou mal no momento atual. 
Esse acúmulo de tempo é a história pessoal e aqui devemos nos lembrar que apagar a história pessoal é um dos quisitos iniciais para quem trilha o caminho do guerreiro (a). 
Portanto o tempo linear do calendário oficial é uma forma de prisão conceitual a mais entre as tantas que nos colocaram. 
Apagar a história pessoal é um conceito complexo, não podemos racionalizá-lo apenas. 
O mundo que nos descreveram impregna nossa história pessoal e nossa história pessoal é um dos fios que ajuda a manter a trama do mundo tal qual ela é, a chamada "realidade". 
Por isso não é fácil apagar a história pessoal, as outras pessoas vão ter medo que ao apagar sua história comprometa a delas, assim armadilhas sutis existem para quem tenta fazer isso sem base, só para "seguir" . 
Por isso "apagar a história pessoal" está ligado a entender melhor o TEmpo , tal qual ele é , não como nos disseram. 
Notar que seguimos um calendário. 
Um calendário convencionado. 
O ano se encerra num dia sem nenhum significado além do convencionado. 
Agora o que são os equinócios e os solstícios? 
São eventos observáveis astronômicamente. 
No equinócio o dia e a noite são iguais, resultado da posição da Terra em relação ao Sol, na sua órbita eliptica. 
É mensurável que o DIa e a Noite no equinócio são iguais e depois se vamos para o inverno, os dias são menores, as noites mais longas até chegarmos à noite mais longa do ano, no Solstício de Inverno , depois dessa noite as noites vão de novo ficando mais curtas e os dias mais longos, até o equinócio de primavera, quando o dia e a noite são iguais e então, começam os dias a ficar ainda mais longos e as noites ainda mais curtas até chegarmos ao Solstício de Verão, momento onde teremos o dia mais longo e a noite mais curta. 
Esses Quatro Momentos do Ano sempre foram festejados e celebrados pelos povos que tinham total ligação com a Terra e seu pulsar. 
Esse celebrar desses momentos não era adoração vazia, nem o repetir de um costume, para quem esta em sintonia é o ritualizar que reatualiza um mito, um mito participativo onde seres humanos e forças naturais se uniam a forças solares e tantas outras forças que nos chegam da ETernidade e juntos realizamos um momento alquímico de transformação dessas energias todas, sendo nosso corpo,cadinho alquímico onde esse transubstanciar da energia ocorre. 
Assim sendo, estar em sintonia com esses fluxos é sentir com mais harmonia a respiração do SEr Terra ao qual estamos ligados, e sentir nosso próprio pulsar ciclíco de energia e assim lidar melhor com os momentos que nos envolvem, a fim de ampliarmos nossa energia pessoal, de tal forma que estejamos sempre em sintonia com os momentos da Vida. 
Alguns pontos para ampliarmos a meditação sobre o tema