---
layout: texto
tags: [prática]
texto_number: 45
category: ventania
---
Date:Sex Fev 23, 2001 9:28 am
Texto:45
Assunto: Liberdade e Implacabilidade
Mensagem:654

Saudações Ventanias; 
São 8:28 no tempo espaço que estou agora. 
Algumas pessoas com as quais conversei ao chegar aqui reclamaram que ainda não se "acostumaram" com o horário "novo" . 
ESta questão do tempo continua sendo um assunto muito intrigante, quando começamos a observar por nós mesmos, a sentir de fato como cada instante ocorre, as diferenças nas texturas de cada momento, na intensidade dos momentos. 
O assunto dos calendários parece que morreu na lista, inclusive a proposta de irmos estudando os glifos maias, podiamos pensar nisso, temos 56 pessoas na lista , poucas se manifestam, seria interessante se algumas apenas pesquisassem e mandassem prá gente material sobre os glifos maias e os calendários lunares. 
ESta questão dos calendários lunares é muito interessante e sobre contagem do tempo também. 
Podíamos trabalhar um pouco sobre os mitos dos nativos brasileitos, como comemoravam suas festas, tinham calendários? 
São temas que seriam interessantes de serem levantados para podermos ir mais fundo nesta questão de TEMPO que é um tema muito importante. 
Existir é mágico. 
Este instante no qual estamos, este instante presente onde é possível acionar teclados que lançam sinais elétricos que se transformam neste texto, texto que vence tempo e espaço e aciona sua percepção no momento que estais. 
Hoje viajo para o Sul, vou ficar parte do Carnaval lá. 
Fico observando o sentido de "feriado" para as pessoas. 
Como fica clara a condição de escravos na qual o sistema procura nos manter com estes tipos de "agendas" . E escapar dessa MATRIX é trabalho árduo. 
É feriado, mas vou a trabalho, certas alterações vão ser realizadas a partir da próxima semana e aproveitando o momento do carnaval vamos trabalhar com treinamento . 
"Aproveitar o clima de carnaval" , foi como justificamos este período para trabalhar. 
Isto motivou minha meditação de como o mundo está padronizado, como as pessoas passam o dia realizando atos em conjunto com milhões de outras, sem nem perceberem sobre isso . 
Acordam, tomam o desjejum, saem para o trabalho, almoçam, trabalham, vão prá casa, assistem a novela, o jornal, a "atração da noite" , outras vem ao computador, ficam na net, mas fazem isso como bando, como manada, nÃo como individualidades... 
"Vaca profana põe teus cornos, prá fora e acima da manada." 
Encontrar nossa individualidade é um desafio. 
Mesmo no campo psicológico comum teremos abordagens que enfatizam esta necessidade, o processo de individuação que a linha Junguiana adota é uma alusão efetiva a este processo. 
Sair do tempo que está estabelecido e encontrar um outro fluxo é uma meta de todo (a) xamã e isto tem de ser feito concretamente e a ARTE está em fazer isso ainda vivendo na sociedade. 
PAra o Clã do ARco Íris a única chance que o Ser Mundo tem de sobreviver, que nós espécie humana temos de sobreviver é mudar nossa relação com a realidade. 
Existe um desafio, ou trazemos a magia para nossa realidade ou esta realidade pode nos consumir de forma irreversível. 
Doença, morte, fim, é o ritmo tido por "natural" , como "coisas da vida" . 
Abrir mão de seus valores e sonhos para servir a este sistema dominante é tido como " necessário" e "de valor" . 
MAs a luta calada, secreta que os (as) xamãs vem enfrentando através dessas eras de dominação é firme , constante, onde a liberdade perceptiva, a mais fundamental das liberdades, não se manifesta só em teorias, mas em fatos concretos, em ATOS. 
Atos de poder. 
Neste sentido um (a) guerreiro se torna um servo do poder, não um escravo, mas um servo, sutil diferença, pois ao servo é dada opção. 
Opção em ser impecável no uso do poder, opção em ser sóbrio no uso do poder. 
Um (a) xamã guerreiro(a) se apóia no poder e sabe que o poder pessoal é tudo que tem para lidar com a ETERNIDADE em sua insondável complexidade. 
As propostas existenciais dos xamãs da linhagem guerreira levam a uma mudança tão profunda, tão visceral, tão intensa em nossas vidas que só tem uma forma de falar sobre o que acontece quando nos trabalhamos dentro da ARTE dos (as) Xamãs Guerreiros (as) 
Nós morremos e nascemos de novo. 
Sim, é fato concreto que a morte para o mundo , para a vida antiga, para a antiga continuidade que chamamos de "minha vida" é o passaporte para o mundo do poder, é por esta porta que os (as) xamãs guerreiros abordam a Eternidade. 
Existem outras portas, mas são por vezes caprichosas, por vezes mórbidas, por vezes indulgentes e grande parte delas cria apenas dependência e escravidão. 
Por isso os (as) xamãs guerreiros (as) deixam o mundo cotidiano e se envolvem com o poder, deixam de servir a importância pessoal e aos valores que lhes impuseram e se tornam intímos ao poder. 
Assim sendo , por força da herança de sua tradição os(as) xamãs guerreiros(as) 
reconhecem que a porta mais efetiva, mas estratégica para adentrar na Vastidão da Eternidade é a morte para a antiga continuidade e o lançar-se em uma nova continuidade existencial. 
Todos os caminhos iniciáticos conhecidos aludem a isso: Morrer e nascer de novo. 
Esta linha leva a um despreendimento completo a um estar apenas aqui e agora, este instante onde a ETERNIDADE de fato se manifesta. 
Quando fazemos essa travessia efetivamente, quando de fato deixamos para trás o passado limitante que nos impuseram, quando deixamos nossa "história pessoal" então não trazemos cargas inúteis ao mundo do poder e não vamos cair nas armadilhas que tantos já caíram de ficarem em briguinhas patéticas, sobre quem "tem mais poder" , que é o " mais poderoso" 
VAmos morrer, vamos nos dissolver na vastidão do dragão novamente e o fogo de nossa consciência será reinalado pelo mesmo dragão que um dia nos deu seu hálito para vivermos. 
É um fato, inquestionável. 
O que podemos é mudar o matiz dessa realidade. 
Os desafiadores da morte passaram eras tentando lidar com isso. 
Dividiam-se em dois principais grupos. 
Os(as) que buscavam a vida além da morte por medo da morte. 
Os(as) que buscavam a vida além da morte por amor à vida. 
A forma como orientavam esta busca revelou diferentes resultados , mas grande parte destes homens e mulheres caíram em armadilhas da mais diversas, conseguindo por vezes prolongar sua vida por milhares, milhões de anos,( estão vivos até hoje) mas de uma forma distorcida, de alguma forma perderam algo de si, caíram numa armadilha e descobriram que vastidão no tempo , vastidão no existir , ainda pode ser uma prisão e mesmo milhões de anos ainda acabam um dia. 
NEste caminho os(as) Xamãs guerreiros(as) descobriram algo inquietante, um "presente" , um "dom " que a Fonte de tudo deixara para quem por essa "chance de ter chance " lutasse. 
Tudo começa com a questão de ter energia, assim o primeiro passo que tais xamãs tomaram foi lidar da melhor forma possível com sua energia, assim começaram por erradicar todo hábito, todo comportamento que se mostrasse como um gasto inútil de energia. 
Focaram suas contemplações para o estado egocêntrico, indulgente e manipulador dos xamãs que haviam falhado em sua busca pela liberdade e notaram que o estilo de comportamento que adotamos na vida cotidiana pode ampliar ou drenar nossa energia. 
Foram, através da observação, mirando o corpo de energia e não por achismos ou dogmas morais, estabelecendo certas linhas de comportamento onde perceberam que a energia não se desgastava, não se dissipava , mas ficava mais concentrada. 
Os(as) xamãs toltecas cunharam alguns termos para explicar tais estilos comportamentais, mas é bom lembrar que tais temas apenas aludem, apontam, não são exatos, lembrem-se de que devemos olhar a estrela, não o dedo que a aponta. 
Implacabilidade. 
É um desses termos que só pode ser "revelado" na prática. 
O agir implacável só é pleno e efetivo depois que atingimos um estado que chamam de "ESTado da não piedade" . 
ESta frase , como todos os termos dentro desta nova linguagem que estamo usando, tem de ser bem meditada para ser realmente compreendida. 
Os (as) xamãs notaram que as pessoas tem uma profunda piedade de si mesmas, pois reconhecem, ainda que sem ter noção disso, que somos nada, que somos efêmeros, que somos menos que um cisco perante a ETERNIDADE. 
Carregamos em nosso interior a certeza de nossa solidão, que a parte humana da Fonte é insignificante demais perante a TOTALIDADE, que não adianta rezar, tentar fazer promessas, subornar deuses ou demônios, o fato é que estamos por nós mesmos e é nosso poder pessoal que vai determinar o quão longe podemos ir nesta aventura chamada VIDA. 
Por isso insistem que só como guerreiros (as) podemos acessar o Caminho do Conhecimento, pois ele é frio como o olho do dragão. 
Nosso olhar está perdido no mundo, procurando comida, satisfação, companhia, enfim nosso olhar foi focado no mundo e nos anseios do mundo. 
Os (as) xamãs guerreiros aprendem a deixar o olhar direito para o mundo mas despertam o olhar esquerdo para que seja "frio como o olho do dragão" . 
É com este olho que os (as) xamãs miram a ETERNIDADE, pois nesse olhar os anseios humanos não vão turvar a percepção. 
ESte é o olhar que quem atingiu a implacabilidade , o frio olhar do Dragão, que mira a ETERNIDADE vazio, pleno em si. 
É dificil falar disso numa sociedade preza a emocionalismos desarrazoados, a um racionalismo positivista e estéril. 
NÃo se trata de ausência de Sentimentos, trata-se de não ficar mais no plano de ter tanta piedade de si mesmo(a). 
Só quando somos cheios de piedade por nós mesmos criamos a arrogância de nos sentirmos superiores, a bobeira da importância pessoal. 
Quanto mais arrogante alguém, quanto mais necessidade de se sentir importante, maior é o fosso de auto piedade real , maior a fragilidade desse ser. 
Vejam essa nossa sociedade dominante, cheia de arrogância, de teorias que a fazem sentir-se como a mais desenvolvida e sofisticada cultura que já existiu, vejam como todo essa arrogância esconde uma sociedade doente, em crise, com armas suficientes para destruir a si e toda a vida existente. 
Por isso o primeiro passo no caminho é perder a importância pessoal e para isso é preciso apagar a história pessoal. 
Apagar a história pessoal é muito complexo, justamente porque é simples . 
Apagar a história pessoal é deixar de ficar dando contas da própria vida para todos, especialmente para si mesmo, é aceitar-se enquanto ser dinâmico e em fluxo e parar de tentar explicar aos outros o que está fazendo. 
Passamos grande parte da vida dando satisfações, explicitas ou implicitas, do que estamos fazendo. 
EScolhemos um grupo de pessoas e resolvemos que temos de agradá-las, por vezes há mesmo uma negação do que somos para "agradar" um meio. 
Todos estes comportamentos alienam, tiram energia dos pontos onde deveriam estar, que são nossos comportamentos que tem relação estratégica com o Caminho e colocam essa energia nos eus caprichosos que temos. 
Assim todo estilo de comportamento que leve a dependências de qualquer forma é danoso, é prejudicial e está em contradição com as metas de um Caminho que também atende por "LIBERDADE TOTAL" . 
Entretanto paralelo ao apagar da história pessoal os(as) Xamãs toltecas falam do construir nosso álbum de momentos memoráveis. 
Fica como tema para o próximo mail, 9: 27 , em três minutos entro no trabalho...