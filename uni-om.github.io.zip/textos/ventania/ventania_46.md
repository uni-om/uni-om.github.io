---
layout: texto
tags: [prática]
texto_number: 46
category: ventania
---
Date:Seg Mar 5, 2001 10:34 am
Texto:46
Assunto: rotinas
Mensagem:667

Ola lista 
Olá Renata; 
Bem interessante suas opniões; 
Primeiro bem real que podemos cair no risco de criarmos a rotina de "tentarmos ser sem rotina" . 
O "eu rotineiro" é cheio de artimanhas e é muito dificil se livrar desta forma de ser, que é bem mais complexa que parece. 
Por isto enquanto o "eu rotineiro" estiver no comando, tudo que fizermos poderá ser apenas uma forma diferente de termos rotinas,, portanto a chave do que estamos falando aqui é ir ao "eu rotineiro" e desmontá-lo, deixando assim de ter rotinas, mesmo que todo dia eu acorde na mesma hora e vá trablahar no mesmo lugar. 
Fomos educados para sermos cheios de rotinas, tudo a nossa volta colabora para isso. 
Por isso na TRilha dos(as) Xamãs guerreiros(as) é dada muita importÂncia em romper com as rotinas, mas isto não pode ser feito como algo formal, é preciso muita imaginação e muita energia para lidar com qualquer tarefa do mundo do poder. 
ALgo que o pessoal que está há mais tempo nesta lista sabe é que estamos fazendo uma experiência aqui, estamos testando as possibilidades de uma lista nos alinhar com o Intento dos (as) xamãs ancestrais. 
TEmos que ter muito cuidado quando lidamos com esse Intento, pois não podemos apenas resignificar , isto é usar um termo diferente com o mesmo sentido, como dizer " o que o Intento quer" , como quem diz "o que deus quiser" . 
Projetar uma imagem a nossa semelhança no Intento é o primeiro erro que devemos evitar se queremos mesmo sentir o NOVO e não uma reedição daquilo que já trazemos em nós. 
O que fazemos não representa nada para o Intento, mas representa muito para nós, aliás é isso que um (a) aprendiz no xamanismo guerreiro busca, provocar, atrair a atenção do Intento, com ATOS , atos de abandono, atos puros e claros onde o melhor que temos é oferecido sem esperar nada em troca, apenas pelo prazer de fazer. 
O problema é que quando observamos as coisas de um ponto de vista dificilmente conseguimos entender o que está sendo dito de outro ponto de vista. 
Assim, avaliando algo a partir do "eu" comum fica sempre preponderando o ponto de vista deste eu. 
Como dizia D. Juan é preciso poder só prá falar do poder. 
É uma ilusão que podemos criar a rotina de não ter rotinas, ou a rotina de ser imprevisivel. 
SEnão temos rotinas não pode haver rotina, se somos imprevisíveis não ha rotina. 
O que acontece é que a mente comum, que lida com o mundo cotidiano não se expandiu ainda, ai vai interpretar tudo com base em seus próprios parametros. 
EnTão vai ser a mesma mente comum, fazendo de conta que não tem rotinas, vai ser o eu comum fazendo de conta que é imprevisível, mas como está no plano do comum, do ordinário, logo logo vai colocar rotinas, enfim, vai apenas manter o mesmo jeito de ser que sempre teve. 
Assim podemos continuar presos na rotina, fingindo que estamos livres, continuamos presos aos paradigmas do mundo, sonhando estar livres dos mesmos. 
Quando de fato trabalhamos com a ausência de rotinas isto é muito poderoso, é revolucionário mesmo , pois vai contra todo nosso condicionamento. 
Se somos imprevisiveis, até para nós mesmos, é porque vencemos a rotina, se estamos ainda no mundo aprisionante da rotina aí sim, vamos por rotina em tudo e então acontece mesmo de "fazer de conta" que não estamos tendo rotina, mas estaremos apenas tendo uma rotina diferente. 
O alerta é bem válido, é muito fácil cair na rotina achando que está saindo dela, mas o enfoque da mensagem que mandei foi outro, foi de um mundo fora da rotina. 
No meu trabalho do dia a dia tenho agenda, tenho consultorias marcadas para daqui há um mês, para daqui há seis meses. 
Isto poderia ser rotina se estivesse preso num "eu rotineiro", mas quando deixamos este estilo de ser rotineiro de lado nao tem mais jeito de ter rotina. 
É um "estado de espirito" precisa estar no mesmo estado de espirito para entender, porque a visão da realidade é uma função direta de nosso estado de consciência. 
A rotina é uma fixação do ponto de aglutinação em interpretar a realidade de uma forma equivocada, quando deslocamos o ponto de aglutinação para outra posiçao descobrimos que não existe continuidade, se não existe continuidade não pode existir rotina. 
Cada dia é único, cada momento é único, cada instante é único, singular e nunca vai se repetir. 
Quebrar rotinas não é criar um estado artificial, não é criar um estado fora da realidade, é justamente o contrário, é voltar para a realidade, o estado rotineiro é que é falso, não real, não natural. 
Portanto se criamos a "rotina de não ter rotina" ou ainda "a rotina da imprevisibilidade" é sinal que não entendemos nada do que está sendo proposto, estamos apenas interpretando idéias e procedimentos que abrangem outras áreas, com a mente cotidiana e portanto as falseando. 
A não rotina é um estado resultante de um movimento do ponto de aglutinação, não uma elocubração mental. 
Como tudo mais no caminho do (a) xamã guerreiro (a) fazemos isso não por principio, mas por estratégia. 
Tudo exige muito bom senso e imaginação. 
Quando falo que não creio ser interessante marcarmos compromissos com antecedência nesta lista estou me referindo a criarmos aqui , para encontros de poder, os mesmos hábitos que temos no nosso cotidiano. 
Agora um exemplo, digamos que queiramos ir juntos para fazer a TRilha Inca. 
Digamos que em Junho. 
Ora , seria interessante começarmos a armar isso desde já, até para que todos possam se organizar, como exemplo, quem trabalha ver se consegue uns dias de férias ou licença, o lance da grana que é preciso ter para uma viagem dessa, assim, seria um contra senso querer que de última hora todos estivessem prontos prá ir. 
Mas nos encontros cotidianos, nos encontros que ocorrem nas cidades, nos encontros que estamos armando para praticar tensigridade ou para caminhadas, vale mesmo o imprevisível. 
É muito dificil atingir o estado de espirito de um (a) xamã guerreiro(a), pois este estado de espírito está muito longe daqueles estados que estamos acostumados, aos quais fomos programados. 
Apagar a história pessoal está ligado a apagar rotinas, a ter a morte como conselheira e a destronar a importância pessoal. 
São técnicas complementares e não podemos tomar uma delas apenas. 
Apagar a história pessoal sem lidar com os outros tópicos tornaria a pessoa desnecessariamente furtiva e evasiva, sempre em guarda de si mesma, sempre em fuga e do que adianta se esconder quando todos sabem que é isto que estais a fazer? 
TEmos que tomar muito cuidado para não confundirmos o Intento com as fantasias que trazemos de "deus" ou algo similar, do contrário vamos ficar presos aos mesmos conceitos que limitam e escravizam. 
Um (a) guerreiro(a) xamã age. 
Primeiro avalia profundamente todas as suas chances e possibilidades de ação, avalia com foco e com profundidade, mas então se solta na correnteza e deixa que o fluxo o leve. 
É sutil isso, pois não é apenas " deixar-se ir na correnteza" , porque a primeira correnteza que temos é a correnteza da vida comum, da vida cotidiana, da vida condicionada com tudo que isto representa. 
Se nos soltamos em "ser o que somos" podemos cair no mesmo equivoco dos que dizem "faze o que tu queres , há de ser tudo da lei" e lascam a agir de acordo com seus egos imaturos e não cultivados. 
Primeiro precisamos ser, nós mesmos, deixar de ser esta resultante, este aglomerado que criaram em nós, para então dizer: "agora fluo com o que sou" . 
Por isso , todo o trabalho inicial é destinado a limpar o que fizeram de nós para que brote o que somos de fato. 
Creio q o intento trabalha de formas misteriosas e não vai ser o fato de eu marcar algo em cima da hora ou c/ anos-luz de antecedência q vai mudar alguma coisa do intento. 
De fato, não é o Intento que vai mudar, é minha relação para com ELE, o que sabemos é que começamos na Trilha com um elo completamente enferrujado em relação ao Intento, assim a impecabilidade em nossos atos é vital para recuperar a plenitude desse elo. 
Se marco algo para muito tempo na frente , encaixei esse algo na esfera dos compromissos agendados, com tempo e planejamento racional. 
PAra o Intento não faz diferença nenhuma, para nós entretanto faz toda a diferença. 
É muito duro para o egocêntrico ser humano aceitar que nesta fase inicial nem existimos para o Intento, sequer nota a nossa presença enquanto singularidade, pois nào somos singularidades, somos apenas mais um bocado de alimento , mais um bocado de consciência amadurecendo para ser devorado. 
Somos tao iguais a tantos outros seres humanos espalhados por aí que nenhuma diferença fazemos nas contas cósmicas, creio que é frente a constatação desse nada que somos que surge a humildade do (a) xamã guerreiro(a) ou a arrogância da auto importância, escudo usado por tantos para se defender da percepção do nada efêmero que somos. 
Os atos de poder são justamente para mudar esta situação, para recuperar nosso elo de conexão com o Intento e estabelecer uma relação dinâmica com esta misteriosa força. 
Veja bem, creio q cada um deve ser livre p/ marcar algo qdo quiser ou qdo o intento "quiser". Se eu quiser marcar c/ um ano-luz de antecedência ou apenas alguns segundos antes, sentir-me-ei suficientemente livre p/ tal. 
Aqui me lembra vários momentos meus e mesmo de tantos aprendizes que lemos , onde fala-se em ser livre para isto e aquilo, quando temos que começar lembrando que nem sequer temos a capacidade de fazer nada, que apenas ressonamos a nossas programções interiores ou a estímulos interiores. 
REAgimos e temos a ilusão de agir, raciocinamos e temos a ilusão de pensar, nos emocionamos e temos a ilusão de sentir. 
Tudo dentro de parametros estreitos, tudo dentro da programação humana, um bom observador que conheça astrologia e eneagrama por exemplo pode traçar um quadro completo de nosso jeito de ser, frente a diversas situações inclusive . 
Assim, enquanto somos entes robóticos adormecidos em hipnótico sono é uma ilusão falar de termos liberdade para isso e para aquilo. 
Precisamos antes lembrar de nós mesmos, resgatar a essência perceptiva que somos, aí começa o agir e só então dá prá falar em "liberdade de agir" . 
"Quando o intento quiser" é completamente fora do questão. 
O que sabemos do Intento? 
Usamos apenas esta palavra para aludir a algo que está além de toda a compreensão e definição. 
Prefiro chamar os sinais do Intento de "designios" é mais impessoal. 
Não é apenasmudar de termos, é mudar completamente o significado do Termo. 
E imagino eu, todos deveriam ter essa liberdade. Se for do intento marcar algo c/ antecedência ou se for p/ marcar em cima, assim vai sê-lo. Se for do intento tal encontro ser c/ tais pessoas, assim vai sê-lo, independente de eu, pessoinha pequenininha diante do intento, querer marcar em cima ou c/ antecedência. P/ o intento, creio eu, isso é uma questão menor q pouca diferença faz. No fim, de qualquer maneira, vai ser o q tiver q ser, c/ quem tiver q ser. 
Interessante que parece muito lógico e claro tudo aqui, mas é só a mente racional abordando um tema. 
Me lembro de uma vez na fazenda do Oomoto eu e um companheiro de treino, meu amigo Márcio( não o da lista) estávamos do lado de fora da cozinha, na varanda, conversando com Marta, que ensacava polpa de frutas, de repente ela prendeu uma mosca na vidraça com um funil. 
A mosca se debatia na vidraça . 
A Marta usou o exemplo. 
A mosca ali no funil via o exterior pelo vidro e ficava se debatendo. 
Enquanto optasse por ficar ali, onde via o exterior e na parte mais ampla do funil estava na verdade mais presa. 
A única forma de sair era arriscar ir pelo caminho menos lógico, pelo espaço menor e mais apertado do funil . 
Nós também estamos na mesma situação, na parte ampla do funil, nos debatendo na vidraça. 
Brigamos pelas nossas pseudoliberdades, argumentamos fervorosamente pela defesa do que chamamos "meu jeito de ser" , quando este "meu" é fruto de um condicionamento profundo, determinado por genes, condiçoes astrológicas do nascimento, tipo de carmas que encarnamos e ainda o estilo de criação e detalhes outros 'varios. 
No começo precisamos aprender a nos restringir, aprender a ter disciplina, aprender a nos focar e por isso existem regras sim, regras claras e precisas para quem deseja de FATO trilhar o caminho, não ficar com elocubrações ou teorias, mas trilhar de fato um caminho que pode ser mortal, pode nos destruir mesmo em qualquer fase desta trilha, pois nao há deuses ou anjos nos protegendo em nenhuma fase da jornada, quanto mais avançamos mais estamos por nós mesmos frente as armadilhas que o CAminho possui. 
Um surfista que vai pegar uma onda não crê que a onda vai protegê-lo, ou "guardá-lo" , ela vai responder a sua perícia e habilidade. 
Nossa relação com o poder é identica, estamos indo ao Poder, ele não vai nos "proteger" ou "guardar" , as vai responder plenamente a nossa perícia e habilidade em lidar com Ele. 
Cada encontro, cada ato, cada momento etc devem ter sua particularidade, devem fluir p/ o q tiver q ser naquele momento e devem conter sua magia por serem únicos. Assim, num momento pode ser q seja um encontro marcado c/ antecedência. Num outro momento, pode ser marcado em cima da hora. Isso sim, creio eu, é imprevisibilidade e singularidade, pq isso é do momento e não podemos querer estabelecer, creio eu, como serão as coisas, as coisas são únicas e o q tiverem q ser naquele momento (vamos viver o presente). Estabelecer uma rotina de se marcar sempre c/ antecedência ou estabelecer uma rotina de se marcar sempre em cima da hora, creio eu q se tornaria uma rotina e perderia a magia do momento. 
O ponto chave está em "estabelecer a rotina" , como já disse antes a mente rotineira toma tudo por seu peso e sua medida, mas aqui estamos falando de outra coisa, de nos livrarmos da rotina, e neste livrar da rotina temos fases de trabalho. 
Como dei o exemplo da viagem ao Peru, neste caso estamos sendo estratégicos falando disso com antecedência, mas para propostas do dia a dia, volto a insistir, tem muito mais poder se marcamos a coisa de estalo . 
Se marcarem algo importante amanhã no Rio eu dou um jeito e estou aí, quem me conhece sabe que sou assim, que arrumei minha vida prá ser assim. 
Ai vão dizer que isto é comigo, que sou diferente? 
Onde? 
Não sou melhor que ninguém, pode até ser o contrário, sme falsa modéstia, sou meio louco e pelas condições de minha vida tive chances de ser um bobo estrela , pseudomestre, chafurdando numa vida hedonistica. 
E se depois de amanhã for necessário estar em algum lugar distante onde algo importante vai lhe ser revelado? 
Gurdjieff sempre dizia isso, se alguém não é capaz de ter o auto controle sobre sua vida para estar onde precisa é total tolice crer que pode buscar uma linhagem autêntica. 
TEmos que parar com essa bobeira de crer que "o Intento vai cuidar de nós" . 
Claro que~ nao,, temos é que trabalhar muito, muito mesmo, para poder começar a limpar o elo enferrujado que temos com Ele. 
O incrível é que quando começamos a trabalhar, ELe também começa a trablahar em nossa direção, mas é sempre proporcional ao nosso empenho, o fluir do Intento em nossa direção. 
Isto não é minha opnião, é o que os(as) Xamãs através dos milenios de observação constataram. 
Isto me lembra o cuidado que temos de ter em "ler" os designios do Intento, os chamados augúrios, temos que trabalharmo-nos com cuidado, para não confundir nossas presunções com revelações. 
A lista é uma experiência e é este tipo de resultado que queremos observar, o lance de marcar de estalo aí as pessoas tem uma necessidade de entrar na net e checar a caixa postal. 
Saberemos então que estamos mesmo criando um elo além do tempo e do espaço, um elo de sincronicidade, se isto não acontece, então sabemos que no mundo virtual tais elos se criam ou não se criam , estamos experimentando, não sabemos como é aqui, nunca antes nossos antepassados tiveram esta tecnologia, somos pioneiros nesse campo. 
Não temos respostas prontas nesse caso, assim precisamos experimentar. 
Algumas pessoas tem narrado lances fortes de sincronicidade, muitas pessoas tem aparecido nas fogueiras que acontecem num mundo paralelo a esse, os sonhos lembram, mas falamos disso um outro momento, o fato é que estamos num experimento e um experimento é um momento que fazemos perguntas para a realidade e observamos respostas. 
A lista não é um clube de comunicação , é uma experiência, lembrem-se guerreiros(as) não estendem pontes às pessoas, às pessoas se quiserem, estendem pontes até este mundo mágico e exigente que é o do poder. 
Imagina um exemplo: tem uma pessoa o insight de marcar algo c/ esse grupo e quer marcar daqui a tantos dias, pq sentiu q seria um momento certo. Mas é estabelecido pela lista q se deve marcar em cima da hora. A pessoa vai ficar se segurando e vai acabar perdendo a magia daquele momento, p/ cair numa regra, numa rotina e tentar se manter nessa linha, e de repente até perder o trelelê do intento. 
Incrível como a mente racional pode falsear tudo. 
Aqui é um claro exemplo. 
Quando a gente lê com a mente do predador este parágrafo pensamos: Verdade, isto ocorre... 
Mas a idéia é outra. 
Se alguém tem um insight de marcar algo e a proposta é marcar só com poucos dias de antecedência essa pessoa vai ter que treinar sua habilidade de ficar quieta, de se acalmar, de controlar sua ansiedade. 
Vai aprender sobre o Silêncio, algo tão dificil nessa sociedade que adora tagarelar, sobre tudo, sobre todos. 
Vai aprender sobre PACIÊNCIA. 
Ao lado de Implacabilidade, AStúcia e Gentileza a Paciência é um dos atributos fundamentais de quem busca lidar com outras realidades. 
Assim, tendo o insight e tendo que esperar para partilhar, vai trabalhar muito a paciência e o auto controle, vai trabalhar muito sobre a ansiedade e vai trabalhar muito sobre o personalismo, pois poderia desejar que tal ou qual pessoa fosse e avisando em cima da hora não vai poder ter certeza de nada, aí sim vai ter que deixar tudo por conta do Intento, impessoal, inumano, além de nossas expectativas. 
Pode correr o risco de ir só para o lugar e este é o desafio maior, fazer o que propôs independente de outros terem apoiado ou não. 
É justamente aqui que a pessoa vai perceber que o tipo de "Magia do momento" que os (as) guerreiros (as) xamãs buscam não pode ser perdida assim, tão facilmente, pois a magia do xamanismo guerreiro nào admite intervenção humana, está além de nossa puerilidade. 
Quem perde a "magia do momento" é o ego, é a mente do predador, é nossa personalidade ansiosa que tenta projetar suas fantasias num mundo onde essa fantasia não é convidada. 
Ou por outro lado, a pessoa tem o insight de marcar algo e tem q ser naquele momento, naquele dia, e se sente infeliz pq não pode marcar, pq foi estabelecido pela lista q só pode marcar c/ dois dias ou mais de antecedência. Entendem o q eu estou falando? Perderia totalmente o momento mágico. 
A verdadeira magia não pode ser perdida, é muito interessante avaliar tudo isto que está escrito, percebem como é a mente concreta, humana, a forma humana declarando tudo a seu jeito. 
No mundo do poder, quando a forma humana é transcendida, não tem jeito de ficar infeliz, isto é capricho, ficar inquieto(a), ficar aborrecido(a) isso é imaturidade e é justamente isso que queremos por em evidência e trabalhar quando colocamos essa idéia na lista de só comunicar os eventos com poucos dias de antecedência, não precisa ser dois dias, pode até ser uma semana, a sutileza deve estar sempre presente aqui para evitar transformar exercícios de estratégia em regras vazias. 
Tentaríamos fugir da rotina da sociedade, caindo em uma outra aqui nessa lista. Estaríamos caindo em uma outra rotina sobre agendas do grupo. 
Excelente essa colocação, mostra exatamente o que não queremos e voltamos ao tópico inicial. 
Presos na mente do predador , estaremos ainda presos na mente rotineira e assim, saímos de uma rotina e caímos em outra, o que temos aqui na lista não é rotina: 
É uma proposta de poder! 
Quando fiz a proposta não o fiz pensando com a mente do predador, fiz uma proposta , como todas as outras que faço aqui, para nosso lado mágico, em busca da liberdade. 
É um "desafio" . Não uma regra 
Rotina não é fazer as coisas com horário apenas. 
Uma época que eu estava pensando assim Oomoto me levou a aceitar um emprego de coordenador num acampamento de recreação. Eu recusava o emprego, ia como monitor nas férias,mas nunca aceitava ser coordenador full time, porque sabia que era completamente rotineiro o lance lá. 
Tinha horário prá tudo, prá acordar, prá dormir, prá comer, prá descansar, tudo, tudo tinha horário e ali eu descobri que podemos agir dentro de horários que outros estabelecem e ainda assim não termos rotinas. 
Estabelecer uma rotina de ser sempre imprevisível me parece tão ruim qto seguir minuciosamente as rotinas sociais. Afinal, creio eu q todos aqui prezam a liberdade e buscam isso. 
Essas rotinas, creio, acabam tirando a magia do momento, como tentei dar os exemplos acima. É isso q não gostaria q ficasse por aqui, mas isso é minha opinião. Seja como vcs quiserem. Ou melhor, como o intento quiser. ;-) 
Ainda somos muito imaturos para saber o Que o Intento quer, estamos começando a realizar experimentos nesta lista e estes experimentos tem sua própria força e motivação. 
Concordo plenamente contigo que estabelecer a rotina de ser imprevísivel é danoso o alerta é válido e útil, mas não é disso que tratamos aqui. 
A rotina sempre tira a magia do momento, mas a Verdadeira Magia, esta sempre presente, não pode sofrer influência nossa. 
Veja bem, por outro lado, se estabelecêssemos q só se pode marcar em cima da hora, ficariam restritos os encontros, não necessariamente ao intento, mas muito mais principalmente a quem tem acesso diário e constante ao e-mail ou conhece fulano/beltrano. Se for mesmo do intento p/ tal pessoa estar lá, independente de marcar c/ antecedência ou marcar em cima da hora, essa pessoa vai estar. Por isso, acho desnecessário se criar essa regra de se marcar sempre em cima. Creio eu, q nós, pessoinhas pequenininhas, não precisamos forçar uma barra p/ o q deve ser o intento. O intento existe e age, e creio, disso, todos devem saber ou ter uma noção. 
Não estamos forçando barra, estamos falando de outras coisas; 
Falando de desenvolver VONTADE 
De como entrar em sintonia, 
Como "sentir" o momento de checar os mails, 
Como provocar "coincidências" que nos fazem estar no lugar certo na hora certa. 
Isso é magia. 
Todos esses medos e receios parecem justos e reais, mas apenas porque vem da mente concreta, a mente que tem o elo com o intento enferrujado. 
Ao recuperar a conexão com o Intento todas estas questões se diluem e o desafio deixa de parecer assim tão dificil e se torna o que é: UMA TAREFA DE PODER!. 
O Intento existe e age a todo instante, mas nós estamos isolados Dele e é com atos, com ATOS de abandono, atos artistícos que acenamos para o INTENTO. 
Concordo plenamente q c/ o poder não se deve lidar da mesma forma. Não se deve estabelecer rotinas, agendas, horários pré-estabelecidos (é meio q, me veio isso na cabeça agora, risos, é meio q marcar c/ seu parceiro q toda sexta-feira vão fazer sexo, putz, q rotina xôxa, perde até a graça, aquela coisa mecânica de se ir já sabendo, c/ hora marcada, dia marcado, pela agenda e não pelo q fluir no momento). Mas é justamente por eu concordar c/ isso, concordar q não há rotina p/ poder, q c/ poder não se lida do mesmo modo, etc e talz, é justamente por isso, q eu discordo da parte de se estabelecer uma regra-rotina de se marcar sempre encontro em cima da hora. 
Quando somos livres, despertos e plenos com o poder podemos jogar pedras prá cima e elas caem artisticamente , mas este não é o caso, somos iniciantes, estamos treinando, pesquisando, investigando o complexo mundo do poder, daí que estamos estabelecendo tarefas ( não regras, tarefas) para observar como funciona esta nossa relação com o poder. 
Estamos estudando, estamos aprendendo e para isso precisamos de tarefas. 
Esse papo de "deixar fluir" é bem delicado e pode nos atrofiar ao invés de nos desenvolver. 
Estamos fluindo em direção a Morte e a dissolução. 
Isto não é vantagem nenhuma, o desafio é ludibriar a morte e entrar nas possibilidades impensadas que nos são reservadas se lutarmos, muito e arduamente. 
Estamos presos num nível do Intento que determina sermos células do organismo cósmico no qual estamos inseridos , apenas fluir é continuar sendo um ser robótico. 
Estamos presos na mente do predador com sua morbidez e indolência. 
EStamos presos aos condicionamentos da Sociedade dominante, uma "sociedade perceptiva" que nos foi imposta e temos que trabalhar para ir além. 
Se ficarmos fluindo nessa "forma natural" vamos é para a morte e para a dissolução. 
O caminho do (a) xamã guerreiro(a) é muito árduo. 
E só como guerreiros(as) que podemos trilha-lo. 
" A coisa mais difícil deste mundo é adquirir a disposição de um(a) guerreiro(a). Não adianta ficar triste, queixar-se e achar justificativa para isso, acreditando que alguém está sempre nos fazendo alguma coisa. Ninguém está fazendo nada a ninguém, muito menos a um(a) guerreiro(a)." 
" Um (a) guerreiro(a) é um(a) caçador(a). Calcula tudo. Isso é controle. Mas, uma vez terminados seus cálculos, ele(a) age. Entrega-se. Isso é abandono. Um(a) guerreiro(a) não é uma folha à mercê do vento. Ninguém pode empurrá-lo(a); ninguém pode obrigá-lo(a) a fazer coisas contra si mesmo(a) ou contra o que ele(a) acha certo. Um(a) guerreiro (a) é preparado(a) para sobreviver e ele(a) sobrevive da melhor maneira possível" 
- Viagem a Ixtlan - 
" O defeito mais intenso dos (as) guerreiros(as) imaturos (as) é que eles desejam esquecer a maravilha do que eles(as) vêem. Ficam dominados(as) pelo fato de que vêem e acreditam que é seu gênio que conta. Um (a) guerreiro (a) maduro(a) deve ser um paradigma de disciplina para vencer a quase invencível frouxidão de nossa condição humana. Mais importante do que o próprio Ver é o que os (as) guerreiros fazem com o que vêem" 
O Fogo Interior