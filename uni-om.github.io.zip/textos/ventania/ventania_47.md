---
layout: texto
tags: [pérola, mapa, prática]
texto_number: 47
category: ventania
---
Date:Seg Mar 12, 2001 2:30 pm
Texto:47
Assunto: Re: [ventania] Caminho, Treinamento, Realidade, Execução
Mensagem:688

Olá lista;
Olá Renata;

Vamos comentar os pontos que tu levantas pois são bem interessantes. 
Primeiro lembrar que não tem Júlio aqui, ou é Nuvem que passa, ou Guerrero, Júlio é outra espreita e vamos confundir energias se trouxermos isso prá cá, valeu? 
SE a lista quiser podemos ir mais fundo nesta questão da espreita. 
BOm , pura bobagem alguém achar que tua mensagem anterior foi "só prá implicar" . 
Tua mensagem foi bem interessante e válida mesmo e por isso a aproveitei para comentar, para mostrar que quando a mente racional pega um tema fica restrita a avaliar esse tema pelos seus parametros. 
O teu alerta tem total valor , podemos sim nos tornarmos rotineiros fingindo não ter rotinas, podemos mesmo cair na tentativa de sermos imprevisíveis fazendo disso uma rotina ainda maior. 
Aproveitei porém tuas colocações e mostrei como tudo pode ser também muito mais do que a mente racional pretende e foi por aí. 
Parece que muitas pessoas 'não conseguem dialogar, só conseguem impor suas idéias ou discutir. 
Isto é coisa de criação, meio onde nos criaram, pessoas que convivemos, precisamos por isso sempre estar atentos a uma boa recapitulação para irmos além disso. 
A proposta desta lista é ir além de todas essas puerilidades e nos colocarmos como buscadores sinceros , onde a grande meta é o TRABALHO, não a TEORIA é o que PERCEBEMOS< não o que achamos. 
Assim, os pontos que tu levantastes, do risco de a busca da não rotina ser uma rotina é um risco real de muitos que criam a rotina de não ter rotinas, quando a essência é ir além do estado onde a rotina nos prende. 
O ego avalia tudo pelo ego, assim para uma pessoa que está presa no ego, tudo é ego, por isso rotular alguém, ou deixar alguém preso a um conjunto do que "achamos" é apenas o ego funcionando e o que falei da mente concreta vale o mesmo para o ego, o ego vê ego em tudo, gosta de criticar e ficar avaliando e analisando os outros, o que indica que o trabalho consigo mesmo não está tão bem realizado assim, pois quando sobra tempo para cuidar da vida alheia é sinal que não estamos cuidando satisfatoriamente da nossa. 
Outro ponto alto desta sua última mensagem é a questão do "xamã pleno" . 
Bem lembrado que este papo de "xamã pleno" não pode ser visto como algo "acabado" "pronto" . 
Existem alguns conceitos que estão tão presos em nós que fica dificil irmos além sem deles nos libertarmos. 
Nossas idéias de absolutos estão aí. 
Embora tenham mudados os termos , muitos(As) ainda trabalham com o mesmo conceito de "deus" , "céu" , "inferno" , "bem" "'mal" , "pecado" , " alma" , "outras vidas" e por aí vaí. 
Não basta resignificar, isto é, dar outro termo ao mesmo conceito, temos que ir fundo e transformar mesmo o conceito e isso só é possível pela vivência, nunca pela elocubração mental. 
Num mundo infinito em constante desenvolvimento alguém se considerar pleno e acabado em algo é apenas uma forma diferente do orgulho se manifestar. 
Podemos dizer que "despertamos" , mas por analogia, acordar de manhã, não quer dizer que estejamos "plenos' com o dia, apenas que acordamos e temos a cada minuto, a cada segundo, o desafio de responder aos desafios que o mundo , que estar vivo nos oferece. 
PAra mim, estar pleno quer dizer estar inteiro a cada momento, respondendo com a totalidade do que somos a cada desafio e isto é em si um desafio, não é nada "acabado" ou final, é apenas o começo de tudo, antes sequer existimos, somos mera possibilidade. 
Plenitude é um estado de ser, quando deixamos de buscar em outros apoio e sustentação e aprendemos a "nos bastar". 
Mas isso é só o começo e temos mesmo de trabalhar árduo e é justamente quando acordamos, pois o sono hipnótico no qual vivemos nosso cotidiano permite um tipo de segurança( limitante e nefasta, mas existente). 
Comentava esses dias que trocar conhecimentos e informações para quem trilha o caminho é como um navegador ou um caminhante que troca cartas de navegação ou mapas de um território com outros. 
Ora , em ambos os casos, é a vida que está em jogo, se vamos trocar mapas temos que saber mesmo do que está no território, não "achismos" , tão pouco frases ditas para impressionar ou fantasias que outro leu. 
Pode ser que alguém nos mostre mapas que encontrou em livros , que nos mostre mapas que outros lhe deram ou contaram, mas é diferente falar do que nos falaram, contos de poder e partilhar o que nós mesmos vivemos. 
ESTe exemplo é bem concreto para mim, MAgia, Xamanismo é algo bem concreto e real para minha vida, cada instante é um desafio, pois é uma batalha de vida e morte, assim pretendo trocar mapas sobre territórios reais que investigo e vivo, não mapas fantasiosos. 
Também não me interessa se o mapa está escrito na língua sânscrita/céltica-neozeolandeza ou se tem filigranas de ouro, ou se foi do fulano ou beltrano, me interessa se o mapa é real, se mostra um território efetivo do CAMINHO e o quão bem representados estão os obstáculos e demais eventos deste caminho. 
Um trabalho pragmático, sem espaço para fantasias ou distrações. 
Já comentei que um (a) xamã quando treina um(a) aprendiz em potencial nunca está na mesma posição que um religioso convertendo, muito ao contrário. 
Estamos interessados em ajudar a desabrochar o ser interior que ali existe potencialmente para que surja mais um (a) companheiro(a) com o (a) qual possamos partilhar nossas inquietaçòes frente a ETERNIDADE que nos observa sempre. 
Somos como ARTISTAS que encontrando outros ARTISTAS em potencial ajudam no desabrochar destes (as) para que possamos ampliar nossa abordagem concreta e objetiva da ARTE. 
Não estamos nunca convertendo, palavra nefasta, nem querendo convencer ninguém de nada, muito menos dos nossos pontos de vistas, já que o que buscamos é justamente outras abordagens da mesma realidade que estamos investigando, com resultados práticos. 
Assim nada mais sem sentido que qualquer proselitismo sobre o xamanismo. 
Nada mais sem sentido que "discutir " com alguém sobre o xamanismo, já que as verdades do xamanismo só tem sentido para quem pratica e vistas só pela teoria parecem um verdadeiro samba do crioulo doido 
Quando vamos a público, quando fazemos palestras, quando estamos aqui na lista ou qualquer outro momento não queremos aparecer, queremos encontrar os da mesma tribo que por razões diversas podem estar a deriva neste mundo estranho e dominado. 
Isso é o mais sério nas obras de Carlos Castañeda entre outras. 
Grande parte dos conceitos dessas obras não são " a boa nova" para todos, é um conhecimento muito específico, para "praticantes". 
O xamanismo guerreiro , entre todos os caminhos xamânicos, é um dos mais rigorosos e dos mais específicos, isto é , destinado a quem tem a tempera de um (a) guerreiro(a). 
Várias vezes CARlos CAstañeda pergunta a D. Juan, mas o que isto significa para o homem (mulher ) comum e ouve como resposta: 
"Nada, não podemos assumir a responsabilidade pela humanidade, o que lhe digo é o que significa para um (a) guerreiro(a)." 
E ninguém é melhor ou pior por ser ou não do clã guerreiro, como ninguém é melhor ou pior em ser pianista ou violonista, apenas expressam a mesma ARTE em formas diferentes. 
Por sincronicidade um amigo comentava justamente esta frase comigo, que 
" conhecer o caminho é muito diferente de trilhar o caminho" . 
Isto é um fato . 
Sim , é muito dificil alguém deixar de "rotular" e "limitar " as pessoas a seus próprios limites e é por isso que dizemos no xamanismo que só quem perdeu a forma humana pode mesmo ajudar outros, do contrário vai é criar muita confusão. 
Nesse recente episódio que saiu uma fofoca boba que uma pessoa estaria usando drogas e tal é um exemplo disso. 
Tudo que foi armado foi pura fofoquinha boba, mas despertou preocupações sinceras por parte de pssoas que querem o bem estar da dita pessoa e tudo mais. 
Num grupo de trabalho isso poderia resultar em sérios problemas, já vi mujitos grupos tentarem se formar e acabarem justamente por isso, porque quem pretendia liderar não tinha resolvido sua forma humana, aí fica envolvido (a) com a energia coletiva do grupo e afunda junto em "paixões" e "ódios" tomando partido e fazendo bobagens diversas, ao invés de apenas rir da puerilidade de seres ainda dormindo e infantis brincando de gente grande. 
Sem a forma humana podemos nos limitar a ficar "pregando" nossas verdades ao invés de sentir o "fluxo da ETERNIDADE" que é o mais importante, que é o único caminho 'valido para um (a) guerreiro(a). 
Ajudar outras pessoas é uma das coisas mais dificeis que existem, pois só pessoas realizadas em si podem fazer isso. 
Do contrário estaremos projetando nossas angústias e inseguranças no outro e desejando que ele seja uma cópia do que queremos ser( e muitas vezs não o somos nem em nós mesmos) . 
Assim rotular a outra pessoa e dizer : " ah só podia vir dela(e) esse comentário> ", é apenas atrapalhar com nossos pensamentos a chance dessa pessoa se libertar dos condicionamentos nos quais está presa(o). 
Concordo contigo na tolice que é negar o caminho do outro como "falso" , "inferior" . 
Fico pasmo vendo pessoas tecerem juízo de valor sobre terceiros, porque outra pessoa é isto ou aquilo e está "longe do caminho" . 
D. Juan Matus é bem claro: " Voluntários não são os mais apreciados no caminho" . 
ESta frase é fantástica, se avaliada em seu real conceito. 
Gente que parece, na ótica de alguns, não ter "nada a ver com o Caminho" , ou "estarem por fora" são na realidade pessoas que podem estar já há muito dentro do Caminho, bastando apenas um toque para que tudo faça sentido e despertem, enquanto outras pessoas decoram livors como se decorassem a bíblia e se acham "iniciadas" quando na realidade podem estar léguas de qualquer acesso ao Caminho. 
Pois é de despertar que o Caminho trata, é de reestabelecer o contato com o CONHECIMENTO SILENCIOSO, é de estar pleno no AQUI e AGORA e não pessoas que decoram um monte de conceitos prontos interpretados de obras como a de Carlos CAstañeda e saem por aí declarando-se : "no caminho" . 
Total concordÂncia com esta tua frase: 
Essa espécie de eu-rotina q estabelece rótulos ou eu-mundo q vê as coisas sempre sob seu ego, acaba gerando diversas contradições, desentendimentos, desperdício de energia, dificuldade em lidar c/ o momento e c/ a nova experiência e o aprendizado, etc etc etc. Os rótulos me parecem uma certa queda no ego-mundo, e consequentemente fuga da abertura mente-universo, e muito possivelmente uma intolerância e falta de compreensão em relação ao mundo q lhes é diferente. 
É muito dificil encontrar quem tenha ido além disso, embora usem um sem número de termos novos vamos acabar encontrando as pessoas recaindo nestes velhos maneirismos. 
Muito boa tua lembrança de Nietzsche aqui, o problema do eterno retorno, pois quando vivemos presos ao passado nos condenamos a repetí-lo, ad nausean... 
"Redimir os passados e transformar tudo, "foi" num "assim o quis": só isto é redenção para mim. 
Vontade! - assim se chama o libertador e o mensageiro da alegria: - eis o que vos ensino, meus amigos; mas aprenderei também isto: a própria vontade é ainda escrava. 
O querer liberta; mas, como se chama o que aprisiona o libertador? 
'Assim foi': eis como se chama o ranger de dentes e a mais solitária aflição da vontade. Impotente contra o fato, a vontade é para todo passado um malévolo espectador. 
A vontade não pode querer para trás: não pode aniquilar o tempo e o desejo do tempo é a sua mais solitária aflição." p.124-125 (NIETZSCHE, Friedrich. Assim falava Zaratustra) 
Esta citação vale mandar de novo, como vale ler toda a obra citada. 
No outro dia, tive uma experiência desse tipo, dos rótulos, qdo conversei c/ um amigo meu e ele virou p/ mim e disse q eu só tinha escrito a minha msg sobre rotinas p/ implicar c/ o Julio. 
Rindo bastante, fique tranquila que isso nem passou pela minha cabeça, aliás quem sou para isso, sou só um espelho, me esforço para ser só um espelho da ETERNIDADE lá fora, mas tem gente que parece que não entende isso e fica querendo me fazer de guru. 
Depois que a gente contempla a ETERNIDADE< depois que descobrimos por exeperiência que somos NADA< que não valemos NADA que estamos aqui só prá cumprir um papel no organismo cósmico e que tudo que podemos ter vai vir do trabalho árduo , toda e qualquer forma de orgulhosamente ostentar estas posiçòes bobas caem por terra, se tornam' pó. 
Abomino os gurus, abomino toda tentativa de me prender nestes rótulos tacanhos, de quem é preguiçoso e precisa de muletas para ir em direção a algum lugar. 
É pura vaidade, basta perceber o sub texto de um (a) seguidor(a): "VEjam ele é o guru e eu sou seu seguidor(a)", 
É a vaidade do seguidor, pior que a do guru, pois quer ser importante parasitando o trabalho alheio. 
Daí que creio que os espertalhões que exploram os(as) seguidores(as) fazem bem, pois nada mais chato e pentelho que um (a) seguidor. 
SE busco a LIBERDADE , a prisão do guru me parece a mais nefasta, pois é sempre conivente com a prisão de outros, que adulando-se mutuamente, ficam a gerar falsidades e fantasias sem fim. 
No caminho dos(as) guerreiros (as) xamãs não temos gurus, mestres, nada disso, temos pessoas em busca da Liberdade e que pássaro busca a LIBERDADE amarrando as asas? 
O que digo, o que escrevo é para ser questionado, avaliado de acordo com tua própria vivência, nunca aceito passivamente, jamais "seguido" . 
SOu um ser livre, sem rotinas, pleno em mim mesmo e nisto está minha força, amante da TERRA . 
Sempre tem alguém que quer me usar como desculpa: 
"O Nuvem falou isso, o Guerrero falou aquilo" . 
Para estas pessoas repito o que sempre diz nessas situações minha grande amiga e companheira, Melina: 
"Me erra"! 
Sö rindo, se alguém quer aprender algo comigo aprenda a se sintonizar com a TERRA nossa fonte imediata, pois é isso que me dá força, eu que nada sou. 
Aprenda a acreditar em si e buscar com suas forças a autonomia moral e intelectual. 
Aprenda a ser senhor (a) de si mesmo e não permitir que nada nem ninguém determine seus passos, a não ser suas buscas interiores e sinceras. 
Seguidores são sempre menos que humanos e há que no mínimo ser humano para depois ir ao caminho dos (as) guerreiros(as). 
ESta lista é uma experiência. 
Uma experiência do Clã do ARco Íris. 
EStamos caminhando bem, não vamos deixar que a mesquinhes de nossa condição humana interfira aqui, vamos trazer prá cá o que temos de melhor em nós, não nossas tolices, que sempre são muitas . 
Pois este tem sido o desafio há eons, nós, tolos seres, que nada somos, desafiarmos e mantermo-nos inteiros frente a vastidão da ETERNIDADE. 

MENSAGEM 689
Sent: Monday, March 12, 2001 7:21 PM 
Subject: [Hecate] SExualidade, Xamanismo - txto longo
 
Olá lista;

Vou me atrever a dar alguns palpites nesta questão toda que está sendo levantada sobre sexualidade, especialmente porque estão falando de xamanismo junto e creio que é interessante deixar bem claro alguns pontos. 
Em primeiro lugar a obra do Doutor Carlos Castañeda é de fato notável, admirável, revolucionária, revela mesmo uma linha cultural que esteve ausente da história por todo esse tempo, é de tal forma nova e inusitada que no meio acadêmico formal é bastante rejeitada, é considerada ficção e não antropologia. 
CC. se tornou praticante do caminho que investigava e graças a isso nos dá uma informação muito mais rica que se fosse apenas um cientista social investigando "de fora" um outro contexto. 
Eu, pessoalmente , admiro a obra de CC. por ter encontrado em outras fontes ensinamentos similares e ter comprovado por mim mesmo, em meu corpo e experiências pessoais, grande parte das assertivas ali levantadas, tendo conhecido a obra depois destas experiências pessoais. 
Considero que a obra permite uma nova terminologia para muito do que é experimentado nas vivências xamânicas. 
P'ra mim ler a obra foi como ter vivido com um povo e não ter como contar a maior parte do que aprendi por nào ter termos para tal narrar e então encontrar alguém , que tendo vivido eventos semelhantes, foi ainda capaz de criar um vocabulário para expressar os novos paradigmas que aprendeu. 
Mas o xamanismo não é apenas esse caminho que ele revela, há outras linhagens de xamanismo e há outras abordagens da realidade que também são xamânicas e que tem outras abordagens do tema. 
Eu nem ia entrar nesse tema, creio que toda racionalização sobre sexo é meio equivocada e escrever é sempre racionalizar. 
No Taoismo existem os famosos conselhos da "Dama Misteriosa" ao Imperador Amarelo e um deles é: "evite toda racionalização sobre sexo" . 
Mas se o lado escorpiano vai por aí, a lua em Gêmeos dá aquela incentivada no "palpiteiro" então aí vai. 
Creio que o primeiro problema aqui é que as propostas que Castañeda e seu grupo recebem das pessoas com as quais aprendem não são "leis" , nem mesmo "normas" para todos(as). 
Fico impressionado como existe esta tendência de tornar um conhecimento altamente específico, destinado a praticantes formais em regras gerais para todos(as). 
Se lermos a obra no devido contexto vamos notar que D. Juan Matus ( que tinha diferentes nomes para cada aprendiz) nunca esteve interessado em "divulgar seu conhecimento" ou fazer qualquer tipo de proselitismo. 
Seu único objetivo era manter a linhagem, manter seu clã e para tal deveria encontrar pessoas com determinado "padrão" de energia e transmitir-lhes sua ARTE/CIÊNCIA, tudo para que estas pessoas um dia encontrassem outras e fizessem o mesmo e o elo não fosse rompido e a TRADIÇÃO, continue mantida ,como vem sendo há tempos incontáveis. 
Isto é muito dificil de entender neste mundo onde somos expostos a proselitismos e a religiões convertoras desde que nascemos. 
Se tem algo dificil no mundo de hoje é viver e deixar viver. 
Todo mundo acha que sabe o que é melhor pros outros e fica pregando e pertubando a paciência alheia com normas e verdades prontas, quando o caminho é singular, é muito próprio de cada um. 
Assim um(a) vem pregar uma coisa e o(a) outro(a) , com medo que tenha de praticar o que foi pregado, ao invés de dizer: "não é meu caminho" prefere dizer: "' é falso" . 
Generalizar é absurdo, se as propostas do caminho Tolteca forem generalizadas a espécie humana acabaria. 
Creio que isto se deve que a chamada realidade é muito f'ragil e só é mantida pela concernência e concordÂncia de muitas pessoas, assim sabemos, intuitivamente, que quanto mais pessoas creem em algo, mais real é esse algo. 
Para quem não tem a segurança do REal em si , para quem não tem a verdade do que crê afirmada em suas vivências, há uma necessidade muito grande de converter outras pessoas para que com muitos "crentes" , fique a sua verdade fortalecida. 
Dessa constatação vem a necessidade de pregar e converter outros para aumentar a força da "realidade" na qual acreditamos e vivemos. 
A energia sexual é tremenda, ela pode até mesmo ser acumulada , os acumuladores de ORgon de REich são uma prova disso, aliás Reich morreu( foi morto?) em parte por causa desse aparelho que foi transformado em verdadeira arma . ( quem estudou um pouco da obra dele sabe que ele e seus estudantes chegaram a fazer chover com tais acumuladores, em um deserto nos EUA.) 
ESte tema da sexualidade é recorrente, me lembro que já debatemos aqui há algum tempo quando falamos de MAgia Sexual. 
De novo creio que a grande questão é a mesma. 
Uma coisa é a sexualidade do dia a dia, para pessoas que querem apenas isso, a satisfação que a sexualidade pode oferecer. 
A parte exotérica de certos conhecimentos servem para essas pessoas, podem ajudá-las a resolver suas neuroses , seus traumas e problemas com sexualidade, algo que a quase totalidade desta civilização tem , pois transformou o amor em pecado e o trabalho em sacríficio. 
Outra coisa são homens e mulheres que descobriram o tremendo poder do sexo e estão usando este poder para outros fins, para outras estÂncias. 
Creio que tudo começa quando confundimos as coisas e queremos comparar a sexualidade de uma pessoa "normal" , isto é, uma pessoa que deseja e quer viver apenas de uma forma tranquila e com bem estar, sem nem muito ir além e alguém que tem um trabalho voltado para outras realidades, para algo que tacanhamente chamamos de Magia, digo tacanhamente porque toda palavra apenas alude, aponta, nunca expressa sem o apoio da experiência vivida . 
Existem muitos caminhos, os caminhos místicos, os mágicos e os filosóficos, os caminhos científicos, os caminhos artísticos. 
Cada caminho tem suas características e por cada caminho somos levados a desenvolver aspectos diferentes de nós mesmos. 
Na ciência por exemplo existem aqueles (as) que buscam através do pensamento compreender a existência e fazer uso das "leis" que descobrem, outros (as) entretando nunca saem do racionalismo, do uso limitado do que poderia ser a mente. 
Há os(as) que pensam e os(as) que raciocinam. 
Os(as) primeiros(As) são os que lançam a ciência na grande aventura da descoberta, os (as) outros lutam para que nada mude, para que suas idéias pré concebidas e o poder que tiram disso, não sejam ameaçados. 
EM todos os caminhos vemos isso, o caminho emocional é um preâmbulo ao SENTIR< assim temos caminhos devocionais que levam apenas a um embotamento supersticioso e fanático e caminhos devocionais que levam a uma fusão com o transcendente. 
Cada caminho tem suas regras e suas práticas, num caminho amplo e efetivo tais regras e práticas são decorrentes da observação direta, da constatação por parte dos (as) iniciados(as) de certas formas das coisas acontecerem, em um caminho dogmático regras e práticas vem do achismo e da superstição, muitas vezes objetivando manter os (as) seguidores(as) apenas como seguidores(as) e a elite dominante sempre com o poder. 
Os xamãs de várias linhagens consideram a Mulher como nutridora da Vida. 
ISto não é justo nem injusto, esses conceitos humanos não entram aí, é um fato energético e fato energético é prá ser visto, observado, contemplado enquanto energia, não para ser debatido com "eu acho isso ou aquilo" . 
BAsta observar num primeiro momento. 
Nós homens fecundamos a vida. 
Participamos da fase " festa" do processo, depois nos retiramos. 
Podemos apoiar, até mesmo energéticamente , a mulher durante a gestação, mas os riscos são só dela, se houver algum problema com o feto é ela que vai sofrer, no sentido físico mesmo. 
Quem nutre o feto, quem corre TODOS os riscos durante a gravidez é a mulher, isto é um fato, nem justo nem injusto, só um fato. 
Então neste primeiro momento já é a mulher que arca com a manutenção e desenvolvimento da Vida. 
Depois a amamentação e mesmo em termos sociais até atingir uma certa maturidade é muito mais a mãe que o pai que é responsável pelo amadurecimento e apoio da criança. 
( Existem pais notáveis que fazem um verdadeiro papel amplo aqui, mas por mais que queira um homem nunca vai gerar ou amamentar uma criança, estamos falando de fatos biológicos) 
Assim, observando a energia, observando os seres humanos enquanto entes energéticos, xamãs de várias linhagens descobriram que a mulher é mesmo a nutridora do Homem. 
Isto não é terrível, discordo completamente do jeito que o tema é apresentado na obra da TAisha Abelar, isto é maravilhoso. 
Os homens podem se tornar vampiros energéticos das mulheres, como filhos podem se tornar dependentes de suas mães de uma forma doentia, mas o fato da gestação e amamentação não é algo terrível, como o fato que as mulheres são as que mantém a espécie não o é. 
Alguém acha terrível a gestação? 
Alguém acha terrível e injusto a amamentação? 
No ramo de xamanismo que estudo isto é visto com admiração e respeito e o fato da mulher ser a nutridora da vida e de nós homens e' considerado um fato de energia, de poder para ser apreciado, não temido. 
Foram muito mais longe e perceberam que a energia base da ETERNIDADE é mesmo feminina e a mulher partilha dessa energia fundamental. 
Por isso a DEUSA é uma abordagem do TAO muito mais interessante que o Deus dos pseudo patriarcais, mas isso não quer dizer que a mulher seja superior ao homem ou toda a bobeira que levantam daí. 
EStamos noutra esfera e estes racionalismos não são convidados. 
Nós homens somos uma energia mais rara na existência, mais frágil e por isso , creem os xamãs, lutamos tanto para provar nosso valor, para nos impor, para nos crermos fortes e dominantes. 
Podemos tirar esperma do homem para fecundar a mulher, podemos fecundar "in vitro" mas sem útero, não se tem vida. 
Assim quando os (as) xamãs dizem que a mulher nutre e sustenta o homem é um fato energético que estão colocando, fruto da observação de incontáveis gerações de "miradores" que observando a energia, como ela flui e como se manifesta chegaram a esta conclusão, sem nenhum pré conceito. 
Aí vamos ao sexo. 
Como dizia Freud temos um problema sério. 
Nossa educação religiosa é muito precoce, somos expostos a idéias antes de termos maturidade para realmente elaborá-las e ao mesmo tempo nossa educação sexual é tardia. 
Isto gera 'vários problemas e é dificil ver esta questão sexual ser tratada no seu aspecto comum com tranquilidade. 
O sexo faz parte de um imperativo biológico: Reprodução. 
E para garantir que a reprodução vai ocorrer o sexo ficou ligado a algo incrível: Prazer. 
O prazer biológico é fantástico, é uma forma da Natureza levar o ser humano a realizar seu imperativo. 
O ser humano é complexo e sabe então desenvolver tudo o que tem para outras áreas, assim aprendemos a ter prazer sem ir até a reprodução, mas o imperativo biológico continua ali. 
Magistas sabem que toda relação termina com uma "cria" quer física , quer " astral" . 
Aï entra o conhecimento que para gerar o corpo de energia temos que saber canalizar a energia sexual , para que ao invés de gerar uma vida, gere o corpo de energia , que temos em potência. 
Acontece que poucas pessoas lidam bem com a sexualidade. 
Poucos(as) lidam bem com seus corpos, se sentem bem com a forma que são, que tem, que se manifestam. 
A vergonha do próprio corpo, a não aceitação do que somos fisicamente, tudo isto já atrapalha bem qualquer tentativa de ir ao sexo com naturalidade. 
Isso já gera um monte de problemas. 
TEmos ainda a questão da racionalização do sexo. 
É muito raro vermos duas pessoas realmente "transando" uma com a outra. 
Grande parte das vezes vemos uma pessoa transando com todas as suas fantasias e projeções , usando a outra como 
"tela" . 
Uma masturbação a dois. 
Mas uma relação plena mesmo, aquela que tu olhas no olho da outra pessoa, aquela que tu sentes cada toque, cada contato, o tom de voz, quando contemplas o sorriso, quando a presença de quem está contigo é tão prazeirosa que nenhuma fantasia ou imaginação é necessária, esta é uma forma mais rara de relação em nossos dias. 
É tão fantástico quando toda nossa pele toca a pele da outra pessoa, quando nossas línguas se encontram, quando os olhares se penetram tanto quanto os corpos, quando o falar é estímulo, quando ouvir a voz da outra pessoa é estímulo, quando a ETernidade se manifesta no corpo desejado e agora presente. 
É interessante que depois de uma relação sexual o que parece, para quem não "vê " a energia é que a mulher sugou o homem, aliás tem vários mitos sobre isso, como a vagina dentada e tal (ai-ai!!) 
O homem vem pelo impulso biológico, está excitado, a mulher ali, também excitada, o homem vai, começam as preliminares,, quando existem, o homem vai, penetra, entra e sai, entra e sai e então ejacula. 
Quando ejacula cumpriu o ditame biológico da espécie, mandou seus espermatozóides para tentar a reprodução. 
Vem a famosa "melancolia pós coito" , para a grande maioria dos homens, momento vulnerável, frágil. 
E a mulher? 
Mesmo que tenha atingido o orgasmo pleno, algo raro, pois as mulheres demoram muito mais que os homens para isso e sabemos que grande parte dos homens ejacula com uma pressa "doida" , como se fosse só isso, dar uma "rapidinha" e ainda ficar cobrando da parceira: " e aí, gozou? " pois agora a mulher que antes era tida como "cientificamente incapacitada para o prazer" , tem de "gozar" junto para que o macho se sinta o "foderoso" . 
Em tudo isso vemos que a sexualidade dita "normal" já é um grande problema mal resolvido na maior parte das pessoas , quanto mais não dizer da sexualidade que sai dessa "normalidade" e entra na MAGIA. 
A proposta do xamanismo guerreiro é bem complexa, fica dificil falar sobre a mesma, mas ela pretende que aqueles que praticam tal ARTE deixem os limites humanos e se atrevam a entrar em outras realidades, transmutando seus próprios corpos para isso. 
Portanto não estamos nos limites da "normalidade" aqui e é claro que não podemos ficar presos aos conceitos do "senso comum" e do cotidiano aqui. 
Ora, pretendemos deixar os limites humanos por superação, não por negação. 
Queremos ir além do humano e só posso ir além de algo se sou antes, plenamente esse algo, como só posso expandir a consciência se tenho consciência. 
Portanto antes de ir além da sexualidade comum, temos que passar pela sexualidade dita comum, temos que estar bem realizados e resolvidos nesse quisito, por isso o caminho do xamanismo que trilho começa por nos levar a assumir toda nossa sexualidade em plenitude da forma que ela é, para depois irmos além. 
Portanto, prá começar a conversa, não tem nada a ver interpretar esse caminho como negação, pois ninguém cresce negando, ninguém cresce dividindo, suprimindo. 
Crescemos quando ampliamos. 
Portanto o que está proposto no caminho xamânico não tem nada a ver com o dia a dia, nem com a proposta das pessoas que querem uma vida "normal" . 
Aqui estamos num campo, onde vamos entrar na herança de um saber que está oculto, que tem sido levemente apontado como esoterismo, o saber de como entrar conscientemente em outros mundos, de como desenvolver o corpo de energia que todos temos potencialmente. 
E para isso precisamos de um procedimento. 
No xamanismo não tem esse papo de "sejam bons e serão evoluídos" . 
Por isso dizemos que é ARTE , pois como a ARTE não basta o talento, tem que trabalhar para desenvolver este talento. 
Assim como um alquimista tem sérias regras para trilhar se deseja mesmo chegar a conclusão de seu trabalho, também quem trilha este caminho tem suas regras e propostas, que não são dogmas, são linhas de açao para se chegar a certos objetivos. 
Assim como um(a) alquimista pode morrer envenenado pelo uso inadequado das substÂncias que precisa em seu trabalho, também um (a) xamã pode morrer ou enlouquecer se não tomar as devidas medidas para ampliar e fortalecer sua energia. 
Assim, para cada pessoa que pretende mesmo ir fundo nas propostas do Xamanismo, entrar em sua parte eSotérica, existe todo um cuidado e toda uma 'serie de práticas para tal. 
Prá começar o xamanismo não considera que já tenhamos um corpo de energia funcional, crê que temos o germe dele, mas precisamos desenvolve-lo. 
Assim, estamos anos luz dos conceitos kardecistas e similares que dotam o ser humano com uma alma imortal e tal. 
Para nós, no xamanismo , isto é fruto de trabalho. 
No começo somos um amontoado de jeitos de reagir, de emocionar e de racionalizar, que existem com um propósito que não é pessoal, mas manter um fluxo de energia no organismo cósmico. 
Para o xamanismo toda a vida orgÂnica sobre a TERra, incluindo os seres humanos, existem para propósitos da TErra. 
Nós é que podemos trabalhar duro e adiquirir algumas coisas que por acreditarmos que temos acabamos perdendo: Individualidade, Imortalidade, etc. 
E para começar esse trabalho precisamos de muita energia. 
Aí começa a questão. 
Se precisamos de energia temos de aprender a não mais perdê-la. 
E o Sexo é um caminho de ampliar a energia de forma notável. 
E para a mulher isto tem este fator agravante, pois além de prestar atenção em seus hábitos, para sacar o que gera energia e o que gasta energia inutilmente, vai sacar que cada homem com o qual se relaciona deixa nela filamentos de energia que durante sete anos( o tempo aqui é uma aproximação) vai levar energia da mulher para este cara. 
Para quem tem muita energia isto não tem problema algum. 
Para quem quer uma vida "normal" também sem problemas, a mulher pode muito mais que isto, como temos mulheres que tiveram mais de 15 filhos e continuaram plenas, conheço algumas assim aqui no interior, inteiras prá vida. 
Mas para quem quer agora toda a energia para propósitos "xamanísticos" isso é para ser meditado e trabalhado. 
Por isso é tolo querer pregar essas idéias para todos (as). 
O que é dito aqui só serve para quem quer mesmo se trabalhar na trilha do xamanismo guerreiro e ir em direção as metas que tal CAminho propõe. 
Alguém pode ser uma bruxa poderosa, uma xamã curadora, ritualística, pode ser mesmo uma mulher realizada e plena neste mundo sem nunca se ocupar dessas questões . 
Mas se deseja chegar as metas propostas pelo caminho do xamanismo guerreiro, ou do Taoismo do Dragão , ou da EScola chamada de Quarto Caminho, de Gurdjieff, ou de certas escolas de Yoga, ou de certos caminhos tântricos , enfim, se tem por meta atingir um estado além do humano aí começa a ter sentido tudo o que é colocado aqui. 
Nós homens também somos orientados a não perdermos energia na ejaculação. 
Se formos ao TAoismo vamos encontrar a mesma idéia: 
"Cada ejaculação é um dia a menos de vida" . 
E não ejacular não pode ser um controle mental, isto é tolice, pode levar a loucura e ao desequilibrio, a taras das mais nefastas. 
O equlibrio para isso vem da respiração e do trabalho interior, do contrário todo o esperma poupado no não ejacular se perde em poluçòes noturnas. 
TRilhar esse caminho só por livros, sem um(a) mestre (a) que tenha em si realizada a meta é como aprender a nadar em águas turbulentas , através de um curso de correspondência. 
Só que tudo isso não é para ser colocado como regra para "a humanidade" , isto é para quem quer ir além , para quem escolheu o "caminho estreito" , para quem quer "ganhar o céu de assalto" , para quem deseja realizar a si mesmo e em si realizar a ETERNIDADE. 
Não é matéria para "crença" mas fatos energéticos que o (a) aprendiz é levado a constatar por si, se estiver numa linhagem autêntica, isto é uma linhagem que tem em si a força da TRADIÇÃO ancestral. 
Não é matéria para proselitismos, só tem valor para quem sabe o que vai fazer, o que está fazendo e onde pretende chegar. 
Por isso abordar esse tema só tem valor aproximado, dizer que existe e que tem sua forma de ser, mas é algo para prática , não para racionalizações. 
Tornar-se um(a) xamã não é algo simples, como tornar-se um alquimista também não o é. 
Um (a) alquimista vai precisar de profunda disciplina e dedicação , terá que enfrentar toda uma farsa de pseudo escolas que tentarão seduzi-lo e mesmo que encontre um caminho autêntico existem riscos tremendos na manipulação das substâncias e das práticas que irá aprender até chegar a realizar a pequena obra, condição para ingressar na Grande Obra. 
Um homem ou mulher que resolva se dedicar a trilha do xamanismo pode levar esse trabalho adiante por vários caminhos. 
Poderá aprender por várias linhagens e cada linhagem tem sua forma e seus objetivos. 
Alguns ramos de xamanismo pretendem metas que nem vale a pena citar , por falta de referencia na sintaxe usual da atual civilização. 
Assim, pretendendo tais metas, também terão objetivos e formas de lidar com tudo que está no caminho muito próprias. 
TAis questões passam por aí. 



-----Mensagem Original-----
De: "OUTSIDER" <>
Para: <>
Enviada em: Monday, March 26, 2001 12:56
Assunto: [ventania]


" Quando o rio e o ar estiverem sujos, quando o ser humano houver se perdido
completamente da linha da vida, quando os animais estiverem ameaçados, as
ancestrais árvores cruelmente abatidas, quando a doença e a tristeza
estiverem
dizimando o povo vermelho, virá uma nova nação, uma nova tribo.
Serão em grande número, surgirão de onde não se espera. Virão em muitas
montarias, sua magia diferente, terão artes que desafiarão a compreensão.
Serão de muitas cores, por isto essa Tribo será conhecida como Tribo do
Arco-Íris, eles virão quando o fim parecer certo, eles virão e curarão a
Terra..."
(Profecia do Arco-Íris)


" Dia virá em que a terra vai ficar enferma. Os pássaros cairão do céu, os
mares escurecerão e os peixes aparecerão mortos nas correntezas os rios.
Quando esse dia chegar, os índios perderão seus espíritos. Porém, vão
recuperá-los para ensinar ao homem branco a reverência pela terra sagrada.
Então as raças se unirão sob o arco-íris para terminar com essa destruição.
Será o tempo dos guerreiros do arco-íris."
(Ojos del Fuego, uma velha índia cree)



Outono;
Olá lista;

Nuvem que passa se aproximando da fogueira virtual por outra interface.
Vou comentar vários mails em uma mensagem só.



Estive no Rio esses dias, nestes dias pude observar como o Rio é uma cidade
que ainda respira o poder das épocas de Baldazir e dos outros fenícios,
Cartaginenses e alguns outros povos de lugares bem menos conhecidos, que
aqui
aportaram, quando a Gávea era uma esfingie e quando o morro dois irmãos eram
captadores de energia para manter o sistema de uma civilização que viveu
numa
era anterior a essa, fora dessa linearidade cognitiva a qual fomos presos,
quando nos fizeram a acreditar que sõ a descrição da realidade oficial tem
valor ou efetividade.

Coisa incrível acreditarmos nisso, pois o fato mais evidente a quem observa
a
vida é que as soluções do sistema são as que menos funcionam, são as que
mais
desequilíbrio geram e ainda assim continuamos a insistir e a treinar nossas
crianças para serem como nossos pais.
Cada grupo humano que surge na terra vem com todo um potencial acumulado que
supera em muito a geração anterior.

No opressor sistema de dominação que o mundo foi transformado enfraquecemos
as
pessoas com a desculpa de educá-las.

É muito importante pensar e sentir sobre isso, para entendermos isso antes
de
mais nada em nós mesmos.
Fomos enfraquecidos, medos foram calcados em nós, disfaçar a auto piedade
com
importância pessoal é algo que faz parte do "currículo oculto" que é o
verdadeiro curriculo da quase totalidade dos sistemas educacionais e
religiosos hoje existentes.
E quando somos manipulados em nossa relação com o mundo, quando nossa
percepção é propositalmente reduzida nos tornamos menores que nós mesmos,
menos do que realmente somos e então passamos a servir este sistema de
dominação e coisificação que nos envolve.

Me parece que o problema principal do "ego" é esse.

Sua real e efetiva inexistência, mas nossa crença ilusória que cria um
simulacro de ego com o qual nos identificamos e confundimos.
O apego é a fonte de todo sofrimento.

Medite se não é o apego que gera sofrimento.

EStamos apegados ao nosso ego.

Entendendo por ego essa personalidade fraca e caprichosa que a maioria de
nós
parece ter, fruto de um sistema que nos condiciona para que nos tornemos
extensões biológicas das máquinas .


Quando entendemos isso podemos ir muito mais longe e nos livrando do apego,
nos livrarmos do conjunto de jeitos de reagir , emocionar e raciocinar que
usamos no nosso cotidiano, quando estamos robõticos e ausentes de nós
mesmos.

Isso é um fato do ego, sua habilidade em nos tirar do único lugar que existe
de fato, onde podemos existir de fato: O Aqui e o Agora.

Tempo e Espaço.

Um continuo.

A abordagem clássica, do senso comum, permitiu o desenvolvimento da
Revolução
Industrial.

Quando coisificaram a natureza e também coisificaram o ser humano, abriram
caminho para o tipo de atividade que gerou a revolução industrial e como
subproduto este mundo agressor, agressivo, desequilibrado e em crise que
vemos
a nossa volta.

O poder de estar no aqui e agora é tremendo, quando entramos neste estado de
agir que nos coloca no aqui e agora nos permitimos estar num fluxo que é
diferente do fluxo da sociedade constituida e embora possamos nela estar
presentes em ato , podemos de fato estar sós no meio da multidão.

Estar no aqui e agora é um estado fundamental para qualquer papo sobre
xamanismo.

È muito interessante como algumas pessoas se aproximam do xamanismo julgando
que vão entrar em algo exótico, usar meios diversos para alterar a
consciência
e depois voltar, de forma segura , para o mesmo mundo "seguro" em que sonham
viver suas vidas.
E o que o xamanismo propõe é bem mais revolucionário, por isso bem mais
simples e direto.
TRabalharmos usando a realidade a nossa volta, eis nosso melhor laboratõrio.
Mas podemos ir além dos paradigmas dominantes hoje e não coisificar a
natureza
a nossa volta, nem as pessoas.

REspeitar o dom da vida em cada ser humano, perceber a magia que cada pessoa
carrega dentro de si é algo que exige energia e mesmo um trabalho, pois a
mente comum é bem mesquinha e insegura e raramente consegue estabelecer uma
relação harmonica mesmo dentro de nós mesmos que não dizer de relações com
outras pessoas...

Há efeito no Xamanismo quando efetivo.

Viver as premissas do Xamanismo é atrair para a sua vida o INTENTO refinado
atraveés de eras , por homens e mulheres que também trilharam este mesmo
caminho.

E partilhar de tal Intento é algo exigente e não pode haver briga em nosso
interior , se queremos mesmo partilhar do tremendo poder que existe em todos
nós, a espera apenas que tenhamos a chance mínima, o milimitro cúbico de
sorte, de ao menos sabermos de que temos tal energia e que podemos de fato
ir
além do que nos condicionaram para ser.

O xamanismo guerreiro por exemplo veio de uma tradição muito exigente e por
isso, uma vez que sobreviveu apesar de toda a opressão e perseguição, da
eliminação efetiva durante muito tempo, como na Inquisição, existe em
paradigmas que não tem nada a ver com a forma de compreender o mundo do
sistema que estamos.

É muito importante entender que o mundo mágico que o xamanismo revela só é
sobriamente vivenciado quando estamos no aqui e agora.

O " aqui e agora " não são palavras vazias.

TEm que ser realmente sentidas.

Como eestá sua postura?
Como está tua respiração?
Que sons ouves?
Que cheiros chegam?
Onde estão tuas emoções, sensações, racionalismos ?

Espreguiçar é um exercício dos mais fundamentais.
FAlamos de L.E.R. .
Espreguiçar muitas vezes por dia e trabalhar as articulações, como
exercícios
com hashis( palitos que servem como garfos na China e Japão)/

Mingau de fubá com menstrus . ( erva que dá rasteira, verde é melhor para
ser
usada. Age nas capsulas sinoviais e nos ligamentos )


Se espreguiçamos de tempos em tempos vamos mantendo todo o corpo numa
tonificação adequada, que nos permite continuar em ação de forma plena.
Espreguiçar é algo que se aprende com o clã dos felinos

PAra a gente que trabalha muito com computador , tecla muito, é fundamental
estar consciente da nossa postura, pois o corpo quando está numa postura
consciente e relaxada ele opera de forma mais natural e rápida, sem
tensionar
e desgastar-se.

Comecei este mail com duas das "visões" nativas sobre os tempos que
estamos
vivendo.

Por isso quando falamos da ação da Tribo do Arco Íris falamos de um trabalho
verdadeiro e incisivo, um trabalho que nos permita estar em tal sintonia com
a
VIDA que a ajudemos a CURAR o SER TERRA no qual vivemos, cumprindo a antiga
Visão.

O que é a REALIDADE senão a realização da Visão de mundo que escolhemos?
Escolhemos aceitar ativamente ou fomos condicionador a tê-la como única e
final.

Quando vivemos nossas vidas dentro da PRESENÇA de nós mesmos nos colocamos
no
único espaço singular que temos, no ponto onde somos algo completamente
singualar.

Quando nos tornamos de fato, a essência perceptiva, quando nos permitimos
ser
PERCEBEDORES e deixamos de interpretar com base em cõdigos convencionaods e
linguagens, mas apenas SENTIMOS e deixamos que nos toque a energia emanada
do
que é observado, nesse estado estamos sendo entes perceptivos em contato com
a
essência que emana, não com a leitura social que posso fazer do que estou
percebendo.

Em outras palavras, estamos percebendo o que é, não o que nos disseram que
era.

E constatar por nós mesmos que podemos ser felizes e realizados, que podemos
realizar efetivamente nossas vidas no aqui e agora, ligados a ações
coerentes
com as propostas da TRibo do Arco ìris, isto é o que chamamos de ação
incisiva
e com ações incisivas que a Tribo do ARco ìris AGE para curar a Terra.


Paz e Luz na Presença;

Eu Nuvem que passa falei e passo o bastão!

Ho!!!


-----Mensagem Original-----
De: "OUTSIDER" <>
Para: <>
Enviada em: Tuesday, March 27, 2001 11:03
Assunto: [ventania] Taoismo e Xamanismo - Faces diferentes da mesma arte



" Podes fazer o corpo e o espírito se harmonizarem a ponto de se tornarem
inseparáveis?
Podes tornar tua respiração terna e suave como de uma criança?
Podes anular os pensamentos até purificar toda tua energia?
Podes governar o império beneficiando a humanidade por meio da não ação?
Podes ser totalmente passivo, vendo abrirem-se e cerrarem-se as portas da
Eternidade?
Compreendendo estas coisas podes permanecer como se não compreendesses
nada?"




Aloha Ventanias;

O trecho acima é do Tao Te King, o livro deixado por Lao Tsé ao deixar a
China, quando da instauração de um estado de coisas nos quais ele percebeu
uma
era de deterioração e resolveu deixar o local.
Conta a tradição que ao atingir as muralhas um dos guardas, admirado de sua
sabedoria, pediu-lhe que deixasse algo escrito, para quando o período ruim
passasse e novamente as pessoas buscassem o conhecimento essencial.
Deixou-nos então o sábio, graças a este misterioso guarda de fronteira cujo
nome não sabemos, o livro , repleto de textos como o que está escrito acima.

O Taoismo é de natureza Xamânica, ou se quiserem o Xamanismo é de natureza
taoistica.

Antropológicamente vamos encontrar em estudos sobre o taoismo essa
afirmação,
é uma tradição que se enquadra no Xamanismo.


Ambas as escolas são caminhos que prezam valores e lidam com paradigmas que
fazem da natureza algo vivo e dinâmico, que permeiam a realidade a nossa
volta
com mundos e seres e que trabalham com o desenvolvimento pleno do ser
humano.


Quando chegamos no caminho temos muitas fantasias em nós, muitas projeções
que
nos iludem e podem mesmo nos confundir a tal ponto que podemos perder o elo
com um Caminho e nos conectarmos a coisas fantasiosas apenas porque
satisfazem
e compensam nossas carências e medos .

A estrutura de um Caminho é complexa e o melhor é não se iludir , pois agir
a
cada instante como se fosse o último, ter foco no momento, ter um estilo de
ação que expressem atitudes implacáveis, astutas, pacientes e gentis, tudo
isso com sobriedade e desapego , não são palavras vazias, mas estilos
comportamentais que são como katás (katis) , treinos onde fazemos os
movimentos para ensinar o corpo a agir por si e com eficiência quando
necessário.



Artes Marciais diversas emanam do Taoismo, os Hsiens taoistas das montanhas,
eremitas ou vivendo em pequenos grupos em cavernas nas faldas do Himalaia
são
exemplos de taoistas tem também a imagem que temos de um(a) xamã: alguém que
cavalga o poder.

As pessoas com as quais estudei tinham uma profunda influência do Taoismo,
Oomoto é da região do Cantão, na China .
Por isso tenho trabalhado bastante nessa interface entre a abordagem taoista
do mundo, originário de uma cultura complexa e ancestral e o xamanismo, que
também é , em seus vários ramos, originário dos povos nativos, em conexão
ampla com a ancestralidade.

O Taoismo aborda a realidade com grande similitude ao Caminho dos (as)
guerreiros(as) Xamãs.

Diferenças apenas no sentido de usar uma outra linguagem, uma linguagem que
se
afasta mais do ocidente e se parece mais com a linguagem que os antigos
Maias,
Toltecas, Olmecs e outros usavam.

CAda ideograma da língua chinesa é muito rico em conteúdo.
Por isso ler uma tradução do Tao Te King é sempre uma aproximação da
expressão
original, como ler Nietzsche traduzido é sempre uma aproximação em
compreender
esse homem que antes de filósofo era um poeta.

Meditar sobre um texto desse permite conexões sutis.

O corpo e o espirito se harmonizarem .
ESta é uma proposta do xamanismo guerreiro, se considerarmos o termo
espírito
aqui como o corpo de energia.
COnsiderando ainda espirito como a energia da Totalidade, podemos levar
nosso
corpo a harmonizar-se com a realidade a nossa volta.

O Xamanismo trabalha com esta idéia e o Taoismo também, levar o corpo a
despertar , a eliminar de si todas as impurezas e toxicidades que possam ter
nele se impregnado e então começar uma trilha de poder em direção a
plenitude
do contato com a energia viva que nos circunda em vãrias estâncias, uma
força
polar , uma força que hora opera num espectro , hora noutro, que flui e em
seu
fluir solve e coagula, criando e destruindo com isso , tudo que existe.
Entramos no meio desse fluxo e começamos a aprender como usar desses fluxos
para nossos fins, para atingirmos nossas metas.

No Taoismo temos um caminho similar e em ambos o que espera o (a) viajante é
o
frio olho do dragão que mira a ETERNIDADE.

Nuvem que passa

falei.

Passo o bastão.

HO!