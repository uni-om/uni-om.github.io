---
layout: texto
tags: [mapa]
texto_number: 49
category: ventania
---
Date:Ter Abr 3, 2001 12:59 am
Texto:49
Assunto: Outros TEmpos e Espaços
Mensagem:771

OS tempos que estamos vivendo são bem complexos. 
Como nunca as forças da destruição estão poderosas, agora , tão perto da reconexão com Hunnab Ku há ao mesmo tempo este risco de destruição real desse nosso plano da realidade, como as lendas e contos dos viajantes entre mundos já narraram ter acontecido com outros. 
A Amazônia é um exemplo concreto da destruição sistematizada da Màe Terra. 
. 
Na Amazônia estão os poucos remanescentes em idade plena do povo árvore ainda em grande quantidade, já nas outras matas em nosso território foram também dizimadas, como as nações nativas. 
As árvores são poderosas guardiÀs contra certos tipos de parasitas que vagam pelos mundos, capturando espécies ainda imaturas para delas fazer seus hospedeiros, levando-as a produzir o tipo de emocionalismos mórbidos e desequilibrados que tem como alimento principal. 
Note como a civilização dominante, que é a civilização dos escravos dos parasitas, tem uma guerra com as árvores. 
Que tragédia para o SER TERRA ter tais forças dizimadas pela civilização dominante, câncer, virus sobre a Terra a reproduzir-se indiscriminadamente, levando ao colapso e a morte o organismo hospedeiro. 
Onde o povo nativo estabelecia uma relação mutualistica e simbiótica com as forças e faces da TERRA o tido civilizado apenas vê o mundo como fornecedor de matéria prima . 
E vai lutar para garantir a continuidade de seus esquemas, baseados todos na proliferação desequilibrada, que acaba quebrando a homeostase do sistema hospedeiro, o SER TERRA que é no qual vivemos. 
Uma das propostas da TRIBO do Arco Íris é restaurar a relação harmônica com o mundo que os povos nativos tinham. 
Os ecos disso já se fazem sentir, hoje um dos certificados mais cobiçados é o ISO 14.000 que é um certificado que desde a captaçao da matéria prima até a entrega do produto , tu não causas danos ao meio. 
O lótus tem a inquietante habilidade de brotar do lodo mais sórdido... 
Cá estamos, de volta a uma cultura mundial, de volta a uma cultura planetária, mas ao invés do conselho de homens e mulheres prenhes em sabedoria, dotados da VISÃO, nossos governantes são fantoches nas mãos de lobys diversos, de grupos de pressão que os levam a dançar conforme a inumana música do mercado financeiro, pois da saúde a guerra, da vida a morte, no atender das mais básicas nescessidades, como comer e beber ao mais artificiais e caprichoso desejos estimulados pelo artificialismo do sistema, tudo isso está tornado neste mundo em valor monetário. 
A Economia não estuda mais a distribuição equipotente das riquezas naturais e das produzidas pelo homem, mas se tornou um sistema mecânico e insensível, onde o fator humano, o fator felicidade humana, nunca é contabilizado nas planilhas, exceto os caprichos dos que se consideram a aristocracia reinante, quase sempre por um direito divino pactuado entre que diz o que é divino e quem recebe as melhores benesses de tal divino. 
A ARte e a REligião estão enredadas no comércio e o que devia ser um brilho na escuridão, uma ponte entre eternidades, o toque sutil que revela a cada um de nós a nossa conexão com a TOTALIDADE se tornou vulgar simulacro, ópio. 
Se venderam, de formas sutis se entregaram, mas no seio de ambas resistem ainda aqueles homens e mulheres que em todas as eras tem cumprido o testamento de seus ancestrais e salvaguardado este ancestral saber que emana dos tempos míticos até nossos tempos imersos na limitação e na escravidão de um racionalismo estéril. 
A cura agora é rico negócio e doenças são criadas para justificar o uso de todo um esquema que só quer gerar lucro, alimentar coorporações. 
Curar , a ARTE do(a) curandeiro(a) foi perdida aqui. 
"Curandeirismo" agora é crime no código penal. 
Aqui estamos, com armas nucleares, com usinas nucleares, com mais de 40 valises com ogivas desaparecidas ( A URSS criou mais de cem valises com ogivas num plano louco de revidar um ataque, quando acabou reuniram as valises das repúblicas e descobriram que mais de 50 estavam faltando. Uma ogiva dessas dizima uma metrópole.) 
ESta civilizaçao que trouxe uma tecnologia predatória e continua negando os OVNIS ou criando uma cortina de fumaça fazendo-nos crer em Extra Terrestres de distantes mundos, quando os de tipo humano que voltam, sim voltam, são antes de mais nada os que não ficaram neste mundo prisão. 
Os Anassazi, Maias, Olmecs e outros povos que quando da constatação dos tempos que viriam durante o eclipse de Hunab Ku migraram para outros mundos, como em tempos ancestrais outros haviam feito, como enquanto clãs e individuos muitos ainda hoje, o fazem. 
Para entender isso temos que voltar ao modelo do mundo como uma vasta cebola com muitas camadas. 
O desafio de sonhar é tremendo porque uma nova percepção da realidade vai se aproximando. 
Aí dá prá entender que tudo que nos contaram tem uma limitação básica: 
Foi contado. 
As palavras aludem, podem apontar, mas temos que ir além do dedo que aponta para vermos a estrela almejada. 
O mundo tal qual o conhecemos, o que chamamos da realidade é só mais uma camada da cebola, só mais uma condição de vibração da realidade. 
Somos um mundo com esferas dentro de esferas, nichos dentro de nichos e isto é real além deste contínuo de espaço tempo que temos agora. 
Os Toltecas chamam de TONAL dos TEmpos, o estado singular de cada época, de cada Ciclo, de cada ERA. 
É um conceito complexo, que os Maias e tantos outros povos tem procurado notar e entender. 
Os taoistas foram muito felizes em sua abordagem do tema , pois ao invés de ficarem presos em concepções lineares ou circulares simples , foram além, criando abordagens extremamente fluídas dessa realidade circundante 
Quando a instalação alienígena foi colocada em certos ramos da espécie humana vamos assistir algumas tribos, isso em todo o mundo, começando um novo ciclo da história, a convivência entre as tribos muda, um tom agressivo é tomado, a mente alienigena com toda sua morbidez, com toda sua ansiedade e necessidade de poder, de manipular vai dominar alguns povos e estes se tornaram algozes dos que antes conviviam em harmonia. 
Uma abordagem antropológica desse momento pode ser vista no filme Instinto. 
O sentido de batalhas antes desse momento era outro, os povos que batalhavam tinham uma noção tão distante disso que nem dá prá citar usando a sintaxe dessa linguagem, gerada no sistema dominante de atitudes bélicas opressoras. 
Assim , em vários lugares do mundo tribos atacam outras tribos, criando escravos, criando um novo sistema de coisas. 
Filósofos na Grécia defendem a escravidão, instrumentos vivos, pois com escravos a fazer o básico, o plantar, o colher , o cuidar do fundamental de um dia a dia, limpeza dos lugares onde estão, detalhes assim, podem os filósofos " filosofar" , abstrair, num sentido e abstrato que quer mesmo dizer : desconectado com o agir. 
E no México ancestral homens e mulheres feiticeiros criavam exércitos e os incitavam a atacar povoados trazendo escravos para que pudessem se envolver em suas misteriosas práticas, assim também como sacrificios aos deuses e deusas sedentos de sangue que estes conquistadores começavam a servir. 
Isso começa a mudar tudo. 
Vamos perdendo contato com o TOnal anterior e um novo tonal dos tempos surge, que vai se transformando até chegar nesse tonal limitado e escravizador que temos por "realidade " . 
Os Toltecas foram surpreendidos no auge de sua vastidão,quando eram capazes de se projetar , juntos, em viagens espetaculares em seus templos de pedra. 
EStavam tão mergulhados na vastidão que não tiveram defesa frente aos limitados mas determinados conquistadores, que vieram e quase destruiram tudo que encontraram. 
Esses templos ancestrais tinham as condições de ressonância adequadas e podiam sair dessa realidade e se reconstruir em outras condições da realidade. 
Nem todos os povos nativos foram conquistados ou dizimados. 
Isto é outra mentira que se conta. 
Muitos povos não voltaram a este mundo sob conquista, levando até mesmo as cidades de pedras onde viviam para mundos outros que nao esse. 
ASsim, este simples dado dos mitos de vários povos que estou narrando aqui já nos chama atençao para algo importante. 
Os ovos não estão mais todos no mesmo cesto. 
A espécie humana já superou e migrou além desse mundo, além desse orbital de energia, se quisermos uma imagem mais atual. 
Absorvendo energia, fótons, energia pura do sol, povos inteiros deslocaram sua consciência para fora deste orbital, fizeram o salto quântico e continuam por vezes saltando para orbitais de mais energia , e outtros de menos energia. 
Nós somos um desses orbitais. 
Há sempre uma tendência dos elétrons a irem para os orbitais de menos energia. 
Estados de maior repouso. 
Assim esses povos também passam de orbital em orbital e precisam passar por esse mundo orbital que vivemos também. 
ESte é o sentido de dizer que os MAias estão voltando, assim como os Anassazi e os Olmecs ( estes dois últimos nomes não é o nome pelo qual estes povos se conheciam, mas o modo pelo qual outros os chamavam). 
Eles estão fazendo sua dança orbital, navegando entre os orbitais possíveis na existência, como todo ser vivo, consciente e livre faz. 
Não é bem que "voltam" eles estão continuando o caminho , passando de novo por este orbital, como já fizeram enquanto nação por várias vezes e depois partiram de novo. 
Mas como compreender o que é ser vivo, consciente e livre nesta civilização? 
A maior parte da civilização nem mesmo a condição de vivo parece presente, uma sobrevivência tacanha, infeliz, pertubarda, a servir sonhos alheios, com algo de medo, algo de culpa e ausente a condição de vivo ausente estará ser consciente e livre. 
A compreensão que temos da realidade ainda está presa a preconceitos muito fortes da idade da "razão" , do iluminismo europeu. 
Tem gente que quer explicar a complexa abordagem da realidade dos nossos ancestrais nativos, os xamãs da antiguidade, usando idéias de agora. 
Então querem que as monumentais marcas em pedra tenham sido erguidas por "naves" , lasers, coisas iguais as naves dos filmes de ficção e é o mais moderno que concebem. 
querem ler a complexa tecnologia de nossos ancestrais, mágica em essência, com os brinquedos desta era tecnológica. 
ESte tipo de leitura só confunde. 
Outros querem que os egípcios tenham conhecido a eletricidade, nas formas tacanhas que ainda a concebemos . 
Querem limitar o vasto passado as prisões conceituais da atualidade. 
A ARTE / CIÊNCIA destes tempos ancestrais era de uma amplitude que temos de ser levados a presenciar sua realidade, não intelectualizar. 
Assim me parece que este tema também tem relação com nosso assunto da evolução que estamos abordando.