---
layout: texto
tags: [mapa]
texto_number: 5
category: ventania
---
Date:Sex Abr 21, 2000 7:10 pm
Texto:5
Assunto: Re: [ventania] Xamanismo tolteca- Artigo Longo

Caro amigo virtual Nativo. 
Sim, meu propósito é criar um grupo que se adeqüe ao regulamento. 
As pessoas com as quais estudei me disseram que existem muitas linhagens rompidas no nagual. 
Como se fossem "tomadas" que ninguém está usando. 
A energia de uma linhagem Tolteca pode catalisar e muito a proposta ulterior deste caminho que me parece bastante válido: Liberdade total, arder no fogo da consciência. 
Mas um grupo dentro do regulamento do mito Tolteca tem peculiaridades muito importantes. 
E grande parte do realmente importante dentro de um trabalho assim não está nem de leve mencionado nas obras que contam um pouco da trilha Tolteca. 
Um grupo se forma não por escolha de qualquer das pessoas que nele estão. 
Não pode ser assim. 
Um grupo se forma porque cada um tem uma característica energética de um tipo que corresponde ao "Mito" que o grupo vai manter. 
Como numa orquestra. 
E os critérios de escolha não são de nenhum membro da orquestra,. nem, do maestro, é de quem nos dá a partitura que vai ser executada: O INTENTO! 
Por isso lhe afirmo que não tenho a mínima idéia de número no grupo, que vai entrar quem vai sair, quem pode entrar , quem pode ficar, tudo isso flui, eu mesmo fazendo parte desse fluxo. 
Este é um aspecto do tema. 
O outro é toda a riqueza de informações que podemos trocar dentro da lista. 
Quanto a este aspecto, a leitura que podemos fazer das obras publicadas sobre o tema, o contato que podemos trocar sobre nossas experiências individuais, tudo isso pode ocorrer, a lista aliás é um excelente veículo para isso. 
Mas quanto ao "grupo" , meu caro, isto nada pode ser feito. 
Não se "faz" um grupo nesse sentido. 
Apenas deixamos fluir, apenas deixamos o Intento se manifestar. 
É um fazer ligado ao não fazer. 
Se vamos ser 8-16 -20 -24 sinceramente nào sei, não há como saber. 
Essas coisas não se decidem assim. 
Minha mente não funciona mais assim. 
Busco apenas ;ler os augúrios e viver por eles. 
Entendo sua busca, é a minha também, mas creio que o trabalho agora é lembrar de nós mesmos, resgatar nossa condição perceptiva, libertarmo-nos completamente de tudo que nos programaram para ser. 
Organizar a ilha do Tonal, pois só com a ilha do Tonal muito bem organizada poderemos nos abrir, naquela parte deixada vazia e silencioa, ao nagual e realmente senti-lo e realmente vivência-lo, sem fantasiar, sem projetar no transcendente qualquer irresolução do imanente. 
Há um meio de contato para trocarmos nossas impressões sobre o trabalho, estamos em contato via lista, se os augúrios soprarem nos encontraremos em outros planos. 
Podemos somar, ampliar nossos horizontes perceptivos pela troca de experiências e vivências, como cientistas fazem em relação a realidade. 
Mas quanto ao grupo do regulamento, é um tema fora de questão tanto aqui na lista como pessoalmente. 
É uma privacidade deles percebe, eu optei por me unir ao movimento da Tribo do Arco Íris com toda a exposição que isto significa. 
Como sabe o caminho referido presa a discrição e o passar despercebido. 
Assim espero que entenda que não estamos fazendo mistérios , ou nos considerando algo diferentes , a parte, ou qualquer tolice do gênero, apenas existe um regulamento, os que seguem e eu sou só uma parte do elo. 
Meu papel aqui é outro, é colocar minhas habilidades a serviço desse momento, dessa luta entre as forças da consciência e da inconsciência e tive por bem fazer isso como xamã e curandeiro, daí nosso trabalho nessa lista, fortalecer o movimento da tribo do Arco íris. 
Lembre-se que o erro dos antigos videntes foi esse, formar grupos a partir de escolha própria. 
Acabaram criando teias de dependência . 
O regulamente coloca claramente que um grupo do nagual não se cria assim , com o racional. 
Ele acontece a partir de augúrios irrefutáveis . 
É assim que trilho meu caminho, caro Nativo. 
Mas paralelo a esta idéia de grupo dentro do regulamento, há outro trabalho muito importante se realizando. 
A tradição da tribo do Arco Íris precisa de nossa união para curar a Terra. 
Pela primeira vez o mundo está ameaçado de total destruição. 
Agir é muito importante. 
Por isso creio que nossas forças podem se unir nessa proposta comum e podemos trocar muitas informações neste tempo de convívio, experiências de caminhos que trilhamos que podem nos auxiliar em nossas jornadas individuais. 
Mas o gerar de um grupo nos moldes do regulamento extrapola completamente o que esta lista propõe, que é ser um fórum de debates, uma fogueira de conselho onde troquemos experiências. e fortaleçamos o mito da tribo do Arco Íris. 
Um grupo dentro do regulamento é algo urdido lá fora, na Eternidade. 
É um poder maior que nós, algo lá de fora, que sussurra entre os mundos, que vaga entre as realidades que tece as coisas aí. 
Não dá prá falar nisso, só aludir. 
Nós apenas lemos os sinais e compomos aquilo que vem do Intento. 
Um grupo se forma , não se faz. 
Mas é uma diretriz de outro ciclo. 
Quiçá seja sua tarefa demonstrar que um grupo dentro do regulamento também se faz, seja sua "tarefa" criar por seu próprio esforço um grupo que crie a coesão necessária para entrar no nagual "sonhando juntos" . 
Seria fantástico isso, pois o poder está sempre se realizando no novo e no inusitado.