---
layout: texto
tags: [pérola, mapa, prática]
texto_number: 50
category: ventania
---
Date:Qua Abr 4, 2001 1:38 am
Texto:50
Assunto: Identidade
Mensagem:778

Aloha Ventanias; 
Algumas pessoas me perguntam umas coisas em pvt que deviam mandar prá lista, pois o assunto é danado de bom. 
O problema é que a timidez é um grande desafio, e é uma marca do quanto somos auto importantes, pois a auto importância nada mais é que a auto piedade disfarçada , fazendo joguinhos . 
A questão levantada por alguns(as) 
No final das mensagens alguns(as) de nós na lista colocam algo assim: 
" Eu, fulano(a), falei 
Ho , passo o bastão!" 
A mente da razão foi treinada para fazer-se cética, mas grande parte do treinamento foi deturpada e fez -se cínica, vendo assim tudo como "meio bobo" , vendo tudo a partir de si. 
A idéia de terminar os mails assim pode parecer uma passagem para viajar na "Hellman's airlines" mas em verdade é bem simples. 
Como estamos fazendo um experimento virtual aqui, estamos usando uma antiga forma de fortalecer os elos de comunicação entre pessoas. 
Quando se coloca : "Eu, fulano(a) falei. há uma afirmação. 
Perdemos muito o sentido do poder das palavras e aqui estamos usando palavras escritas, que impressionam nossos olhos, e vão imprimir idéias, evocar sentimentos, partilhar sentidos de observação da vastidão que nos circunda. 
EScrever e falar sempre foram oficios sérios para os povos nativos, nossa cultura conseguiu deturpar bem isso e enfraquecer bem este poder que temos, mas se fortalecermos novamente tal elo que temos com a ETERNIDADE< podemos mais uma vez escrever a partir do foco de nós mesmos, falar a partir do foco de nós mesmos, agir a partir do foco de nós mesmos, sentir a partir do foco de nós mesmos, pensar a partir do foco de nós mesmos. 
Isso muda tudo e uma das chaves está em observar a respiração. 
É fantástico o efeito de nos observarmos durante a inspiração, durante a expiração e no espaço entre elas. 
Assim ensinam os Sufis. 
Linhagens que herdaram a sabedoria dos nativos do deserto. 
A espreita começa por aqui, não em mirabolentes farsas rocambolescas onde pretendemos na verdade compensar algum ponto vaidoso em nós, exercendo personagens e tipos que sejam a expressão do que "sempre sonhamos ser" , ou ainda usando da idéia da espreita, para fazer valer comportamentos caprichosos e idiosincráticos. 
A essência da ESPREITA é agir na condição mais estratégica do uso e fortalecimento da energia pessoal em qualquer posição que o ponto se deslocar. 
Assim o ponto por onde muitos caminhos começam é lidar com o dia a dia, o desafio que a própria ETERNIDADE criou para cada um de nós. 
Quando lidamos eficientemente com esta realidade primeira , só então estamos prontos para voos mais ousados. 
Espreitar , ou praticar a loucura controlada, não é algo sem maiores efeitos, ao contrário, toda a concepção e percepção da realidade muda para quem prática tal ARTE. 
Quando a espreita, ou ARTE da loucura controlada começa a ser compreendida o próprio corpo muda com isso. 
Há o ativar de níveis genéticos que estavam adormecidos e certas organelas que estão dentro das células, passam a atuar em outras frequências. 
O complexo de golgi é um exemplo dessas organelas intracelulares que atuam de forma diferente de acordo com o tipo de respiração, foco e estado de consciência que estivermos. 
ESte tipo de fisiologia só é naturalmente estudada em linhagens como o Taoismo, a Acupuntura e algumas linhagens de Artes Marciais que são a expressão de outra forma de abordar a realidade, onde o corpo humano é visto em sua totalidade, que abrange também a chamada parte etérica, onde estão os meridianos da acupuntura, onde estão os chacras e outros pontos de grande energia. 
Visto em sua totalidade física o ser humano é já aqui um ser cheio de energia e poder que pode estar presente em si, ou ter sido esbanjado em uma vida sem foco. 
A vantagem do(A) xamã guerreiro é que ele (a) não carrega passado, assim no momento que constata a importância de tudo isto , a importância de estar aqui e agora e trabalhar a si mesmo , começa então a agir com o foco devido, limpando seu elo de conexão com a ETERNIDADE. 
Uma das armadilhas sutis é procrastinar , deixar para amanhã, para o momento X, as ações transformadoras que surgem quando nos decidimos definitivamente trilhar o TAO. 
Só podemos dizer que decidimos algo quando agimos, decisões intelectuais, viagens emocionais são comprovadamente falsas, só duram por um tempo, depois se dissipam e tudo volta como antes. 
Atitudes realizam. 
E aqui podemos começar a sentir de novo a presença do inefável poder que nos sussura sempre, mas que não notamos pela algazarra das nossas muitas máscaras lutando por dominar o cenário. 
Aqui começamos a sentir os compromissos do CAMINHO. 
NÃo é um compromisso com ninguém, neste nível não podem haver intermediários, não precisamos que hajam. 
EM contato direto nos colocamos frente a frente com a ETERNIDADE e com nossos sentimentos podemos estabelecer um contato que a mente alerta pode nos ajudar a entender , ainda que tal compreensão seja de todo distinta da usual. 
REStabelecer o contato com a ETERNIDADE, com o TAO, com o INTENTO é apenas uma forma de aludir a uma atitude transcendente, que é algo pragmático,não uma "fantasia mística". 
Assim , a menos que por sorte esteja numa condição de espaço tempo que o próprio ESPIRITO, a própria ETERNIDADE se manifeste por si, o trabalho de nos reconectarmos é árduo e precisa começar agora. 
Isto está ligado a ESPREITA, espreitarmos a nós mesmos, implacavelmente, mas também com sutileza, com astúcia. 
Perceber os jogos que fazemos conosco mesmos, as esfarrapadas desculpas que ainda colam , os vícios comportamentais que nos levam a repetir por anos, caminhos de conhecida ineficiência, propostas que nunca se realizam. 
A ESPREITA é ato e atos são finais no mundo dos(as) xamãs guerreiros. 
Por isso, por esta tremenda força os (as) xamãs guerreiros também perceberam a necessidade de serem gentis, muito gentis, pois ao lado da paciência é a gentileza que deixa a implacabilidade leve e a astúcia não cruel. 
DEcisões geram atos. 
O tempo entre o pensar e o agir deve ser o menor possível quando nestes paradigmas. 
Pois um dia em silêncio agiremos e agir em silêncio é a porta que nos lança a esta outra misteriosa condição de consciência, a esta outra atenção, o Nagual, onde vivems uma vida ampla, de maiores possibilidades, por isso maior risco de nos aprisionarmos, mas é uma contraparte do corpo físico, que tem mente, emoção, etérico, tudo isso nele, o dualismo é corpo físico, corpo energético, não mente corpo. Mente é corpo, corpo é mente, não é mente Sã em corpo são, a mente é o corpo também, não está apenas contida num cérebro como querem alguns. 
Sentimento é corpo também, sentimos com todo o corpo, temos que recuperar estes níveis de sensibilidade para perceber isto. 
ESta a razào do uso dessa fórmula. 
Afirmar nossa identidade, assim como a prática de ler o mail é recomendado o rito do Cocar, que nos coloca em sintonia com vasta egrégora, ligada a proposta de paz da Tribo do Arco Íris, afirmar seu nome, afirmar sua singularidade não egóica, é começar a criar um foco, um espaço mágico onde podes brotar e vicejar enquanto autonomo ser rumo a LIBERDADE. 
Ter a identidade bem definida no contexto onde estamos é algo importante. 
O problema é com o conceito que temos de" bem definida" 
Mais ainda com o conceito de identidade. 
FAzemos parte de uma civilização onde identidade é um registro teu num departamento para o qual tu eres um número, um código. 
Identidade, ter identidade, quantas loucuras egóicas não estão acontecendo agora realizadas por pessoas que buscam "identidade" . 
Sua face no bando. 
"bem definida" é uma proposta muitas vezes vista como adotar uma postura rígida, inflexíviel, fora do fluxo das coisas e chamar este endurecimento senil de "madura forma de deixar tudo bem definido" . 
Claro que estamos a eons disso quando usamos esse termo aqui. 
Identidade bem definida é para nós outra construção, não um acumular linear de histórias pessoais que te prendam a um agir que seja só uma reedição do que já foi. 
Identidade bem definida é tua marca singular na existência, onde a ETERNIDADE aprende algo mais, porque fomos novos, fomos criativos, geramos artisticamente o que não havia antes, em atos concretos, onde quer que estejamos. 
E quando descobrimos algo, quando realizamos algo a ETERNIDADE se realiza por nós, através de nós, e isto nos dá uma energia tremenda, quando ao final do ato , apenas oferecemos sinceramente tudo aquilo a ETERNIDADE e nos retiramos do palco, serenos, cientes que aquele espetáculo já acabou e aplausos ou vaias da platéia já não importam mais, há outros palcos a visitar , novas perfomances a nos desafiar. 
Aqui repousa a espreita, a ARTE da loucura controlada, atos de abandono, de total foco e paradoxalmente total entrega,algo que só se resolve na prática, atos à ETERNIDADE. 
Por isso a ESPREITA não pode ser praticada pelos níveis egóicos limitados, pelas máscaras a brigar , a sofrer , ansiosas, pois será apenas um mero representar de papéis, sem nenhum real efeito sobre o ponto de aglutinação. 
OBservar a respiração é o começo neste caminho, redescobrir o ser energético que somos.