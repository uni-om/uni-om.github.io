---
layout: texto
tags: [pérola]
texto_number: 53
category: ventania
---
Date:Seg Abr 9, 2001 5:00 pm
Texto:53
Assunto: Perplexidade partilhada
Mensagem:795

A terra lhe é preciosa ,e ferí-la é desprezar o seu criador.Os brancos também passarão: talvez mais cedo que todas as outras tribos.Contaminarem suas camas, e uma noite serão sufocados pelos próprios dejetos. 
Mas quando de sua desaparição, vocês brilharão intensamente,iluminados pela força do Deus que os trouxe a esta terra e por alguma razão especial lhes deu o domínio sobre a terra e sobre o homem vermelho.Esse destino é um mistério para nós ,pois não compreendemos que todos os búfalos sejam exterminados , os cavalos bravios sejam todos domados ,os recantos secretos da floresta densa impregnados do cheiro de muitos homens, e a visão dos morros obstruída por fios que falam. Onde está o arvoredo? Desapareceu.Onde está a águia ? Desapareceu. É o final da vida e o início da sobrevivência.