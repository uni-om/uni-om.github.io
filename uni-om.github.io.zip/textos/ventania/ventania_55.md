---
layout: texto
tags: [pérola, mapa]
texto_number: 55
category: ventania
---
Date:Sex Abr 20, 2001 7:08 pm
Texto:55
Assunto: Re: [ventania] Profecia do Quinto Mundo-considerações (txtolongo)
Mensagem:820

Aloha lista;

Aloha Retawe;

A proposta é essa mesma, trocarmos nossas visões de mundo expondo nossas
palavras nesta fogueira virtual, aqui ninguém tem pretensão de dono da
verdade ou bobeira semelhante, aqui estamos apenas comparando nossos mapas
sobre a vasta jornada pela Eternidade que é nosso desafio realizar.

Vou Comentar sua mensagem ao longo dela


>
Sou novo na lista, mas peço o bastão para expor minhas considerações.
Como dizem por aí, que a gente não deve falar muito da história pessoal,
passarei direto para alguns comentários do texto enviado pelo Nuvem que
Passa.

"É interessante que a mensagem foi escrita nitidamente por alguém
americano,
pois traça paralelos com o cristianismo e com a Bíblia..."

Sinceramente, não entendi essa idéia de americano, porque me considero
deste
continente e nem por isso acredito na Bíblia, ou no cristianismo como é
descrito pela Igreja Católica ou Protestantes em geral.

Ficou mesmo equivocada a forma de colocar, quis dizer que os
norte americanos tem uma abordagem da realidade bem fundamentalista, tudo
vira "jesus" , "deus" tudo fica bíblico, tem várias igrejas nativas que
fazem uma miscelânea total entre conceitos cristãos e idéias dos nativos.
Não julgo se é bom ou mal, creio que isso não existe, mas dentro de uma
proposta de liberdade ficar preso a paradigmas cristãos e mesmo de outras
religiões fundamentalistas não me parece muito útil, até mesmo a nível
psicológico as deficiências dessas doutrinas, nitidamente feitas para
enfraquecer e facilitar a escravização , não tem coerência com as propostas
do Xamanismo guerreiro.





Além do mais,
acredito que é bom conhecer a Bíblia, o Tao-Te-King, os Vedas, Alcorão,
etc.
Pois todos os livros considerados sagrados, contém o "Ver" tão propalado
por
D. Juan. (Se alguém não conhece muito, leia o capítulo 15 da 1a Carta de
Paulo aos Corintianos, que verá muita coisa boa que tem que acontecer
conosco
antes de passarmos para outra realidade). Ali fala da transformação que
tem
que acontecer do nosso corpo físico em corpo etérico. (Isso de Corintiano
é
brincadeirinha, é aos Coríntios).


Concordo com vc, nos escritos sagrados de todos os
povos vamos achar referências de sabedoria, mas o problema é que não é
nesses pontos de saber transcendente que tais credos tecem suas teias onde
capturam "devotos" e fazem toda a lavagem cerebral que sabemos acontecer que
torna o ser humano menor que ele mesmo, um mendicante "servo do senhor" .

A abordagem esotérica das religiões é muito válida, mas é uma minoria que
tem acesso a isso, a maior parte do fenômeno religioso opera nos níveis de
dominação ideológica e necessidade de converter outros a seus esquemas, sem
um respeito profundo e sincero pelos outros caminhos . FAtos observáveis.

Mas todo livro sagrado tem toques importantes, é a chamada sabedoria perene,
que mesmo com toda a perseguição e deturpação não conseguiram apagar.




"O xamanismo não tem nada a ver com cristianismo..."
Sobre esse texto do Nuvem, gostaria de considerar que Cristianismo genuíno
não é o que se prega ou o que se vive por aí. Cristianismo é diferente de
Catolicismo ou Protestantismo. Além do mais, se pensarmos em Cristo como
um Nagual com seus 12 aprendizes, poderíamos dizer que produziram bons
avanços no andamento espiritual da evolução da Humanidade. Penso até, que nosso
avanço consciência, passando pela Idade Média, Moderna e Contemporânea,
era uma preparação para a humanidade chegar a este último estado de percepção
da "Ver" - dade.


Como já comentei numa visão ideal do Cristianismo
podemos até nos aproximar disso, mas o intento por trás de todo o
cristianismo históricamente analisado sempre foi o de conquistar e dominar,
há uma doutrina subjacente de conquistador embutida em tudo que veio com o
Cristianismo e isto me parece muito danoso ao ser humano em geral.
Creio que a REvolução Industrial não foi um avanço, mas um perder de
sintonia que aconteceu, só agora, a duras penas, sendo recuperado por outros
camos da ciência que se atreveram, enfrentando a resitência e o preconceito
dos "acadêmicos" ousar abordagens da realidade que , surpreendentemente para
alguns, são similares as concepções de mundo que O Taoismo e outros caminhos
ancestrais apresentam.




"O xamanismo não precisa de Messias, de gurus ou de livros sagrados..."
Coloco o seguinte agora, porque tenho lido todos os livros de Castaneda,
menos o último, mas pergunto: O que é o Nagual, já que li que sem ele não
há
liberdade? E por outro lado, o que significam para vocês os 12 livros
escritos pelo Nagual de três pontas? Amigos, espero que desculpem minha
ousadia ao falar tudo isso, mas são os meus sinceros pensamentos e estou
seguindo o caminho há 13 anos.

O espaço aqui é para isso mesmo, trocarmos
ideías e abordagens da realidade.
Creio que o sentido de Nagual num grupo como o de D. Juan e Castañeda não
tem anda a ver com o sentido de messias que coloquei nesta frase, aliás há
várias colocações de D. Juan e Castañeda sobre isso, sem gurus, sem messias,
pois assim como o cristianismo esotérico é uma coisa ideal, que só poucos
trilham e na prática as igrejas cristãs estão apenas interessadas em criar
adeptos, números, massa de manobra o conceito de messianismo deixa o ser
humano a margem de sua própria história, pois fica sempre aguardando alguém
para fazer o que ele mesmo precisa realizar.
O conceito de Nagual como líder do grupo, como que tráz a liberdade é eons
de distância do messianismo, que é estudado como uma forma de fazer as
pessoas esperarem sempre que alguém venha e lhes dê a liberdade.

A Liberdade é uma conquista, um nagual te dá a chance mínima de saber que
temos que lutar por esta conquista.
O conceito de Messias é completamente diferente, gera dependência, por isso
coloco que no Xamaniso Guerreiro não há espaço para tais conceitos que
transferem para outros a responsabilidade que tem de ser nossa.


Se lemos os livros da saga de CC vamos notar que D. Juan é um típico exemplo
de NAgual, ajudou CC a se ajudar, nada de "guruzices" .



"Enquanto religiões dogmáticas fazem do ser humano um seguidor..."
Considero um problema falar em dogmas, porque de uma forma ou outra, me
parece que você naturalmente se torna dogmático, quando começa a conhecer
e
"ver" as leis imutáveis da Natureza. ( espero que considerem que o ato de
"Ver" faz você chegar a um estado de percepção onde não existe outra
verdade.
Se assim podemos dizer.

>>>>>>>>>>>Aqui eu já discordo totalmente, quando mais nos familiarizamos
com a natureza ,com sua essência, não com a descrição social dela, vamos ter
mais liberdade, menos "leis" menos "regras" surge outra coisa,q ue não é
nunca um dogma, pois dogma é uma verdade inquestionável e os fatos
energéticos da feitiçaria não são dogmas, são verdades demonstráveis pela
prática.
ALiás um dos pilares do TAoismo é o TAO TE KING o Livro das Mutações, nada
há de imutável na ETERNIDADE, a não ser sua eterna mudança, se tornar
dogmático, cheio de verdades prontas é o equivoco que muitos caminhos
mágicos levam, qando a liberdade implica justamente no oposto,:

Não sabemos nada, tudo pode acontecer, somos mistério dentro de mistérios e
nunca sabemos de qual moita o coelho vai sair.

"Veremos que a todo instante, alguém está falando em dinheiro..."
Nuvem, desculpa que estou te marretando, mas, vejo que não só o dinheiro é
o
assunto do dia, ou da época, mas também o sexo, não acha? Também o
Prestígio
ou o apego à imagem pessoal, ou auto-importância, como queira falar.

RIndo, sem marretar amigo, é sempre um rpazer
trocar idéias, eu tenho uma forma de falar meio incisiva, que aqui, só no
escrito, sem expressões faciais e tons de voz, podem parecer impositivas,
mas quem me conhece sabe que não tenho esse peso, estou apenas comparando
mapas e busco apenas falar de mapas reais e não os imaginários.

O dinheiro fica como meio de se ter sexo, meio de se ter prestígio e como
fator de auxilio a manutenção de uma imagem pessoal. Comentei esse lance do
dinheiro porque isso me impressionou, fiquei observando as pessoas no dia a
dia e as vi engalfinhando-se pelo dinheiro de uma forma que tudo parece
girar hoje em torno de dinheiro, como meio de chegar a estes outros temas
que tu colocastes e de fato ocupam o centro de gravitação do ser humano
contemporâneo.




"Esta civilização que aí está, tem no 'ter" e não no "ser" o foco..."
Acredito (achismo?) que não é o "ser" o foco, porque o ser leva à
auto-importância e nós temos que vencer isso, mas é o "sentir (perceber)"
o verdadeiro foco, ou seja, tornar-se consciente. Embora a vontade e a
Intenção devam dirigir.

Comunicar é delicado porque precisamos ter certeza que
estamos empregando o mesmo sentido para os termos que estamos usando.
SER no sentido que usei ali implica tudo, SENTIR, PENSAR , AGIR, que
abrangem bem mais que emocionar-se , raciocinar e reagir.

A auto importância é toda preocupação com a fantasia que existe um ego para
ser importante.
O SER ao qual me refiro é a essência perceptiva , presente no mundo, sem ser
do mundo, atuando com foco, não lutando por uma auto imagem, mas expressnado
sua essência.




(Será?) De toda forma, no texto seguinte, você concorda com
isso quando coloca: "Valorizamos o corpo, a natureza, a realidade sensível
e
sabemos que temos de começar por estes campos antes de irmos ao além."

"Onde o povo nativo é quase apagado da história, generalizado e ignorado
em sua luta..."


Às vezes fico pensando, se temos que apagar a história pessoal e
desprender-nos de tudo, e..., embora tenhamos ancestralidade, acredito que
não defendemos uma raça, talvez uma visão do Universo, mas acredito que a
Terra não precisa ser defendida, ela se defenderá sozinha, apesar de nós.

Aí entra o grande ponto que divide hoje a TRibo Arco Íris hoje.
Alguns creem que somos ínfimos de mais para ajudar a TERRA, que não
precisamos fazer isso, que ELA se defenderá sózinha, e que os que se foram
tinham mesmo que perder a guerra, os povos que continuam hoje sendo
trucidados, paciência , são os insondáveis caminhos da ETERNIDADE.

Sinceramente não tenho esse desapego, sou um caipira chucro, que ama a
TERRA, que não quer ficar neutro nessa guerra, mas que também não vou dar
bobeira e entrar na guerra dentro dos esquemas dos senhores do mundo.
Creio numa luta de magia, como as antigas lendas contam, onde a luta é
travada em outras fronteiras, creio também nesta magia no dia a dia, quando
ao final de cada dia sou coerente plenamente comigo mesmo, creio que a
energia gerada por um dia vivido em coerência com nossa essência gera um
tipo de energia que efetivamente auxilia a terra
Creio que estamos numa guerra de consciência, de estado de consciência, nós,
enquanto humanidade trouxemos o mundo a este estado de crise e
desequilíbrio, cabe a nós ajudarmos a restaurar o desequilíbrio.

A TERra pode se defender só sim, com terremotos, e coisas do gênero, mas um
outro caminho pode ser tentado.
Eu sou , por natureza do clã guerreiro, assim esta luta pela cura da Terra é
algo do meu sangue, dos meus ossos e do meu espírito.



seremos nós que teremos que mudar com ela, para conseguir passar para o
além,
como você disse.

"O xamanismo é um elo direto com a Eternidade."
Noto que é difícil entender a palavra eternidade. Por que não falar em
eterno
presente ou Presente do Infinitivo? Ou melhor, Um estado sem tempo, já que
o
tempo segundo A Roda do Tempo, disse que o Tempo é um pensamento e que o
Espaço é um Infinito?


>>>>>>>>>>>>>>>>>>>>>>PAlavras só aludem, são dedos e para ver as estrelas
que apontam não devemos nos fixar neles mas mirar o apontado.




"Não somos pecadores em busca de redenção, temendo e idolatrando um deus
punitivo que entregou seu filho para com seu sangue lavar nossos pecados."
Acho complicado falar disso, mas embora concordo completamente com o que
você disse, preciso entender que os semitas, eram povos pastores, devido a
isso, tinham uma outra psicologia, a qual Joseph Campbell explica muito bem,
quando disse que esses povos quando precisavam matar animais, precisavam
reconhecer que estavam fazendo algo contra a natureza, matando uma vida. Com tudo
isso, não quero defender essa idéia ou justificá-los, mas entender mais fundo
seu inconsciente.

"..., o fato de estarmos conscientes, nossa relação dinâmica com a vida e
a
Consciência."
Neste ponto, apenas gostaria dizer que consciência é percepção de si, o
que nós somos? Um ovo de luz? Um ponto de aglutinação? Um Atman? Um ego? Uma
bolha dentro dessa cebola de energias esféricas?


Creio que somos a realidade que expressamos a cada
momento, a factualidade de nossa presença no aqui e agora. Sem muito
racionalismo, somos a realidade que vivemos, podemos ter o arcabouço
intelectual mais acurado, mas se a realidade de nossas vidas não condiz do
que adianta?
Penso que o mais importante exercício do caminho é ao final do dia
recapitular todo o dia e que o último sentimento antes de irmos a mundos
outros que não esse seja o de satisfação por termos estado presentes onde
estávamos e lidado com as situaçõs que a vida nos apresenta como estratégia
e foco . O mais é elocubrar para escapar das constataçòes fundamentais.
Só temos o momento presente, nada mais que isso.




"O xamanismo é um caminho para pessoas fortes."
O que você quer dizer com isso? O xamanismo não consegue transformar a
pessoa? Esse ser forte é algo inato?

O xamanismo é um caminho para pessoas fortes.




Pois é meus amigos (as), estou apenas com minha mandala ancestral no meu
peito, porque não tenho cocar, mas tento usar ela com respeito e manter
minha
consciência presente no dar-se conta.

A idéia do cocar é uma proposta da lista, uma proposta de sintonia, um jogo,
uma arte, uma forma sutil de entrar em sintonia e equilíbrio com a proposta
que a lista tem que é de partilhar pontos de vista sem proselitismo , apenas
ter uma fogueira virtual onde partilhamos nossa abordagem da realidade e as
nossas experiências.




Para terminar, quero dizer que estou no caminho, tento manter minha paz,
meus
sentimentos e percepções em harmonia. Sigo o calendário Maya, faço meus
passes mágicos todo dia e tenho recapitulado um pouco. Tenho lido muito,
pensado bastante e sentido demais.

Na Paz, passo o bastão.

Retawe falou



Que este seja o começo de um proveitoso e amplo
papo entre praticantes .