---
layout: texto
tags: [pérola]
texto_number: 58
category: ventania
---
Date:Seg Abr 30, 2001 12:32 am
Texto:58
Assunto: Fogo dos deuses e deusas
Mensagem:868

" As noites eram de gelo e os deuses e deusas tinham levado o fogo embora. 
O frio cortava a carne e as palavras dos homens e mulheres. 
Eles(as) suplicavam , tiritando, com a voz quebrada; e os deuses e deusas se faziam de surdos. 
Uma vez lhes devolveram o fogo. 
Os homens e as mulheres dançaram de alegria e alçaram cânticos de gratidão. 
Mas de repente os deuses e deusas enviaram chuva e granizo e apagaram as fogueiras. 
Os deuses e deusas falaram e exigiram : para merecer o fogo, os homens e mulheres deveriam abrir peitos com um punhal de pedra e entregar corações. 
Os índios quichés , ofereceram o sangue de seus prisioneiros e se salvaram do frio. 
Os cakchiqueles não aceitaram o preço. 
Os cakchiqueles , primos dos quichés e também herdeiros dos maias , deslizaram com pés de pluma através da fumaça e roubaram o fogo e o esconderam nas covas de suas montanhas" . 
Eduardo Galeano - NAscimentos - Memórias do Fogo (1) 
Editora Paz e Terra - Página 33 - 1ª edição 
ESte texto, prá mim, alude de forma clara aos dois caminhos que os(as) xamãs do velho mundo encontraram, servir a deuses e deusas sedentos de sangue ou serem ladinos, ardilosos, roubando mesmo o fogo destes deuses e deusas e criando um caminho de liberdade. 
Nuvem que passa, Ho!