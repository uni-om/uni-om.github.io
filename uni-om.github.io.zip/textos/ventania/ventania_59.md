---
layout: texto
tags: [pérola]
texto_number: 59
category: ventania
---
Date:Seg Abr 30, 2001 8:42 am
Texto:59
Assunto: noite e sonhos
Mensagem:869

" O sol não deixava nunca de iluminar e os índios kashenawás não conheciam a doçura do descanso. 
Muitos necessitados de paz, exaustos de tanta luz, pediram ao rato que emprestasse a noite. 
Fez-se a escuridão , mas a noite do rato bastou apenas para comer e fumar um pouco em frente do fogo, 
O amanhecer chegou e os índios mal haviam deitado em suas redes. 
Provaram então a noite do Tapir. 
Com a noite do Tapir puderam dormir um sono solto e desfrutavam o sonho tão esperado. 
Mas quando despertaram , tinha passado tanto tempo que as ervas espinhosas tinham invadido seus cultivos e esmagados suas habitações. 
Depois de muito buscar , ficaram com a noite do tatu. 
Pediram essa noite emprestada e não a devolveram jamais. 
O tatu, despojado da noite, dorme durante o dia. 
Obra já citada , página 29, 30. 
O existir da noite e do dia tem sido respondido pela mente ocidental com 
simplismo. 
A luz do sol brilha e é dia, de noite a ausência do sol gera a noite, escuridão. 
E assim tem sido aceito, pois as palavras tem essa magia de fingir explicar. 
As explicaçòes míticas foram confundidas em interpretações simplistas, onde a mente racional, nível para o qual as explicações místicas e míticas não tem sentido ou efeito, predomina. 
O mito não é um antecedente simplório da explicaçao científica, tão pouco está restrito ao religioso. 
Mitos são abordagens por outros níveis perceptivos . 
Mas não podemos limitar os arquétipos vivos dos mitos, nos estereótipos das interpretações lineares do mito. 
Usamos as palavras, mas compreendemos sua complexidade? 
Vejam o termo elétron, a real complexidade que está no ente localizado e mensurado no mundo subatômico, esta complexidade é rotulada : elétron e todos usam da palavra, do termo, mas pouquíssimas pessoas tem a efetiva compreensão do que é o elétron.. 
A luz é uma partícula tão complexa quanto o elétron. 
Fótons. 
Natureza dual, partícula e onda. 
Comportar-se como partícula e onda já é algo demais de paradoxal para a mente que ainda funciona pelos paradigmas dos modelos que começam a deixar de ser adotados na civilização dominante. 
A lenda acima parece pueril, imagine com que sorriso sarcástico o "padre", "pastor" ou mesmo certos cientistas, não recebem tais histórias. 
Povos simplórios, adorando a natureza. 
Mas quando mergulhamos no sentido do rato e do tapir como unidades complexas de significação, símbolos ancestrais para expressar realidades próprias da cultura que conta a história podemos redimensionar nossa compreensão. 
Há a noite curta demais . 
Nela não se pode sonhar. 
Há outra que os sonhos vêem, mas são tão longas que a vida se passa em outros mundos, aqui o sonhar ficou mais forte que o dia a dia. 
Então o Tatu empresta a noite que é o equilibrio do dia. 
E como nunca lhe devolveram, hábito reincidente na espécie humana, hoje anda o tatu sempre em dia, mesmo quando outras espécies percebem à noite.