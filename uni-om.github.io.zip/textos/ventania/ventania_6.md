---
layout: texto
tags: [pérola, mapa]
texto_number: 6
category: ventania
---
Date:Qui Abr 27, 2000 10:38 am
Texto:6
Assunto: Saudações !

Saudações.

Esta palavra: 
Saudações! 

Este ato de "saudar" quando se começa a dialogar.

Existem povos que pegam areia do solo, outros poeira e jogam sobre os dois ombros, para demonstrar que não estão com armas. 
Entre povos de diferentes origens que se encontram nas suas andanças pela floresta o sentido de saudar-se tem outra amplitude. 
Entre xamãs, Neo xamãs, enfim entre os (as) praticantes da ARTE o sentido do termo Saudações nos leva a perceber outra natureza de nossa postura perante o Existir. 
O(a) xamã é antes de mais nada um ser sensível. 
Sensível a realidade que o(a) circunda. 
Entretanto sensibilidade é um termo muito deturpado para expressar este "estado de ser" de um (a) praticante de ARTE. 
Confundimos emoção com sentir. 
Como confundimos raciocinar com pensar. 
Emoção e raciocinar são formas muito específicas de funcionar de habilidades maiores que possuímos. 
Sentir e pensar são estas habilidades. 
Emocionar-se e raciocinar são campos de treino onde a percepção balbucia suas tentativas de expressar-se e perceber o mundo por essas habilidades. 
Assim , sendo a ARTE um estado perceptivo onde nossa ligação com o Poder se faz por outra via, que não a determinada pelas tradições que apoiam o modelo no qual seres humanos são transformados em objetos. 
Tendo como ética fundamental jamais usar outro ser humano como objeto, agir voluntariamente na ampliação e sutilização do estado de consciência da espécie humana, da qual emergimos para o estado já além do humano que se situa o (a) xamã. 
Por isso considero bem delicado e carecendo de grande bom senso considerar-se xamã. 
O termo Xamã implica numa vitória sobre toda uma estrutura de situações quer externas, quer internas, que levam tempo e dedicação para serem realmente superadas. 
Elas tem a inquietante capacidade de se transfigurar no oposto do que realmente são e as prisões podem surgir de forma muito sutil. 
A importância pessoal é considerada o cadeado final, forte, robusto, enferrujado a tal ponto que a chave está com parte dela quebrada dentro da fechadura, numa tentativa equivocada de abrir usando a força. 
Os (as) Toltecas procuram trabalhar com total foco a questão da importância pessoal. 
Foram miradores espreitadores Toltecas que perceberam que a importância pessoal era uma máscara, um disfarce defensivo. 
Foi uma surpresa perceber que a importância pessoal com toda a vaidade e arrogância que dela decorrem, fosse na realidade uma máscara defensiva que vinha de uma outra emoção, mais profunda, muito bem disfarçada. 
A auto piedade! 
Quando a essência humana percebe algo e se surpreende pois ainda é imatura e pouco trabalhada, o condicionamento que chamam educação trabalha apenas com a personalidade, não a essência. 
A essência perceptiva que somos de fato percebe a efemeridade da existência, a singularidade de nossa presença e como será breve o nosso ato neste mundo maravilhoso e espantoso que nos circunda, nos anima, nos alimenta e nos toca, como o raio de sol entrando pela minha janela , o beija flor nos jasmins da varanda do quarto. 
Essa composição de poder me leva a perceber que o assunto que estamos aqui partilhando é algo importante. 
O foco de nossa atenção pode variar muito se nào for treinado. 
Os (as) xamãs do clã guerreiro Tolteca perceberam que a vaidade estava sendo usada por medo. 
Medo da imensidão que nos circunda, como defesa da percepção dessa realidade. 
Suportar a presença da vastidão tocando tuas células, poder sentir o hálito do Dragão da Eternidade e pulsar em chamas com ele para não ser incinerado, deixar que o passado e gasto em nós se incinere e qual Fênix renasça transmutado , o trilhar no mundo agora revelando o caminho e não nos afastando dele. 
Este me parece ser o trabalho que nos dedicamos enquanto xamãs no ramo Tolteca. 
Há uma harmonia de percepções muito grande entre os xamãs Toltecas e os Taoistas. 
A causa é terem bebido na mesma fonte, serem dois galhos da mesma árvore que brotou em passado remoto nas alturas hoje geladas os Himalaias. 
E quando então presentes em nós mesmos todo o tempo e focados na respiração , por exemplo, conseguimos um estar pleno aqui e agora que permite um perceber da "porta entre os mundos" , a fresta que está sempre aberta, que pode ser usada para entrarmos em outros mundos, tão "completos e inclusivos" como esse. 
Homens e Mulheres Xamãs são a expressão de um mito. 
Numa Era de Estereótipos urge que trabalhemos bem nossas bases para não cairmos nessa armadilha e aceitarmos a moda propagada pela engeharia religiosa dos que nos dominam, que vem progressivamente conquistando o mundo e destruindo o povo nativo. 
O Xamanismo não é dessa civilização dominante. 
Portanto os paradigmas da civilização dominante não podem ser usados para compreender o xamanismo. 
Notem que os paradigmas Quânticos e da biologia em suas complexas abordagens da realidade e da vida não são adotados pela sociedade dominante, embora comprovados cientificamente. 
Isto demonstra, para um bom observador, que o mito da ciência foi reduzido a estereótipo. 
A ciência só serve quando produz armas , conforto e poder. 
Sua atuação foi limitada, portanto o caminho cientifico sozinho não levou a liberdade desta sociedade do paradigma que a faz escrava de si mesma, pois basta um pouco de sutileza para perceber que mesmo nossos feitores são escravos... 
Saudações. 
O que nós da Tribo do Arco Íris com nosso compromisso de trabalhar na cura da Terra, ato que deve ser atitude , consciência, 24 horas de foco, o que nós atribuímos a este termo : "saudações" 
Não o que raciocinamos, ou mecanicamente fazemos, máquinas tem limites muito sérios. 
Organismos não. 
Somos organismos limitados a uma percepção mecânica de nós mesmos. 
Mas o Xamanismo insiste: Somos organismos. 
Conjunto , integração de "N" fluxos de vida e consciência. 
A força vital está presente em nós. 
Buscamos que ela desperte, se torne consciente de si mesma. 
Estar aqui e agora é a chave, presente. 
Em cada inspiração , em cada expiração e no espaço entre elas. 
Isso desenvolve o foco necessário para entrarmos com sobriedade nas outras realidades, nas outras camadas da grande cebola cósmica, da qual somos apenas uma camada, na infinitude, numa eternidade de cebolas maiores e menores . 
Saudações. 
A quem saudamos? 
Quem saúda? 
Já resolvemos o aglomerado de estilos de ser , pensar e agir que confundimos com nosso "Eu" singular. 
Não um "eu" separado da Eternidade, mas um "Eu" que se reconhece existente, essência perceptiva. 
Os Videntes Toltecas, especialmente "Los Nuevos" insistem que este é o último bastião no qual nos apoiamos. 
É aqui, nesta ciência e presença plena com a força vital que resistimos quando o Mar Escuro da Consciência vier reabsorver a consciência que nos emprestou, que nos doou, para seus próprios propósitos. 
Resistindo a dissolução, mas ainda assim dissolvendo-se. 
Ardendo na chama da consciência os Videntes Toltecas almejam sonhar um novo sonho. 
Que saltam além de todas as possibilidades e entram num novo estado de consciência, abordam e absorvem uma nova "intenção". 
Entram na 3 ª atenção. 
Liberdade Total é outra metáfora para esta meta. 
Assim, seres que almejam ter mais um tempo na Eternidade para continuar a vislumbrar e interagir com a magia, os mistérios insondáveis e a maravilha que nos cercam, seres com este prósito como vivem suas vidas? 
Esta a questão que deixo, como vivemos nossos dias? 
Na plenitude de nós mesmos, conseguindo a primeira liberdade necessária d e quem almeja a plena, a liberdade Interior? Sujeito da história, participante da vida? 
Ou mecanicamente, vítima da vida, objeto da história que disfarça com fantasias misticóides e explicações racionalizadas suas inabilidade em SER plenamente. 
Pois xamãs curam-se a si mesmo, realizam-se em si e só quando somos presença plena podemos nos dizer hábeis para ressonar em outros tais estados. 
Pois é ressonância a arte dos seres que tem fibras em si. 
Vibrar, vibrar e levar a vibrar. 
Ressonar . 
Consciência.