---
layout: texto
tags: [pérola]
texto_number: 60
category: ventania
---
Date:Seg Abr 30, 2001 9:11 am
Texto:60
Assunto: Yobuënahuaboshka
Mensagem:870

" Os anões da selva tinham surprendido Yobuënahuaboshka em uma emboscada e tinham cortado sua cabeça. 
Com tropeços , retornou a cabeça a região do Kashinahwa. 
Embora tivesse apreendido a saltar e a balançar com graça , ninguém queria uma cabeça sem corpo. 
- Mãe , irmãos meus, vizinhos - se lamentava- Por que me rejeitam? Por que tem vergonha de mim? 
Para acabar com aquela ladainha e livrar-se da cabeça, a mãe lhe propôs transformar-se no que já existia. 
A cabeça pensou, sonhou, inventou. 
Seria o que não existia. 
A lua não existia. 
O arco íris não existia. 
Pediu sete novelos de lã , de todas as cores. 
Fez pontaria e lançou os novelos ao céu, um atrás do outro. 
Os novelos ficaram enganchados além das nuvens . 
Se desenrolaram os fios, suavemente , para a terra. 
Antes de subir, a cabeça advertiu: 
- Quem não me reconheça será castigado. Quando me vejam lá em cima , digam : "Lá está o alto e belo Yobuënahuaboshka!" 
Então trançou os sete fios que estavam pendurados e subiu pela corda até o céu. 
Nessa noite , um talho branco apareceu pela primeira vez entre as estrelas. 
Uma moça ergueu os olhos e perguntou , maravilhada: 
" - O que é isso? " 
Imediatamente uma arara vermelha lançou-se sobre ela, deu uma súbita volta e picou-a entre as pernas, com seu rabo pontiagudo. 
A moça sangrou. 
Desde este momento , as mulheres sangram quando a lua quer. 
Na manhã seguinte , resplandeceu no céu, a corda de sete cores. 
Um homem apontou com o dedo: 
- "Olhem, olhem! Olhem que estranho!" 
Disse isso e caiu. 
E essa foi a primeira vez que alguém morreu. 
obra citada- página 28 
A criação no mundo do mito é dinâmica, nós recriamos o mundo a todo instante. 
A criação é um segundo momento, no princípio há a emanação,do nada brota algo, um pássaro que é a ETERNIDADE densifica'se e se auto fecunda, bota um ovo que é a existência. 
O mesmo é dito usando o dragão como símbolo. 
Depois dessa fase inicial vem então a criação que continua ocorrendo a cada instante . 
A física fala disso hoje, não há passado nem presente, mas um presente dinâmico que emite ondas quânticas que ecoam e interagem com este presente, intermpretamos algumas dessas irradiações como passado, outras como futuro e tanto quanto o ramo da árvore é causa do caule tanto quanto a raíz, nem passado , nem futuro são menos irreais ou causais, paradoxalmente. 
Ler o mito, ouvir o mito é sagrado porque ao faze-lo partilhamos do poder nele incluso e se somos buscadores (as) naturais do poder sem dúvida o poder ouve e atua quando nos unimos com Ele, pela força do mito. 
Por isso alguns mitos são secretos, outros só devem ser partilhados em lugares de poder. 
O rito reatualiza o mito. 
No rito pleno incorporamos o mito, não como um ente externo que a nós se agrega ou possuí, mas entramos na mesma ressonância, na mesma frequência onde não representamos apenas, mas somos o mito. 
O rito nos leva a nós mesmos, o que incorporamos num rito é a realidade mais profunda de nós mesmos, ausentes pela condição de não poder que é a vida cotidiana. 
Um desafio que sinto que pode ser chamado de "Viver o mito" com o despreendimento e a flexibilidade perceptiva que o caminho do xamanismo propõe é a partir de hoje cada vez que olharmos a corda de sete cores ou a lua lembrarmos de dizer, mesmo que seja só para nós mesmos: 
- " Lá está o alto e belo Yobuënahuaboshka!" 
É com tais detalhes que se tece um sonho de mil gatos(as)...