---
layout: texto
tags: []
texto_number: 61
category: ventania
---
Date:Ter Mai 1, 2001 9:30 am
Texto:61
Assunto: Perplexo
Mensagem:876

Agora voltando de uma caminhada pelos arredores da cidade, serras, pasei por um lugar perto da chácara de um amigo que eu ia muito quando guri. 
O lugar era bem interessante, um riacho, fino mas fundo, pedras que brilhavam a luz do sol e da lua, lugar cheio de árvores , goiabas e limões. 
Mamonas também, uma vez quase perdi a visão por causa de uma guerra de mamonas. 
Será que foi isso? 
Aquele lugar onde cacei girinos e piabinhas levou uma mamonada de alguma força cósmica, que também só queria brincar, como quem me acertou um dia. 
E num instante de desequilibrio perdeu seu poder pessoal e então alguém olhou prá ele, não viu a beleza . 
E resolveu que árvores, água, vida é pouco importante, construir moradias de alto padrão para ganhar muito dinheiro é melhor. 
ALgo que sempre me espanta, como esta civilização leva as pessoas a coisificarem tudo, até que se coisificam e se permitem serem usadas nessa destruição constante do que é natural e forte, para substituir pelo artificial e efêmero. 
Mais um lugar de poder que se foi. 
ESpero que se cure... 
O loteamento em piche e lotes marcados por sulcos na terra estéril é algo bem estranho de se ver... 
Até quando a destruição continuará? 
Perplexo.