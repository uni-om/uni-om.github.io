---
layout: texto
tags: [mapa, prática]
texto_number: 62
category: ventania
---
Date:Dom Mai 6, 2001 9:14 pm
Texto:62
Assunto: CAminhos
Mensagem:901

Saudaçòes ; 
EStive lendo sobre a questão da roda do sul e do norte. 
Eixstem pessoas que trilham caminhos que celebram a natureza de acordo com as estações do ano, outras seguem caminhos que celebram de acordo com as tradições européias. 
Concordo que a idéia é trilhar o caminho que mais lhe apetece, que mais tem a ver com cada um. 
Eu pessoalmente trilho o caminho telúrico, mas em física existe uma idéia de conexões não locais, onde o spin de um eletron responde ao spin de um outro eletron numa posição do tempo espaço bem distinta. 
Assim ir contra suas tendências interiores só prá agradar este ou aquele individuo que de alguma forma influência seus pontos de vista é ainda seguir, é ainda estar em heteronomia, respondendo a ordens , respondendo a programações. 
Me parece que o mais importante num rito é o sentimento, só tem verdadeiro valor o rito que ritualizando reatualiza o mito, em plenitude, em nós, nos tornando plenos e sensíveis a realidade a nossa volta e a realidade que carregamos dentrod e nós mesmos. 
Ser fiéis a esta realidade interior é tudo que um (a) pãgão(ã) busca. 
Ser fiel a algo externo a nós é a marca dos seguidores, dos que trilham um caminho de heternomia existencial, objetos, servos e ovelhas de pastores de rebanhos que negam a liberdade selvagem e plena que arde no peito de nós, seres humanos, e preferem um seguro cercado, um pasto aramado, que a liberdade desafiadora das planices e montanhas ainda intocadas. 
Creio que uma das bases do movimento pagão é este elo direto que podemos estabelecer com a NAtureza e com aquilo que podemos chamar de divindades. 
Um elo sem intermediários, onde as pessoas há mais tempo no caminho são apenas companheiros e companheiras mais experientes, que podem , se de fato trilham o caminho, nos dar dicas preciosas para evitarmos armadilhas e perigos do caminho. 
Por isso o Xamanismo foi tão perseguido, e isso não começa com os Europeus não. 
Os Astecas, os chamados Incas, ( que não são uma tribo mas uma classe governante) e outros tantos já tinham em si essa praga que infestou a humanidade: ">dominar outros seres humanos, fazer de seres humanos, criaturas naturalmente mágicas , livres na infinitude, servos de servos, objetos, negando a condição de sujeito a seus próprios filhos e desencendentes. 
ESse imperialismo que tráz homens corajosos, que de guerreiros foram deturpados em mercenários, que educados sob outros paradigmas seriam audazes aventureiros no mar infinito da consciência, para aqui agir dominados pelos mais vis e desequilibraods sentimentos, esse estilo de humano dominando outros já havia se infiltrado por aqui também. 
É muito importante compreender que embora sem o grau de atrocidade e violência gratuíta que o invasor íbero trouxe a estas terras, já haviam povos aqui em busca de formar impérios, subjugar outros povos para fazê-los seus servos. 
ë importante lembrar qe mais terrível que o sacríficio para fins mágicos de pessoas feitos pelos povos nativos , veio a Inquisição torturando para extrair segredo dos iniciados e depois matando de forma cruel os "hereges" , em chamas, banho de banha fervente, antes açoitando e lavando com sal as feridas, enfim, requintes de crueldade, nos verdadeiros "'barbaros" ( no sentido vulgar deste termo) frente a um povo muito mais sofisticado existencialmente. 
É muito forte sentir isso. 
Sentir que ter tiram da tua terra, do convívio das pessoas que partilham tua vida, daquelas pelas quais sentes um afeto sincero e desinteressado e te obrigam a ir para longe, para um lugar onde serás sempre o fugitivo. 
SAber que escravizaram teu povo, que vão usar as pessoas que amas, das formas mais vis e abjetas. 
É interessante que para um guerreiro e uma guerreira isso seria um treino tremendo de poder, mas não estamos falando de guerreiros e guerreiras, aquelas pessoas que vemos andando na neve nas montanhas da europa oriental, nos conflitos e Kossovo e Macedônia não são guerreiros e guerreiras, são seres humanos, e fazer vistas grossas a todo o sofrimento que esta falsa guerra causa a estes seres humanos é confundir implacabalidade com crueldade, risco fácil quando a personalidade e não a essência controla a cena. 
Guerras de conquista, pelo "ouro", pelo "dinheiro" . 
A instabilidade na região citada é causada pela ação direta de coorporações que querem construir um "corredor de energia" com gaseodutos e congêneres, noutro local, e fazendo da área uma região de conflito, armando imaturos grupos em guerras étnicas, cria um "clima de insegurança" para investidores , fazendo valer o seu projeto. 
Vidas humans sacrificadas para tal vil projeto, isto é a civilização dominante. 
Vidas jogadas fora pela ganâqncia de poder de alguns. 
. 
Armadilha que ainda hoje leva um número incontável de pessoas a dedicarem a energia de suas vidas a deuses e deusas ,criados a imagem e semelhança dos seres humanos, e há ainda os céticos, qe cultuam o deus dinheiro, poderoso e dominador neste mundo de escravos onde a uma parte da espécie human se encotnra confinada . 
E no Xamanismo também vamos encontrar esta luta pelo poder , entre aqueles círculos onde o poder deixou de ser um meio para se otrnar um fim, onde a personalidade mal resolvida ,em sua insegurança fundamental prefere lutar pelo poder sobre outros, que permitir a essência desenvolver realmente o poder que trás em si. 
Quando falamos de xamanismo e de caminhos xamânicos temos que tomar muito cuidado com os cultos xamânicos. 
Nem todos os caminhos xamânicos levam a LIBERDADE. 
Cultuar seres leva a questionamentos importantes. 
Que tipo de ser estamos cultuando? 
SAbemos de fato que tipo de ente estamos nos relacionando? 
Somos sers muito novos na Eternidade, temos que ir aos outros mundos e ao contato com outros seres com muito cuidado e vigilância. 

Como diz o velho nagual: 
"Liberdade para se dissolver, para decolar; para ser como a chama de uma vela que mesmo diante da luz de um bilhão de estrelas , permanece intacta, porque jamais pretendeu ser mais do que é : uma simples vela." 
Existem seres que são em relação a nós, como uma estrela frente a chama de uma vela, podemos chamar estes seres de deuses e deusas , podemos cultuá-los, mas estaremos apenas caindo na velha armadilha que muitos de nossos ancestrais caíram. 
Nesse ponto, ao invés de me aliar com os Quichés que cederam e ofereceram o coração de seus inimigos a deuses e deusas vorazes, para recuperar o fogo roubado, prefiro trilhar o caminho dos Cakchiqueles e ser ladino, roubar dos deuses e deusas seus segredos, espreitando os espreitadores e ocultar nas cavernas secretas o brilho e a chama, para de calores externos não depender.