---
layout: texto
tags: [pérola, mapa]
texto_number: 64
category: ventania
---
Date:Sáb Jun 16, 2001 11:41 am
Texto:64
Assunto: Ritos de Solstício - Tribo do Arco Íris
Mensagem:1036

Espero que esta mensagem lhes encontre naquela porção singular de si mesmos , onde o silêncio existe e nenhuma programação exterior tem acesso. 
Que ela chegue na "Presença". 
No próximo dia 21 teremos um eclipse, num solstício. 
É uma data das mais interessantes, existem muitas "profecias" maias e de outros povos nativos sobre esta data. 
NAda "apocalíptico", "nostradamico" , não é por aí. 
Existem referências a estes eventos, e referências aos tipos de energia que estes eventos despertam. 
FAzendo estas leituras para o momento atual da humanidade notamos que mais que nunca é urgente que pessoas voltadas para a construção e não para a destruição, para a consciência e não para a inconsciência , para a Liberdade e não a prisão se irmanem de tempos em tempos, emitindo tipos de energia que podem auxiliar efetivamente no equilibrio do Ser Terra. 
Existe uma lenda entre certos povos que viveram onde existe a Guatemala que se parece muito com a lenda hoppi da Tribo do Arco Íris. 
Falam do poluir e degradar do mundo pelos invasores, que gerariam uma nova raça híbrida nas terras conquistadas dos povos nativos, mas escravízariam essa raça híbrida para seus próprios fins. 
Mas neste povo os acontecimentos seguem sendo narrados e falam de alguns ciclos ( sabem que os povos ligados aos maias, tinham datações de tempos complexas) e um desses ciclos seria este momento que estamos vivendo. 
Existe uma consciência coletiva, da qual a Internet é um dos "tecidos neurais" , que está se intensificando cada vez mais. 
Existem experiências sendo realizadas via Net que tem demonstrado o incrível poder da rede para nos colocar em contato, para nos articularmos enquanto membros de uma abordagem de realidade que não é a "padrão" que não é a "estabelecida verdade oficial" . 
Um mundo se sustenta pela "visão" que a coletividade mantém desse mundo. 
Por eras temos sido expostos a tiranos e tiranas que nos implantaram seu modo de ver o mundo, nos prenderam a uma descrição da realidade, como a que atualmente domina grande parte do mundo e das pessoas que nele vivem. 
Mas há outras "visões de mundo" e visões de mundo são diretamente relacionadas ao estado de consciência de cada um. 
Esse poder da net está sendo sabotado em diversos países, por diversos tratados, como os programas embutidos de espionagem que existem desde os hardwares até os lugares que visitamos na rede, desde os "ingênuos" feitos propositalmente pela página para ter acesso a novos consumidores, até os mais sérios colocados por uma dessas muitas organizações que servem aos neo senhores e senhoras feudais, em suas constante paranóia de "dominar o mundö". 
MAs ainda assim temos brechas e por uma dessas brechas gostaria de partilhar algumas idéias que me foram passadas num encontro recente. 
Creio que para ser claro no que vou dizer e evitar excesso de ruído na mensagem, não mais que o já "comum" é bom a gente pensar junto certos conceitos. 
Um sols'ticio de inverno é um momento astronômico, ninguém está "imaginando" ou "visualizando" , é algo que está ocorrendo, neste evento o dia será o dia mais curto do ano e a noite a mais longa, então o poder solar que veio decrescendo até este pondo começa de novo a crescer a amadurecer e fortalecer, como o ponto no mais profundo Yin que traz já em si a força do Yang. 
Um solstício de inverno para nós que somos desta área do planeta é diferente do solstício de inverno de quem vive nas regiões onde o sol de fato parte e a escuridão e o frio tomam conta de tudo. 
A energia que acompanha o solstício de Inverno em nossa Hybrasil é bem distinta, mesmo nos cantos mais frios do sul, onde sopra o minuano, mesmo na Serra onde a neve cai, ainda temos um "tom" diferente dos povos que vivem completamente na neve. 
FAlo disso porque podemos acabar presos na forma de ver o mundo dos conquistadores , quando existem outras formas de sentir, perceber de agir no mundo que está aí. 
DEstruíram de tal forma as culturas nativas de nosso continente que só agora estamos um pouco mais bem informados do colossal potencial de desenvolvimento harmônico que estes povos possuiam e porque o conquistador se esmerou em realizar tal genocídio e ainda varrer a memória das práticas e conhecimntos desses povos da própria história, substituindo por uma farsa vulgar onde selvícolas atontados e brutos são o estereótipo de raças viris e sábias que no entanto foram destruídas. 
A forma de se relacionar com os poderes que nos envolvem dos povos nativos era bem distinta, podemos chama-la de pagã, pois viviam de fato em contato direto com a natureza. 
MAs outros povos nativos desenvolveram cidades, centros cerimoniais e aí também várias práticas de sintonia se estabeleceram. 
Pois me parece que o mais fundamental para compreender esses ritos é entende-los não como "adorações" , não como "cultos" , mas como cerimônias de 'sincronização". 
Por estes ritos cada ser humano, que também é parte do Sol, entrava em sintonia com o novo ciclo do sol e através desse sol com outros sóis, com o núcleo da galáxia. 
Estes termos "sol", "núcleo da galáxia" , tudo isso são formas de dizer de hoje, para estes povos a forma de se referir a estes poderes era outra, não a visão supersticiosa que querem lhes dar, mas uma visão dinâmica, viva, presente. 
O sol é um ser vivo e consciente, num grau inimáginável para nossa efêmera vida e consciencia. 
EStamos numa teia de interconexões, numa verdadeira "web" multidimensional. 
Existem mensagens vindas através do sol, através dos planetas. 
o Sol e os planetas sao densificações de vórtices de energia que nascem em outras dimensões. 
Marte é um portal para toda a energia que está num mundo, daí que o planeta Marte num mapa astral representa onde este portal, este vórtice está e sua relação com os outros. 
Nós somos como rádios, captamos e emitimos ondas diversas e assim estamos em contato com toda a ETERNIDADE< apenas não percebemos isso porque nossa educação foi mero treinamento para nos tornar operadores de partes desse sistema dominante que aí está. 
Em outras culturas íamos aprender sobre o poder do Sol , das estrelas, dos planetas, não como entidades antropomórficas como alguns ainda leem, mas como poderes efetivos, vivos, conscientes e a nós relacionados. 
Eram aí que surgiam os ritos. 
ESses ritos, essas práticas de sintonia com as forças da Eternidade podem nos ampliar em termos de energia e com mais energia temos mais coisas que podemos realizar e ao realizar parece que aprendemos mais sobre as potencialidades do ser humano. 
Neste momento creio que revelamos um pouco mais da ETERNIDADE para ela mesma. 
Existem dois mundos. 
Um está claramente em extinção, óbvia rota que a atual sociedade se traçou. 
Outro está começando, frágil e sutil como todo começo, taoísticamente também com todo o poder e força de um começo. 
Depende de cada um de nós o mundo com o qual vai se sintonizar. 
É uma escolha pessoal, até quando alguém é "maria vai com as outras" , frase aqui do sul que diz daquela pessoa que não tem autonomia em suas decisões , seguindo sempre o 'bando" em suas opções, ainda aí, está sendo exercido este interessante poder que temos, de "escolher" o que vamos "fazer" . 
É sobre esse fazer que paira alguma confusão também. 
Me parece que muito do que chamamos de fazer nada mais é que um "reagir" , não um "agir" . 
Como bem demonstram certas correntes comportamentais, o ser humano vive respondendo a estímulos, mesmo sem o perceber. 
Se nos observarmos por um longo tempo, com foco, determinação e sinceridade, só nos observarmos , sem querer mudar nada, só observar mesmo podemos descobrir coisas realmente úteis, mais úteis que as imagens ilusórias que fabricamos de nós mesmos. 
Somos um vetor resultante, onde os vetores que nos dão origem são incontáveis, influências astrológicas, influências genéticas, nossos fantasmas interiores, a força de nossos ancestrais em nós, o que comemos no almoço, tudo isso age e influência esse vetor resultante que chamamos ilusóriamente de "meu jeito de ser" , " minha atitude" . 
Mas podemos dar um passo além disso e nesse passo ousar ir mais longe e de fato "AGIR". 
Isso leva tempo, mas me parece que de tempos em tempos temos a sorte de partilhar uns "agir" que não nasceram em nós, um "PARTICIPAR". 
PArticipar tem sido uma palavra muito esquecida e no entanto a física quântica tem revelado que nosso universo é um universo de participação, de interconexões,onde todas as partes são igualmente importante na existência do todo, a vasta "" teia da vida" , como a rede de Yndra, onde cada entrelaçamento é uma pérola, cada pérola é uma rede. 
Nesse dia do Solstício no mundo inteiro pessoas ligadas ao movimento Tribo do Arco Íris vão estar sintonizadas em certos momentos específicos, de acordo com seus fuso horários. 
ESte é um convite de participação. 
O movimento TRibo do Arco Íris é um movimento, uma ação que nasce de uma resposta consciente, premeditada , ao chamado dos conselhos ancestrais de vários povos, deste as geladas planícies árticas, onde corre o urso , até o continente que dorme sob o gelo ao sul, onde respousa a continuidade da vida. 
Mais que nunca os conselhos dos povos nativos tem se apoiado e fortalecido, cientes do momento delicado que atravessamos, dos riscos para toda a VIda neste planeta, que desde o inicio da loucura nuclear fez da raça humana um destruídor potencial do próprio ser Terra. 
Formado por integrantes de vários povos, várias raças, de muitas cores, o movimento atua há anos de forma direta e indireta, dos conselhos nas florestas e montanhas como nos meios conhecidos de mídia, para dar uma dimensão mundial aos seus trabalhos. 
A proposta da dimensão mundial é para que formemos uma teia, uma teia dentro da grande teia que já existe e que esta teia seja uma teia com um propósito: 
Curar a Terra. 
Para 'nós curandeiros que seguimos os caminhos telúricos é sensível que a terra está doente, foi colocada doente pelo ataque dos seres humanos que ainda hoje, agora enquanto escrevo, no momento que estiveres lendo, vão estar em atitudes de destruição. 
Esse ano a Amazônia sofreu uma das piores ondas de destruição, isso com todo mundo achando que o mundo está "mais consciente ecológicamente" . 
Para as pessoas ligadas ao movimento Tribo do Arco Íris a única saída para essa crise que se avoluma e intensifica cada vez mais é a MAGIA. 
Por isto temos nos dedicado a certas práticas nos solstícios e equinócios. 
NEste solstício estaremos em práticas : 
No momento do Solstício, pela madrugada. 
No nascer do sol 
No meio do dia 
No por do Sol 
Ao meio da noite, quando o sol estando no estremo oposto gera o "momento de sombra" , que devido ao eclipse tem um poder especial neste dia. 
No momento do eclipse 
Onde quer que estejas, se estiveres a fins de participar dessa "onda " é só se focar em si mesmo(a), sentir a respiração e se conectar ao sol e as estrelas ( lembra que de dia as estrelas ainda estAo lá) . 
É só sentir o fluxo da energia que vem da Eternidade passando pelo seu corpo, ativando seus chacras e indo para o centro da Terra, para o centro vital da Terra e como uma agulha de acupuntura injetamos essa energia estelar e planetária na terra, energia "astral" , no sentido dos antigos alquimistas . 
Ë se visualizar como um ovo luminoso, brilhante, com fibras vindas de todas as estrelas sendo captadas e essa energia propositadamente direcionada para a Terra. 
Depois deixa a energia do Dragão da Terra, desperta pela força do Dragão Celeste que evocaste venha a tona e entre pelo teus pés, suba pelas tuas pernas e no chacra básico comece a ativar os ventos que dormem para que a "mente esteja quieta, a espinha ereta e o coração tranqüilo." 
ISto dá prá fazer em minutos, desculpa de falta de tempo não rola, além do que deve ser feito com nosso ser de energia e para nosso corpo de energia não tem barreiras, podemos ir ao banheiro do escritório fazer e conectar o mesmo poder de quem estiver fazendo no Alto da pedra grande em Atibaia. 
Prá quem trilha um caminho mais xamânico ou magistico, que pratica ritos como formas de linguagem artísticas para interagirmos com os poderes que nos circundam, há um outro rito.