---
layout: texto
tags: [pática]
texto_number: 66
category: ventania
---
Date:Qua Jun 20, 2001 1:25 pm
Texto:66
Assunto: eclipse
Mensagem:1045

ALoha

TRAdicionalmente o eclipse é um momento de muita energia.
A lua se coloca entre a Terra e o Sol e por um tempo médio de Quatro minutos
uma área da Terra fica exposta a um cone de sombra.

A energia do Sol está chegando até nós todo o tempo, estímula a Vida, faz com
que processos dos mais diversos ocorram.

Num momento de eclipse , a área onde o máximo do eclipse acontece , sofre uma
inversão.
Em pleno dia a noite se faz presente.

Eu já presenciei alguns eclipses totais, no México e em Foz do Iguaçu e foi
muito interessante observar toda a natureza "perplexa" frente a condição de
excessão.

Os animais voltando pros ninhos, como se a noite estivesse chegando mais cedo
e de repente o dia volta.

A cara de "ué" nos animais quando o dia volta é interessante e é um vasto
campo para os cientistas .

EM nosso caso, que buscamos utilizar objetivamente esses momentos de energia ,
este eclipse tem uma grande significação , pois ocorre num solstício e com
Marte numa aproximação total da Terra, num ano de Marte.

O horário do eclipse é 10: 15 da manhã, ( horário de Brasília)

Neste momento podemos realizar um rito .

Rito do Eclipse-


Num lugar tranquilo onde não vão lhe incomodar, trace seu círculo e se coloque
ao centro.

HArmonize-se com os quatro elementos, nas quatro direçòes, sinta que quatro
pilares de energia se formam nas quatro direções, Agua, Fogo, TErra e AR.

Sinta-se o quinto pilar, o pilar central.

É importante ao "sentir" os pilares, visualiza-los como enraizados até as
profundezas da Terra e se perdendo nas alturas.

Assim como sentir-se com a "cabeça nas nuvens e os pés enraizados".

Quando estiver nesta sintonia, busque se harmonizar com a TErra.

No momento exato do eclipse ( 10:15 am) se harmonize com a Terra.

" SEr Terra, sou parte de ti, tu eres minha mãe, mas também sou parte do Sol,
também carrego a natureza do Sol dentro de Mim.
Por instantes SER TERRA, a Lua se coloca entre ti e o Sol, em partes tuas a
energia do Sol não chega. 
Eu sinto teu chamado pela energia do Sol, para que ela volte e se ative.
Eu , como parte do Sol, como criatura solar, ativo também este chamado, amplio
em meu corpo e meu corpo é parte de teu corpo, pois eu e ti somos um ." 

sinta todo seu corpo como um grande captador de energia do sol, sinta tua
natureza solar sento ativada e sinta-se como uma agulha de acupuntura captando
a energia do Sol e a enviando para o interior da Terra.

Mantenha esta prática por quatr minutos e então sinta que a Terra volta a
plena recepção da energia solar na face para ele direcionada.

"Que a energia do eclipse seja trabalhada com foco e equilíbrio e que as
forças da harmonia e do equilibrio possam cumprir seu papel" .

Agradeça a presença dos quatro pilares, deseje que eles voltem para seus
pontos de origem e ao partir levem consigo toda energia o passado , deixando
apenas a energia do Aqui e Agora contigo, plena e equilibrada.