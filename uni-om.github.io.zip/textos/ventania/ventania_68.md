---
layout: texto
tags: []
texto_number: 68
category: ventania
---
Date:Ter Jul 24, 2001 10:58 am
Texto:68
Assunto: Re: [ventania] Ciclos;
Mensagem:1098

Aloha lista; 
SAudações Ambrósio; 
Vou respondendo em azul. 
From: Ambrosio To:  Sent: Monday, July 23, 2001 2:39 PM Subject: Re: [ventania] Ciclos; 
Oie... Vou colocar alguns comentarios meus no seu mail e umas perguntinhas. Espero que não se importe Nuvem. :-) 
;-) 
Ciclos, o tema deste mail. 
O dia 25 de Julho para os que trabalham com o Calendário dos Sonhos é uma data simbólica, um momento de relembrar que existe outro jeito de sentir o passar do tempo, uma forma mais efetiva e participativa. 
 Que calendario seria o calendario dos Sonhos? 
O calendãrio dos sonhos é usado no mundo inteiro por pessoas que se envolveram com o trabalho de Argüelles e sua companheira Loydine, é um caleñdário inspirado no calendário maia , mas com uma interpretação própria em certos pontos. 
Hoje, para realizar aquele nível de movimentos, um praticante da " arte do dragão" precisa de muito mais energia, pois a concernëncia coletiva não os tem como possíveis assim o deslocamento do ponto de aglutinação grupal para o nível onde isto ocorre é mais trabalhoso, mas não menos possível. 
 Como seria a relação da energia grupal com a energia individual? Seria como se o ponto de aglutinação estivesse mais "proximo" a posição que permitisse tais movimentos ( naquelas civiliações) e hoje estaria mais distante (nessa civiliação) devido as imposições ( TV, educação, modo social ) ou seria outra coisa que num tem nada haver com isso? 
PAra falar disso temos que entrar noutro ponto do conhecimento dos(as) antigos(as) feiticeiros (as) , o Tonal e o Nagual. 
O tonal é esta faceta da existëncia que chamamos da realidade, podemos dizer que tudo o que podemos conceber faz parte do Tonal, já fora dessa condição hã outra, que quase não é realmente conhecida pela civilização dominante, pois tudo que chamam de " espiritual", " transcendete" está mais prá tonal, pois pode ser definido, pode ser mensurado, pode ser abarcado pela mente e então é tonal, estados diferentes de tonal, mas ainda tonal. 
Já a outra esfera da existëncia é acessada por outro " anel" de percepção, de atenção , a segunda atenção, o nagual. 
Estes termos, tonal e nagual são apenas alusivos, especialmente nagual, dizer que há um nagual é só citar algo, não quer dizer que compreendamos o que é isto que estamos aludindo. 
No nagual sõ hã atos. 
Chegamos ao nagual atraveés do corpo sonhador, por isso sonhar é um caminho para forjar em nós o corpo de energia, que para os toltecas, como para os taoista não vem de brinde com a vida, mas deve ser " cultivado" . 
O tempo muda de textura em seu fluxo, nossos ancestrais viviam num mundo muito diferente do nosso, uma " textura" diferente. 
Houve um tempo mais ancestral onde os seres humanos viviam no mundo dos sonhos. 
A nossa civilização está presa a um mito criacionista linear, vai acontecendo numa reta no tempo, mas outras civilizações tem outras interpretações. 
Os povos nativos de vários continentes contam que este mundo é um entre muitos , que a humanidade veio andando por vários mundos até " brotar" nesse e um dia vai continuar sua jornada rumo a outros mundos. 
Assim os tapetes mãgicos jã voaram em Bagdá, as brumas podiam ou não abrir as portas prã Avalon, Asgard podia ou não ser alcançada pela ponte do arco íris, Matatu Araracanga podia ser encontrada atravessando o portal caverna das araras, enfim muita coisa tida hoje como lenda e fantasia eram realidades corriqueiras. 
A concernëncia das pessoas estava numa posição que mantinha o ponto de aglutinação alinhado com uma percepção mais flexivel da realidade, permitindo essas mudanças. 
O dia que antecede nosso aniversário é um " dia crepúsculo" , um dia fora do tempo que podemos usar de muitas formas se soubermos como. 
risos... La vai uma das perguntas classica. De que ´´formas`` podemos usar esse dia? :p 
PAra o Xamanismo todo dia é único, mágico e estar " aqui e agora" é a melhor forma de utilizar um dia, de usar o dom da vida, que passa por nós a cada instante e nunca mais volta. 
Dias com estes n~iveis de energia especiais podem ser melhor utilizados se desde o despertr at~e irmos dormir nos lembramos que somos condutores de energia, metabolizadores de substäncias cõsmicas para a Terra e telúrica para o Cosmos, que somos catalisadores de substäncias cõsmicas que chegam da eternidade passam por nõs, se manifestam como nossas emoções, raciocionios e reações e seguem seu caminho. 
EStamos enriquecendo a consciëncia da Totalidade, somos ovos de consciëncia, containers onde a consciëncia pela experiencias de vida são enriquecidas, assim quanto mais conscientes de nós mesmos estivermos , mas estaremos em sintonia com as incontáveis energias que nos chegam da Eternidade.