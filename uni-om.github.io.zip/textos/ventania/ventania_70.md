---
layout: texto
tags: [pérola, mapa, prática]
texto_number: 70
category: ventania
---
Date:Qui Ago 9, 2001 11:47 am
Texto:70
Assunto: Re:Recapitulação txt longo
Mensagem:1141

Olá lista;

ESte tema da recapitulação vale a pena ser comentado, é um dos pilares do
processo apontado pelo xamanismo guerreiro e por outros caminhos também.

ë fato que todos recapitulamos ao morrer.

O mar escuro de consciência, a fonte que nos doou a consciência ao final da
existência toma de volta para si tal consciência, que se dilui no vasto mar,
nele diluindo o teor de nossas experiências, metabolizadas pelo processo de
estarmos vivos e percebermos.

Ao final da existência o ponto de aglutinação, a percepção , tudo que somos
, pois o resto é emprestado, passa por todas as experiências de vida que
tivemos, não é umr ecordar mental, é um viver de novo mesmo, algumas pessoas
que quase morreram e voltaram falam desse "passar da vida " .

Por isso os videntes toltecas desenvolveram a técnica de viver neste mundo
em consciência intensificada e ir a muitos mundos, não humanos
principalmente, se lançar as vastidões do infinito e retornar a esta terra,
este tempo onde temos nossas vidas.

Imaginem onde um(a) xamã pleno como os que ensinaram o nagual de 3 partes
não iam?

E voltavam, viviam ali, na casa do México por exemplo onde faziam seus
piquiniques, onde D. Juan Matus cozinhava rabadas apimentadas para deleite
de todos.

Esse ir a extremos da segunda atenção e voltar tem um porque.

Nossos ancestrais espirituais foram, e foram e foram, alguns tão indo ainda,
mas isto se revelou uma armadilha.

Eles pensavam que o nagual, a segunda atenção fosse algo como hoje se pensa
em plano espiritual, algo que vai subindo, ficando mais "puro" , mais
"pleno"

Os (as) novos(as) videntes resolveram essa armadilha, perceberam que a
segunda atenção é só a contraparte da primeira, vasta,muito mais vasta, mas
apenas uma contraparte, ir -se por ela é apenas adiar um fim, não vencê-lo.

Descobriram outra possibilidade.
O vasto mar da consciência quer de volta apenas a consciência, que é sua de
fato, mas nada quer com a força da vida que temos.

Esta descoberta mudou tudo.
A força da vida não precisa se dissipar , apenas a consciência.
E treinando guerreiramente os (as) nuevos videntes fizeram algo impensado,
além de toda possibilidade de compreensõa, mas possível de realização.

O ente perceptivo ao morrer abre mão da consciência.
Ao passar por todas as experiências de vida o ponto de aglutinação libera
uma tremenda energia pois , ao contrário dos caminhos antigos, os (as)
nuevos videntes não foram progressivamente a outras realidaes, ascendendo
uma fibra de cada vez.

Foram aleatoriamente a muitas realidades, imaginem a cena de uma bexiga
transparente, cheia de fibras óticas.
Um ponto de luz sai de um feixe aceso e vai acedendo os outros, dos mais
distantes aos mais próximos.

Isso libera um tipo de energia estupendo, essa energia, se for usada com
intento permite a quem isso faz dar um salto em direção a outro estado,
abandonamos a primeira e a segunda atenção, mas absorvemos uma "terceira
atenção" estado que só cito prá dizer que existe e já é muito.

Este caminho faz com que os (as) xamãs guerreiros (as) tenham práticas que
lhe permitam chegar a este objetivo.

O ente perceptivo que somos pode se "individualizar" .

Podemos ser nós mesmos, podemos ser mais do que "fizeram de nós".


Para os(as) xamãs guerreiros(as), muitas linhagens, taoistas, hinduistas,
sufis, budhistas , o ser humano existe para cumprir um papel dentro de um
amplo esquema cósmico.

Não fomos "criados a imagem e semelhança de deus para reinar sobre a
criação" .

TAis histórias atestam a necessidade humana de fugir da constataçãod o nada
que somos.

Somos como enzimas,cumprimos um papel na existência e voltamos pro "caldão"
de onde viemos.

Isso se tudo for segur o caminho "natural" .

Mas é neste nada que os (as) xamãs guerreiros encontraram poder para ir
além, pois se tão infímos somos podemos mesmo escapar deste intento primeiro
da realidade e astutamente nos esgueirarmos pelos mundos, alcançando ume
stado que metafóricamente chamamos de "liberdade total" .

PAra realizar este desafio supremo precisamos de muita energia, antes de
mais nada.
E esta energia tão necessária, durante a vida, foi sendo perdida pelos atos,
nas pessoas e vivências que tivemos.

Deixamos pedaços nossos em pessoas, situações, em cenas, lugares e estes
pedaços de energia que ficaram nos fazem falta, pois só com toda nossa
TOTALIDADE podemos desafiar os designios primeiros da FONTE, da ÁGUIA e
"como um jato, passar além de seu bico , livres , rumo a LIBERDADE.

Esse sonho já foi sonhado antes, isso o torna realizável.

REcapitular é um exercício para recuperar esta energia, estes pedaços de nós
que fomos sem saber, deixando pela estrada de nossa vida.

Os budhistas de várias linhagem o realizam, taoistas, sufis, muitas
tradições trabalham com esse recapitular da vida.

Por que?
Para quê?
Como?

O que é recapitular ?

É antes de mais nada lembrar, lembrar de um evento que aconteceu, começa
assim, então não para aí, se nos colocamos na atitude coerente desse
momento, se estamos focados nesse momento com o devido "intento" algo em nós
é afetado e nosso ponto de aglutinação, isto é nossa percepção, é deslocada
para o "momentum" energético onde aquele fato recapitulado aconteceu.

Todos os fatos da vida devem ser recapitulados, por isso se diz que a
recapitulação dura a vida inteira, temos sempre camadas mais profundas para
recapitular.

REcapitulando descobri que vivemos em várias dimensões ao mesmo tempo, temos
multiplas vidas e mesmo nessa vida aqui e agora nós só lembramos de uma
camada superficial do mundo, recapitular nos dá energia, nos devolve a
energia.

Nossas possibilidades existenciais são incríveis, posso citar apenas o
exemplo de uma mulher do grupo de D. Juan MAtus que sonhando trazia para
este mundo ESperanza, uma curandeira e o Zelador, intelectual simpático que
cuidava de uma das casas do grupo.

Esses mistérios são pertubadores, fascinantes, somos magia num grau
impensado e ficamos aqui nestas percepçòes tolas e limitadas de mundo,
acreditando mesmo que é a bolsa de valores, a seleção brasileira, a alta do
dolar que importa.

Presos a uma mídia que serve ao conquistador e por isso oblitera
nossapercepção, ficamos sendo alimentados com lixo cultural e embotados em
nossa realidade existencial.

Noticia é a tragédia, a violência, meios sutis de aumentar o medo, pois
sabem que se te mantiverem com medo do que está a tua volta tu nao
questionará o sistema que lhe escraviza.

E cada dia surge um novo processo contra o bode expiatório da vez para que
não vejamos nosso pais sendo entregue aos sempre vorazes mercantilistas, a
companhia das indias ocidentais do momento.

Vivemos neste contexto histórico e deixamos nossa energia neste mundo,ele é
mantido também com nossa energia, cada vez que assistimos um programa de tv,
cada vez que lemos jornais, que comentamos sobre esses assuntos.

não são apenas nossos impostos, cobrados em cada bala, em cada cafézinho que
tomamos, que sustentam esse sistema.

Nós o sustentamos com a força de nossa intenção e nossa energia, toda nossa
vida desde que nascemos, tem sido sustentar esta realidade, que nos anula,
mas nos mantém como galinhas em granja, alimentados se botamos nossos ovos,
depois abate.

REcapitular portanto é também uma atitude da TRibo do Arco Íris em sua luta
pacífica e silenciosa pela retomada dos direitos de nossos ancestrais, de
outra abordagem da realidade.

Quando tiramos a energia dos eventos passados e deixamos apenas a que ele
tinha estamos também tirando a energia desses eventos que ficou impregnada
em nós.

Só assim podmeos mudar nossa percepção da realidade, do contrário será
apenas uma mudança intelectual.


Porque em cada interação que temos deixamos energia nossa e levamos a
energia do lugar das pessoas, de tudo que ali ocorreu.

E sabemos que percebemos uma vastidão da qual só registramos a mínima parte.

Quando recapitulamos vamos tirando a energia que ficou e devolvendo a que
ficou impregnada em nós, isto é, vamos resgatando nossa energia singular.

Isso amplia nosso poder pessoal.

Vai além, revendo os eventos de nossa vida aprendemos a reconhecer "o que
fizeram de nós" e podemos ir além desse estado e sermos "eu mesmo" , ser
singular, único, que só existirá nesta efemera mas bela existência por um
curto tempo.
E se vamos existir por tão curto tempo com a morte sempre há um braço de
distância à esquerda como não viver intensamente cada momento, presnte,
pleno(a), como seguir dividido(a), fragmentado(a)?
Temos em nós tudo que precisamos para essa fantástica jornada que é viver.
Por falta de saber perdemos nossa energia, perdemos nossa força da vida e
deixamos pedaços de nós com pessoas, eventos, lugares.

A recapitualação é mais que lembrar portanto, começa assim, mas não é uma
revisão psicanálitica.

Pela magia da respiração damos uma dimensão extra a esse exercicio.


A prática usual recomenda escrever uma lista com as pessoas que conhecemos,
todas.
Depois dessa fase o ideal é sentar-se em um lugar calmo, com o mínimo de
interferências externas.
REduzir as influências externas é muito importante para uma real
recapitulação, recebemos muitas "impressões " das coisas a nossa volta.

Florinda Matus fez sua recapitulação em um caixote construido ao seu redor.

Certa vez morei , em Sampa, numa casa que tinha uma escada e em baixo dela
fizeram um armário.
O armário não tinha prateleiras.
Durante anos usei aquele armário para recapitular.
Eu trabalhava a noite e durante o dia ficava só em casa, as pessoas que
moravam comigo trabalhavam de dia, assim tinha silêncio durante a tarde e
recolhimento.
Comento isso porque me parece que essas condições são muito importantes, a
qualidade da recapitulação sofre influências desses dados.
Taisha recapitulou numa caverna.
Este dado de estar num ambiente mais restrito focaliza energias da pele que
em outras estâncias estariam sendo "tocadas" por vibrações sutis , que
podemos não perceber conscientemente mas estão de fato em ação.

Além de um lugar adequado a recapitulação pode ser fortalecida por passes
mágicos para a recapitulação que quem faz tensigridade pode partilhar com
quem não faz.

No Shün que é a ARTe do Movimento que prático antes de fazer a "limpeza do
poço", como seria a traduçao do nome que damos a essa prática, existem
movimentos que são feitos.

Vou sintetizá-los para ajudar quem não tem acesso a grupos dessas práticas
como :

Primeiro espreguiçar bem, muito, mexer boca , olhos, puxar o corpo
todo pelos dedos, sentir os dedos dos pés e mãos.

"acordar o corpo" que é com os joelhos meio flexionados, braços a frente
com as mãos em garras, pés alinhados com ombros e tensionar o corpo inteiro,
tensionar mesmo, ir expirando contraindo o abdomem e tensionando até ficar
alguns instantes sem ar e todo tenso, então se soltar, dar uns pulos e
sacudir braços , mãos e pernas como se estivesse saindo de uma piscina e
tirando a água do corpo.
Então sentar numa cadeira ou chão e o corpo tá pronto prá recapitular.

Costas eretas, pode se encostar numa parede ou apoio para as costas
Olhando para frente solta todo o ar, sentir-se vazio.
Então vira a cabeça toda prá esquerda, queixo no ombro esquerdo
FAz uma respiração vazia, isto é, vira a cabeça até o ombro direito mas sem
respirar, vazio.
DEpois inspira indo prá esquerda e expira indo prá direita.

Intente que a inspiração absorve toda tua energia que está na cena e a
expiração devolve toda energia da cena que ficou em ti.

Então vá deixando a lembrança fluir, sinta-se na cena, mas não julge, apenas
observe.

Julgar, lamentar-se são formas de prender-se , de anular o valor da prática.

O importante é ir a cena e observar com foco o ocorrido, deixa que o
aprendizado venha, não crie interpretações mentais do tipo : " agora vou
agir assim ou assado" " a partir de hoje vou ser assim" estas propostas são
respostas da mente desequilibrada que temos em nós, é "o que fizeram de nós"
não querendo perder o controle e jogando como sempre aprendeu: " agora
serei a criança boazinha e farei tudo direito para agradar a todos e ao
papai do céu!"

O trabalho aqui é observar com neutralidade e recuperar a energia perdida,
deixando ali a que ficou impregnada em nós.

Podemos usar a recapitulação como o tremendo instrumental que é para nos
livrar de tudo que não somos, que apenas impuseram a nós.

Há várias dicas, fazer uma lista com todos os eventos da vida, tem muita
informação sobre técnicas por aí, basta pesquisar.

Uma prática muito válida é lembrar do dia todo ao deitar-se para dormir.
Eu prático ir lembrando do momento que sentei para relembrar, já indo
dormir, voltando cena a cena até chegar na hora de manhã que abri os olhos.

ESta prática diária tem várias resultantes, dá prá gente antes de mais nada
um dimensionamento de como tem horas durante o dia que estamos "no piloto
automático" ausentes de nós mesmos .

São instrumentais de guerra, a guerra contra os limites em nossa busca de
liberdade.

Um(a) xamã guerreiro (a) da liberdade total luta este tipo de batalha, estes
são nossos treinos de combate.