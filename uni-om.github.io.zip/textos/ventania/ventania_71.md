---
layout: texto
tags: [pérola, mapa]
texto_number: 71
category: ventania
---
Date:Seg Ago 13, 2001 8:34 pm
Texto:71
Assunto: Re: [ventania] a individualidade dos guerreiros(as)
Mensagem:1170

ALoha lista;
Aloha Dhyana;

Muito interessante as colocaçòes que acrescentas nesse mail

Uma coisa que noto demais é isso, as pessoas seguindo os passos ao invés de
entender o caminho, querendo imitar o jeito de andar ao i'n'ves de sentirem
a trilha.

Isso acontece demais em várias propostas e diferente não poderia ser nos
castenedismos e similares que surgem por aí.
No caso de TAisha, Castañeda, Florinda a questão fundamental é o que eles
aprendem, as experiências vividas são do contexto deles, são verdades
relativas ao tempo e ao espaço deles.

Existe uma diferença entre quem participa e quem imita.
Quem participa compreende a essência e vai dar sua leitura num momento
adequado , vai dar sua interpretação , quem imita pouco entende, apenas
repete algo que acha ínteressante, mas repete a forma sem entender o
conteúdo, invalidando assim o aspecto essêncial de um conhecimento
iniciático que é levar ao despertar, não ao continuar no sono.

Observo muito isso em pessoas que pretendem estudar a obra do novo nagual,
um seguir onde estudar é de maior utilidade.

Mas um risco muto sério é alguém dizer o que um guerreiro ou guerreira deve
fazer ou nao.

Só um guerreiro sabe o que deve fazer, ficar de fora dando palpites é
achismo e por isso creio que o equílibrio para quem PRATICA o caminho do (a)
guerreiro(a) é encontrar o equilibrio entre o que existe sendo ensinado e a
própria prática diária.

Como dizia D. Juan Matus as pessoas adoram que lhes digam o que devem fazer,
mas gostam mais ainda de fazer o contrário e acabam criando problemas com
quem teve a bobeira de lhes dizer.

Creio que existe dois tipos de liberdade.
A liberdade que vem da disciplina, do trabalho conosco mesmo e a liberdade
caprichosa que é mero capricho.

Me lembro que quando comecei a estudar com Oomoto e o grupo dele eu tinha
bastante desta última, gostava muito de ser o "constestador" o que "dá sua
própria interpretação" , fantasiando que isso era algum tipo real de
liberdade.

Oomoto com toda sua sutileza e sabedoria me levou a perceber que o ímpeto de
liberdade era valido, a vontade de ser e estar por mim, mas que este "mim"
este "eu" ainda nem existia, que eu era um amontoado de possibilidades, que
eu ainda era " o que fizeram de mim" e não minha essência perceptiva, se
construindo a partir de uma localização singular na realidade.

Fico observando as pessoas aqui na lista falarem : "um(a) guerreiro(a) age
assim, um(a) guerreiro(a) age assado , gostaria de fazer uma pergunta:

SABem de fato o que estão falando?
O que é ser um (a) guerreiro(a)?

Já morreram? De fato não "simbólicamente" ?
Tem validado este passaporte dia após dia?

"Já se deram ao poder que a seu destino rege e nada mais tem para nada ter a
defender? "

Vivem mesmo cada instante de suas vidas, cada instante, com a meta clara e
profunda da liberdade total?

CReio que são metas para se viver, mas quem não está 100% mergulhado nisso
pode dar palpites ou dizer : " na minha opnião" mas não dá prá dizer como
um(a) guerreiro(a) deve realmente agir.

A mente da besta, a mente que dorme, o estado de sono hipnotizado que
vivemos nos afasta muito da realidade dos (as) guerreiros(as), árdua é a
luta para atingir o viver pleno e estratégico de um (a) guerreiro (a) 26
horas por dia.

A luta é continua, na realidade nunca vencemos completamente o medo, a
clareza, o poder e a velhice ( velhice entendida aqui como senilidade , não
mera idade).
ESTamos sempre em luta e um momento de bobeira caímos e perdemos tudo, tendo
que começar tudo de novo.

ESta é uma diferença fundamental do estado guerreiro, estamos nele todo o
tempo, em combate, nao é um estado como o céu, no qual se chega e se fica
por prêmio ou algo assim.

Um (a) guerreiro(a) valida a realidade de sua condição em cada ato que
pratica.

A vastidão do mundo da segunda atenção pode nos desviar da meta da liberdade
total, somos muito afortunados de termos relatos de pessoas como CC, TAisha,
Florinda , entre tantos outros, que nos permitem ficar espertos e não cair
nas armadilhas 'varias.

Mas sem nunca nos esquecermos que temos armadilhas próprias a nossas
singularidades, aspectos que eles e elas nunca viveram, pois cada um de nós
quando começa a se realizar de fato é ser singular, de singular caminho, com
eventos próprios a sua realidade existencial.

Se é verdade exatamente do jeito que eles contam não me interessa tanto, me
interessa muito o cerne abstrato das informaçoes, é para eles, estes cernes
abstratos , que me abro quando leio os livros desse pessoal ao qual tenho
profunda admiração, pela coerência de suas mensagens com o que vivo em minha
vida.

O seu comentário sobre o lance da La Gorda e enterrar e tal é muito amplo e
pode ter certeza se a maior parte das pessoas que "quiseram" se enterrar o
houvessem feito teriam conseguido sim afastar pertubaçoes que lhes
acompanhassem, aí entra o lance que acabariam atraindo tudo de novo, mas o
fato do poder de se enterrar é poder em si, não depende de crença nem de fé,
funciona e pronto.

Intenção, InTento não é fé, é outra coisa e quando fazemos coisas ligadas ao
intento dos feiticeiros antigos colocamos em andamento energias sutis.

O problema é que as pessoas querem "adaptar" o SABER a seus eus comuns e
isso nunca funcionou.
TEmos que ir além do que "fizeram de nós" para realmente sermos capazes de
cultivar " a essência perceptiva que somos" .

É disto que o mundo precisa , nossa resposta singular, por isso concordo com
vc que "seguir" o que quer que seja é péssimo.

ALiás sempre considero seguidores algo menos que humanos, pois seguir é
apenas imitar e imitar é algo muito limitado.
Agora temos que tomar cuidado quando vamos ao universo da magia e queremos
interpretá-lo com a mente racional.

Tua interpretaçao do simbolismo terra morte renascimento e tal teria feito
D. Juan Matus e D. Genaro rolarem de rir, pois não tem nada a ver com o
esquema da feitiçaria.

Quando comecei a estudar magia também tinha mania de fazer tais
interpretações, que só agora entendo é uma tentantiva de "psicologizar" o
que não é dessa esfera.

Por alguém dentro de um caixão e colocar na terra é funcional em si, certas
energias não entram nessa "blindagem" .

Aprendi isso com uma curandeira quando nem sabia o que era CAstañeda, quando
iamos lidar com a cura de alguém que tava em estado muito terminal a gente
isolava essa pessoa da força da morte e fazia isso levando para uma caverna
que tinha num sitio dessa curandeira ou mesmo enterrando essa pessoa, coisa
que causava pânico numa familia que já vinha por ultimo recurso a uma
curandeira e via sendo enterrado quem justamente elas tinham medo que o
fosse para sempre.

Funciona porque é manipulação com poderes da energia da TERRA, sem nada
dessa coisa de "simbolismo" , de "relaçãod a maorte simbólica profunda do eu
em transformação relacionado com a realidade dialética dos processos que
interferem em nossa psiquê permitindo um contato com dimensões ocultas que
entretanto agem na formaçao de nosso self."

É aí que entra a sabedoria do útero, que por mails anteriores seus parece
que tu não botas muita fé, mas que é um fato para as feiticeiras e
guerreiras que convivo.

Nós homens podemos desenvolver esta sabedoria direta também, nosso corpo de
energia tem esse tipo de sabedoria, que vem na forma de insights vigorosos e
plenos.

Assim os dois extremos me parecem danosos a uma compreensão pragmática da
obra do novo nagual e suas companheiras, a abordagem de quem segue e a
abordagem de quem interpreta com paradigmas não relacionais informações que
foram geradas dentro de um contexto específico.
CC insiste sempre D. Juan nunca quis "ensinar" nada no sentido de um mestre
preocupado que seu discipulo se "espiritualiza-se ".
Ele estava apenas cumprindo sua missão, dando continuidade a sua linhagem.

Assim acreditar que podemos ir em buscas de naguais que vão nos treinar é
total tolice, só há caminho, só há trabalho quando e enquanto há sinais,
sinais que vem de uma FORÇA misteriosa, que todos temos acesso mas só os
guerreiros da liberdade total tem ido às ultimas consequências
interpretacionais e práticas do lidar com este PODER.

E todo trabalho é feito de Ação e nao ação e só a disciplina e o poder
pessoal de cada um pode acumular.

Podemos discordar dessas premissas, elas servem para um tipo de caminho,
podemos trilhar outros caminhos, há tantos, só não podemos falsear um
caminho que já tem suas premissas bem claras querendo criar pseudo
interpretaçòes apenas porque nao somos capazes de trilhar com exatidão o que
é proposto, então ficamos diletantemente criando justificativas.

Me lembra a história da acupuntura no ocidente.
Frente a evidênci que funciona agora querem dar interpretações de "nódulos"
nervosos e tal , quando a acupuntura não precisa "ser explicada" pela
medicina ocidental, ela já tem sua própria explicação , na complexa idéia
dos meridianos e tal.

Assim se não estamos aptos a trilhar a árdua caminhada da trilha dos (as)
guerreiros( as) melhor assumir isso e sabermos que mesmo assim podemos usar
um monte dos conceitos desse caminho para melhor viver, mesmo uma vida
comum, plantando milho todo ano, ano após ano. Com certeza pelo menos o
milho, será de ótima qualidade.

CAda caminho tem sua práxis, o poder do caminho do(a) guerreiro (A) é que
foi gerado no sonhar, está impregnado do poder de seus praticantes.

Só quem morre pode entrar nesse caminho, não há outro jeito.
É fato declarado, o mais é fantasia para fazer de conta é coisa de
seguidor(a) que precisa fazer de conta que participa de algo.

E como bem colocas há um abismo entre quem caminha e quem segue.