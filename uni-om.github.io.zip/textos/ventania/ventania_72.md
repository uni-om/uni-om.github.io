---
layout: texto
tags: [pérolas, prática]
texto_number: 72
category: ventania
---
Date:Seg Ago 13, 2001 9:05 pm
Texto:72
Assunto: Re: [ventania] En: Re:Renascimento Azul
Mensagem:1172

Aloha lista; 
Aloha Pedro 
E aí compadre, tamos precisando conversar sobre vários temas dos nossos projetos , como tá dificil da gente se encontrar vai o recado por aqui mesmo, com as devidas desculpas aos demais da lista pelo off topic. 
Vou pegar carona no teu mail para responder a missiva de nosso amigo . 
Os temas da lista tem uma orientação, vale a pena ler os arquivos da lista, a maior parte dos temas e termos usados tao ali elucidados, esta lista tem uma proposta de estudo, assim quem entra precisa dar uma " atualizada" lendo o material que já foi enviado. 
Temos uma proposta nesta lista, nada de material off topic, nada que não seja diretamente relacionado ao tema. 
ISto ajuda a termos certeza que quando abrimos um mail da ventania estamos numa "sintonia" de aprendizagem efetiva e nao apenas diletantemente presentes. 
TAmbém considero que tamanho dos mails não é problema algum, eu que mando uns enormes seria o mais incorente se colocasse algo contra na lista. 
Aliás trabalho com isso em várias áreas, esse papo de que temos de ser "práticos" e "sucintos" que as pessoas não gostam de ler e assim temos que ser diretos e tal deve ter alguma utilidade em alguns ramos do marketing, mas aqui, numa lista que busca trabalhar com profundidade temas complexos, ,quem tem preguiça de ler já tá no lugar errado, pois uma das bases do xamanismo guerreiro, que é o estudado aqui é o trabalho no sentido contrário da preguiça. 
Essa idéia de "corpos" não está presente no xamanismo guerreiro. 
Aqui temos dois corpos, o denso e o de energia. 
Para nós, mente, emoçòes, tá tudo no corpo denso, a dualidade é corpo denso,tonal, e corpo de energia, nagual, a primeira atenção e a segund atenção. 
D. Juan Matus ria muito dos esquemas "ocultistas" que Castañeda lhe apresentava, dizia que falavam do outro lado baseados nesse e que é claro que só podiam estar falseando. 
O tonal é descrítivel, assim tudo que podemos definir, por mais sutil que pareça, ainda está no tonal. 
Nagual é outro lado do par, só citado para que o saibamos existente, qualquer tentativa de "classificar" , de "rotular " o tonal é mera tentativa , nao há como, no nagual só há agir. 
As escolas externas de yoga deixaram muitos conceitos semi apresentados assim esse trabalho nos chacras está ligado a todo um conectar do ser humano com dimensões sutis da existência, dimensões do tonal. 
Blavtsky teve um trabalho brilhante, admirável em sua época, mas os conceitos de corpos e tudo mais nao fazem parte do xamanismo guerreiro, mesmo entre caminhos ocultistas e esotéricos mais profundos se aborda esta questao em outros paradigmas. 
O problema é que continuamos presos a idéias de que o que o ocidente chamou de espiritual é em si o nagual e me parece que não é , é apenas uma parte mais sutil do tonal, mas como pode ser definido, quantificado, localizado é TONAL ainda. 
ABandonar o corpo físico seria mais ou menos a coisa mais absurda que se poderia propor para um(A) praticante do caminho do guerreiro(a). 
É justamente o contrário, precisamos de "visceras de aços" corpo inteiro, saudável e flexível para ativar ao máximo o corpo de sonho, isto para os propósitos dos novos videntes, que aspiram pelo abstrato estado chamado de liberdade total. 
É o corpo físico tudo que temos no começo de nosso caminho, já que a proposta xamanistica dos (as) toltecas não fala de termos uma "alma" ou nada assim, a menos que trabalhemos muito prá isso. 
Quem estranhar estas proposições recomendo a leitura da obra de Ouspensky e de Gurdjieff. 
Dentro de uma linguagem mais aparentada ao esoterismo comum e ao ocultismo europeu eles explicam que a abordagem teosofista de muitos corpos, já existentes, é um equívoco e trabalham com esta mesma idéia da criaçao do corpo de energia, para que então comecemos a falar de sermos uma individualidade e não um aglomerado. 
SEgundo os feiticeiros o corpo energético está no começo meio que "encerrado" dentro do corpo físico e por isso estamos sempre a caminho da morte, pois o corpo ener'getico anseia por sair e ser uno com a energia que nos circunda. 
Uma das artes dos(As) feiticeiros é abrir as portas mágicas que temos em nós e trazer o corpo de energia para fora, o "forjando" , então muda a situaçao, o corpo de energia se expande e ao mesmo tempo, "pressiona' o corpo denso, dando-lhe uma continuidade e resistência impressionantes. 
Os "eus" que citamos aqui, em minúsculo por convenção, sao os muitos estilos de agir, de emocionar-se de raciocinar que trazemos em nós, estilos diferentes vindos de muitas vidas de muitos seres, que como num tapete, podem ser usados , após este tapete ter sido desmanchado, em outros tapetes. 
CAda ser pode se tornar uma individualidade singular. 
Quando esta singularidade se fizer em seu corpo, quando deixa de reagir para agir, dizemos que trabalhou seu corpo de manifestação, isso tem uma ação num chacra , quando o emocional é também singularizado, quando deixamos de ter apenas emoções resultantes de estímulos para realmente termos nossas emoções, surgidas de nós , singularmente, algumas escolas dizem que temos o "corpo emocional" , o memso ocorrendo quando conseguimos ter uma mente racional singular, que pensa por si e não apenas segundo condicionamentos, aí temos o "corpo mental " ativado. 
Corpo emocional e corpo mental concreto ( kama rupa e o manas rupa na teosofia) são um primeiro estágio, porque depois podemos deixar de apenas raciocinar e passarmos a PENSAR que é mais amplo ,aí podemos dizer que despertamoso corpo manas arupa , ou mental abstrato e ainda mais longe deixar de "emocionar" e aprendermos a "sentir" que é muito mais complexo, isso ativa um chacra e toda uma malha de energia em nós e pode ser dito que despertamos o EU singular em nós, percebemos que somos mais que o percebido, somos o ente perceptivo. 
ESte caminho foi explicado de várias formas, mas tudo isso é ainda o TONAL, que é amplo e rico em possibilidades. 
O corpo energético quando entra em atividade desperta outros níveis aidna mais complexos dessas facetas, somos seres duais, mas a dualidade não está em "corpo / mente" mas em corpo denso e corpo de energia. 
É um tema complexo , vale a penas ser bem trabalhado. 
Os toltecas insistem, estamos presos dentro de uma bolha de percepção, é preciso organizar tudo que temos como "conhecimento" de um lado da bolha e entáo é do lado vazio da bolha, sem nenhum "pré conceito" que vamos investigar a real natureza da ETERNIDADE, senão caímos na armadilha de tantos de nossos antepassados espirituais. 
Ao invés de presenciarmos a vastidao da segunda atenção como algo novo, desconhecido, inexperado,vamos cair na armadilha de projetar na mesma nossas descriç~eos da realidde e ficaremos vendo anjos ou demônios, duendes ou ets e outras interpretações que sao apenas projeçoes da forma humana sobre energia pura. 
Sim, temos muito mais meios que sabemospara vencer a MAtrix, por isso ela precisa do medo e da culpa, de fazer das pessoas menos que elas mesmas para continuar sugando a energia da vida. 
Sim, os portais estao se abrindo, muitos que partiram estão voltando e os tempos mudam. 
Que mil gatos (as) sonhem...