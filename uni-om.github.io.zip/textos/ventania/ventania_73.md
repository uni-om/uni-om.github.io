---
layout: texto
tags: [pérola, prática]
texto_number: 73
category: ventania
---
Date:Seg Ago 13, 2001 10:19 pm
Texto:73
Assunto: Re: [ventania] a individualidade dos guerreiros(as)
Mensagem:1173

É muito sutil o trabalho na trilha do(a) guerreiro(a)
Lendo as últimas mensagens da lista me lembrei de um evento que já citei
até mas vale a pena contar de novo.

Muitos anos atrás no sitio onde o pessoal do Oomoto se encontrava estávamos
eu e M. na Varanda, conversando com Marta, que na cozinha, estava ensacando
polpa de frutas.
Colocava em saquinhos de "chup chup" e depois congelava.
Usava um funil para isso.

Estávamos do lado de fora, a janela da cozinha , aquela de vidraças,
baixada, permitia que conversassemos.

De repente a Marta deu uma pancada no vidro, fomos olhar o que era
assustados, ela havia prendido com o funil uma mosca na vidraça.

O tema de nossa conversa tava versando sobre disciplina, trabalho e
liberdade.

Ela comentou que estávamos na situação daquela mosca, a não percepção do
vidro nos fazia crer que ficar rodando na parte ampla do funil é que era
liberdade, mas a averdadeira liberdade era ter a coragem de nos limitarmos,
limitarmos muito até a ponta do funil , mas então, quando atravessássemos a
estreita passagem, quanta liberdade real havia lá fora.

Comentou que todo caminho profundo ia por aí, primeiro parecia que a gente
sofria uma limitação, mas isso era uma "focalização" do que antes era
confuso e diluído em nós.

O caminho de várias tradições, entre elas o xamanismo guerreiro, começa
assim, como uma restrição, como uma limitaçao, pois no estado "comum" que
estamos nem sequer existimos.

É claro que para quem acha que tá pronto, que já tem "muitas vidas de
experiência" e tudo mais este tipo de idéias não tem valor algum.

Por isso se diz que no xamanismo guerreiro voluntários (as) não são bem
vindos(as).

Há um falsear quando a pessoa se recusa a jogar o jogo para querer impor
"suas' próprias idéias.
TEm pessoas que chegam no caminho "sabendo tudo" .
Assim já trazem seus esquemas prontos e querem adaptar idéias que nada tem a
ver com as propostas do caminho, aí usam as palavras tonal, espirito,
nagual, lado esquero e tudo mais com os mesmos significados que davam a
compreensoes oriundas de paradigmas completamente diferentes.

A falácia é que este "eu" que pretende "ter" 'suas " próprias idéias, nem
existe, e' um aglomerado uma ilusão.

Esta constatação é fundamental para entender que nãoe stamos falando de um
caminho que quer "impor" suas idéias ou algo assim.

Temos que meditar muito, observar muito a nós mesmos para então, por
constatação pessoal, não crença, compreender que o "eu" que usamos é um
aglomerado, que não nos pertence, que precisamos "gerar" um "eu" .

TEmos que morrer para este antigo "eu" e entao renascermos de nós, por nós e
através de nós mesmos.

TEmos que começar nos observando, nos estudando para percebermos que o que
chamamos de "eu" é um aglomerado, o que queremos de manhã , muda a tarde a
noite já é outra coisa.

PErmitir que nasça um "eu efetivo" que tenha continuidade é uma das
primeiras tarefas de todo caminho profundo.

O problema é que quem está exposto a um treinamento verdadeiro desse vai
querer muitas vezes provar "que é livre" , "que não segue ninguém" e vai
criar linhas de ação que apenas enfatizam caprichos pessoais, mascarados de
"minha vontade" e ainda enfatizar ações que apenas reforçam o lado
caprichoso e indolente de nossa natureza , travestidos de "dou minha
interpretação " e " não sou seguidor" .

Canso de ver isso, pessoas que "seguem" o sistema que lhes foi implantado
dia e noite, justamente num processo de treino resolvem "provar que não
seguem" , que "tem idéias próprias e então resolvem brigar com o Caminho, ao
invés de concetrar suas brigas para onde devem que e' o sistema.

Viver com alguém que trilha o caminho é aterrador para muitos e esgota
mesmo, pois uma pessoa que está conectada ao espirito exerce uma pressão
constante , um empurrar que para quem não está acostumado é cansativo e
muitas vezes irritante.

Todos temos essa pressão interior, que nos lembra que somos muito mais que o
"que fizeram de nós" , mas fugimos de várias formas dessa pressão.

É interessante notar , as pessoas quando estão cheias de energia colocam:
"preciso gastar essa energia" e lá vão.

Usando meios diversos evitam sempre o silêncio e a solidão, necessidades
fundamentais de quem vai em busca de si .

MAs na trilha dos (as) guerreiros(As) fazemos justamente o contrário,
enfatizamos esses valores e isto é incomodo demais para quem não está
afinado com tais propostas.

A forma que um (a) guerreiro (a) lida com o mundo, sua total sintonia com o
Intento pode levar a quem não está preparado e ainda mede o mundo pelo seu
próprio ego , a se sentir hora manipulado, hora sob engodo.

A questão é que um(a) guerreiro não age pelo ganho pessoal, seu propósito
ulterior é seguir as orientações da Totalidade e apenas isso, como dizia D.
Juan Matus, um (a) guerreiro (a) não age pelo lucro mas pelo espírito.

E é deveras dificil entender isso quando a pessoa se sente 'usada" ou
"manipulada" , num dos joguinhos de carência e auto piedade nos quais a
maioria está mergulhada.

Um (a) guerreiro(A) quando é posto na condição de ensinar algo a alguém deve
saber que tudo que podemos no começo é demonstrar sobre o "agir sem esperar
recompensas" , o "agir pelo agir" .
Tudo que alguém que ensina pode fazer depende depois do sucesso neste
primeiro ítem.

No caminho tolteca se recomenda que em primeiro lugar ajudemos as pessoas
que querem ir mais fundo nessa proposta a perder a auto importÂncia, é claro
que quem vai trabalhar isso precisa já ter tal tema trabalhado em si, do
contrário pode falhar miseravelmente, inclusive se preocupando com o que
pensa sobre si a pessoa que está sendo ensinada e pior se preocupando em
conseguir resultados.

Agir sem esperar nada em troca é a base, assim se usamos de um longo tempo
porque sentimos sinais em relação a alguém e este alguém não vai a lugar
nenhum, nada disso deve nos incomodar,os caminhos são misteriosos, as vezes
uma semente precisa dormir anos na terra antes de brotar.

Assumir as responsabilidades sobre os própios atos, que é deixar de ser
vítima e culpar algo ou alguém pela sua condição de vida e ter a morte como
conselheira são outros dois pontos fundamentais que devem ajudar as pessoas
que buscam a trilha dos (as) guerreiros(as).


Tudo o mais é supérfulo nessa fase, pois sem estas mudanças fundamentais
podemos apenas estar ampliando nosso sono, coisa desnecessária.

Alguns pontos que vieram a minha mente nesse instante e quis partilhar.