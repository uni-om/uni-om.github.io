---
layout: texto
tags: [péerola, prática]
texto_number: 74
category: ventania
---
Date:Ter Ago 14, 2001 11:49 pm
Texto:74
Assunto: Re: [ventania] Jogos de Manipulação
Mensagem:1183

ALoha lista;

Aloha Dhyana

Concordo contigo quando dizes que a liberdade não pode ser arrancada, tem
que ser cultivada, exatamente este cultivo que é tão delicado, por isso não
podemos querer "seguir" os passos de Castañeda , TAisha e Florinda ou quem
quer que seja, pois cada um tem sua própria caracterísitca.

Mas estas pessoas tem outro papel, são mitos.
PErdemos muito em relação aos mitos com a adoção do filosofismo excessivo de
nossos dias, ainda desconhecemos o poder do mito, o mito é outro estado de
existência, é mesmo uma posição do sonhar, um sonho.

Só entrando num nível mítico podemos mesmo viver as propostas do xamanismo
guerreiro e um mito é uma história viva, uma história que reatualizamos em
nossa realidade existencial.

Assim existe uma diferença entre "seguir" o caminho proposto e "viver o
mito" reatualizar o mito ritualizando-o em nossas vidas.

São conceitos sutis que temos de observar bastante, pois o que pode começar
como mera imitação pode levar alguns a alinharem-se com um INTENTO que
transcende tempo e espaço e então o mito é reatualizado.


TRilhas existem muitas, no exemplo do Kechan por exemplo é algo que
interessa pensar que a mesma trilha pode ser trilhada por muitas pessoas e
nunca será a mesma trilha, nem serão as partes percebidas as mesmas.

Sim, o caminho é solitário, aliás um dos grandes problemas para que as
pessoas se aproximem de fato do caminho do(a) guerreiro(a) é isso, é a
solidão do caminho.

Me lembro de Oomoto certa vez comentando que mesmo um grupo de pessoas em
trabalho eram como bambuzais, podiam estar próximos , mas cada um com sua
raíz.

E é esta a proposta do caminho, não criar muletas ou criar dependentes, mas
ajudar quem deseja a estar cada vez mais ciente de si, ciente da realidade
circundante e assim mais apto a despertar de fato.

É um desafio muito grande este do despertar, porque a quase totalidade que
uma pessoa crê fazer parte do "caminho" é na realidade ainda lixo da vida
antiga que quer se insinuar na nova proposta.

Já viram que os projetos sobre quebra da imunidade parlamentar ou diminuição
do salário do legislativo tem raras chances de acontecer, pois o grupo não
vai legislar contra si mesmo.

O conjunto de falsas personalidades que nos compõe, o conjunto de jeitos de
reagir , emocionar e raciocinar que nos mantém hipnotizados e ausentes de
si, não vão "tramar" para sua própria derrubada.

Assim, no começo, o trabalho pode ser tremendamente falseado quando
projetamos nossos caprichos, medos e carências levando-nos a decisões que
podem mais nos afastar que nos levar a meta da lembrança d enós mesmos, do
despertar e da liberdade.


O grande problema me parece é a tal da projeção, ficamos projetando nossos
conceitos nas pessoas, aí já queremos julgar, determinar se tal pessoa é
mesmo "guerreira" se nao é , se é mais ou menos e nessa fuga, enquanto
ficamos a julgar outros, escapa o único trabalho possível que é o que
podemos realizar sobre nós mesmos.

Para um (a) caminhante atento tudo e todos são mestres e mestras do caminho.
Se estamos sensíveis vamos perceber a mensagem na pena que voa numa rua
movimentada, nos pássaros que passam, no sol, no céu, nas palavras que as
pessoas dizem, enfim, o mundo se comporta de forma a ser todo evento e
pessoa em nossa vida uma indicação, um sinal, um augurio de poder.

A questão é se vamos ler tais sinais com nosso lado em busca da Liberdade ou
com o antigo e condicionado "eu" .

As pessoas quando saem para uma jornada de poder muitas vezes sentem o
"mistério" o "algo a mais", mas quando voltam ao cotidiano de suas vidas
acabam mergulhadas, na maior parte das vezes sem nem se darem conta disso,
no mesmo eu medíocre de sempre, medíocre mesmo , no sentido de mediano.

Quando se fala demais sobre o passado, sobre as pessoas que viveram emnossas
vidas, quando falamos demais sobre o "mim" , "mim" , "mim" deixamos de dar
espaço para o novo chegar .

O grande teste é sempre esse, se o eu mediocre vence ou a essência
perceptiva optará por se alinhar com o conjunto de formas de ser que pode
nos içar para fora desse atoleiro onde fomos colocados .

Outro ponto que me chama a atenção é o detalhe que citas de ser nada.
Dá um trabalho danado a gente ser "nada" .
Somos condicionados a "ser alguém" .
É um apelo profundo que plantam em nós e que esta cultura de mídia acentua
mais que nunca, o "ser alguém" , o "aparecer" , "brilhar perante o grupo."


É preciso meditar profundamente para entender a quem estamos servindo,
sempre fomos posto a servir alguém a querer agradar alguém, a '" provar"
para alguém, pai, mãe, irmãos (ãs) , filhos(as) ,
companheiro(a) ,amigos (As), enfim alguém que em algum momento escolhemos
como nossa "testemunha de vida" .

Isso é muito sério, um dos primeiros passos no caminho de xamanismo que
trilho é descobrirmos quem são as nossas testemunhas.
Muitas vezes elegemos estas testemunhas crianças e passamos a vida inteira
"provando" coisas para essas testemunhas, que quando ausentes ganham ainda
mais poder, por estarem mergulhadas em nossa psiquê e nos dominarem de
dentro.

Não é dificil perceber quem sào as "testemunhas " da nossa vida , é a
pessoa, ou pessoas, pois podemos ter criado mais de uma, que citamos
constantemente e em momentos diversos vamos nos ouvir " fulano ou fulana
precisava ver isso" .

Libertarmos a nossa energia dessa "testemunha" é fundamental, porque no
xamanismo temos sim uma testemunha, mas não é ninguém , é o ESPIRITO< o
INTENTO, algo que não pode ser descrito, mas que sabemos existir.

Essa TEstemunha silenciosa é nossa companheira constante e os (as) xamÃs
guerreirosA(As) consideram cada ato realizado um ato de abandono e um ato
"artístico" realizado para essa testemunha silenciosa.

Com atos refinados os (as) xamãs acenam para o Intento e convidam essa força
misteriosa a vir até nós.

MAs para irmos a esta "testemunha" temos que nos libertar da testemunha
humana que colocamos em nossas vidas e recapitular ajuda nisso também.

TEmos um problema muito sério com o poder, as pessoas querem muito manipular
as outras, querem muito dominar e implantar seus próprios esquemas e isso
gera todo um quadro social como o que assistimos, onde há uma disputa pelo
dominar, pelo poder.

Sobre esse tema recomendo um filme chamado "Instinto" com Anthony Hoppinks,
vale a pena , pois debate esse problema chave, a necessidade de dominar.

CAda um de nós tem uma experiência singular a viver, precisamos mesmo viver
tal realidade singular, pois só dai podemos surgir enquanto "entidade" ,
enquanto causa, ao invés de continuarmos a ser mera consequência de eventos
que foram deflagrados alhures.

O interessante que por mais que a gente deixe claro que não é nada, que está
ali mas ninguém pode ter segurança nenhuma que vais estar no instante
seguinte, mesmo que tenhas já no nome a idéia de efemeridade e passagem,
como meu "Nuvem que passa" ainda assim tem gente que insiste em querer
eternidade, em acreditar que pode mesmo contar com algo da tua parte, risos.

A loucura da dependência humana é sem limites, as pessoas aprendem, mas
depois preferem esperar que apareça de novo outro alguém, outra idéia, outra
"muleta" e desistem de provar que valeu a pena aprender e a única forma de
mostrar que realmente aprendeu algo é enfrentando com eficiência as soluções
de vida.

Quem se entrega e existem muitas formas de se entregar, apenas continua a
ser o que sempre foi, o desafio não é esse, o desafio é ousar mudar, é
responder de uma forma nova e criativa ao desafio imenso que é estar vivo,
que é acordar toda manhã e enfrentar um novo e desafiante mundo a nossa
volta.

e este desafio não acaba nunca, a cada instante é renovado e a cada instante
podemos responder este desafio como guerreiros (As) ou como tolos (as).

É nosso poder realizar esta opção.
O poder mais sagrado que temos.