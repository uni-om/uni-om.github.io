---
layout: texto
tags: [mapa]
texto_number: 76
category: ventania
---
Date:Sex Set 7, 2001 8:02 pm
Texto:76
Assunto: inciando
Mensagem:1232

ALoha lista 

Vou iniciar com este mail uma série de nove mails que são resultado de reflexões que surgiram como resultante de um encontro que ocorreu em certa região da Guatemala e outros, resultante deste, em alguns locais de Hybrasil. 
EStamos vivendo num tempo que os antigos maias falaram, um tempo de transição, uma saída de um estado de "eclipse" em relação a forças de Hunab Kü, o centro galático e voltando a receber energia com mais plenitude. 
Vou tentar ser mais claro para quem não está familiarizado com o tema. 
Para nós que trilhamos os caminhos ancestrais a abordagem da realidade é feita por outros paradigmas. 
Assim, consideramos que há alguns milênios, especialmente nos últimos 500 anos, houve uma progressiva ascenção de grupos humanos cuja relação com os outros grupos é de subjugação e destruição. 
PAra nós isso ocorre porque os seres humanos estão fora de sintonia e esta ausência de sintonia torna o ser humano um destruídor, um criador de conflito e não de equilibrio, como poderia ser. 
Povos ancestrais diversos sabendo que isto iria ocorrer se prepararam para migrar, nào apenas para outros locais desse mundo, mas também para fora deste mundo, para um mundo outro que não este. 
TAis "viajantes " entre dimensões continuam suas vidas e aventuras existenciais e aparecem de tempos em tempos aqui na Terra. 
Consideramos que com a mudança de certas energias que ainda estão incidindo sobre a Terra, sobre esta dimensão da Terra, pois a Terra é um ser que tem mais dimensões que as que percebemos, com suas próprias esferas de vida nelas, tais mudanças podem resultar entre outras coisas na volta a vida neste plano da realidade de povos que no passado partiram. 
Os Maias estão entre esses povos. 
Quando partiram eles sabiam que a Terra ia entrar numa condição de "eclipse" em relação a certas energias sincronizadoras que emanam do núcleo galático. 
O que os Maias perceberam e outros tantos povos, é que a era do eclipse desenvolveu um conjunto de instituições , pessoas e entes que vivem dessa condição e a volta a um estado de plena energia inviabiliza os planos de dominação e controle que estes grupos exercem. 
Foi quando resolveram partir. 
ESta partida foi realizada por muitos clãs, ainda hoje é realizada. 
PAra compreender isso precisamos dos recursos mais abstratos de outra compreensão da realidade. 
A forma pela qual os Maias e outros tantos povos nativos viam a realidade era profundamente diferente da que hoje adotamos, por isso toda a colocação que vem a seguir precisa ser cuidadosamente estudada para evitar interpretações equivocadas, leituras presas a paradigmas que não são coerentes com os que geraram estas informações. 
Eu acredito que estamos num momento crucial de uma longa luta, uma luta entre consciência e inconsciência, entre vida e destruição, entre liberdade e opressão e as atitudes que tomarmos agora serão decisivas para o nosso ingresso ou não numa condição diferente de realidade. 
Nossas atitudes são nossas armas, com elas demonstramos se estamos alinhados com a vida ou com a destruição. 
A ERa Industrial está acabando, o planeta está exaurido em suas possibilidades de receber o lixo gerado por este modelo de vida. 
Ao mesmo tempo que polui e destrói mananciais o modelo dominante támbém age predatoriamente em ecosistemas que degradados geram disturbios climáticos. 
A qualidade do solo vai sendo depauperada, tornando a dependência de fertilizantes e nutrientes químicos cada vez maior, com o consequente dano ao meio. 
Pragas resistentes, resultantes da aglomeração de tantas plantas da mesma espécie num mesmo local, levam a venenos cada vez mais possantes, isso tudo entrando na terra, levado pela chuva, se misturando em tudo. 
Doenças tidas como controladas, como a tuberculose, voltam em versões mais perigosas devido a super resistência causada pelos antibióticos e seu uso desregrado. 
Um grupo de países , no hemisfério norte, vive bem e confortavelmente enquanto nós sangramos , vendidos sem nem bem saber como nem prá quem, vendo miséria e violência onde sempre foi Hybrasil, terra pródiga que uma flecha lançada sempre podia trazer algo prá se comer, 
A perda da dimensão mítica da humanidade e sua redução a um conjunto de crenças simplistas e consoladoras permitiu um dominio da alma do mundo antes desconhecido pelos que que dominam. 
SEm os mitos, as histórias de poder, a humanidade caiu num sono, o sono do esquecimento. 
As lendas antigas falam desse momento. 
Os filhos e filhas dos povos ancestrais com os conquistadores estariam hipnotizados, servindo aos conquistadores. 
MAs a serpente emplumada mais uma vez viria. 
Na sua forma de bolha de luz. 
Os textos que seguem falam desse momento, dessa volta do clã da Serpente emplumada, ao lado de outros clãs, em ações incisivas para transformar a realidade 


In lakesh! 

Eu Nuvem que passa falei 
Passo o bastão 
Ho!