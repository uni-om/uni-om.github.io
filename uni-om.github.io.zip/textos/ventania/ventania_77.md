---
layout: texto
tags: [pérola, mapa]
texto_number: 77
category: ventania
---
Date:Sex Set 14, 2001 12:07 am
Texto:77
Assunto: Mudar de mundo. (texto longo)
Mensagem:1245

ALoha lista;


É interessante observar o ano de MArte.

Prá mim é um ano de Ogum, dos deuses gêmeos guerreiros, a energia é plena, não aceita mais ou menos, age pelo pilar do Rigor da Árvore da Vida.

As energias num ano de Marte movimentam-se com intensidade, como num surf, não se exita num ano de Marte.

É estar atento para onde a onda vai quebrar e ir no fluxo.

Mudança parece ser um sinônimo para o ano de Marte e quando mudançã aparece nesta civilização a gente vê a crise.

A crise .

Me parece que o apego gera a crise, pois o apego a uma situação ou pessoa ,acaba nos limitando a querer ficar agarrados(as) a ela.

E na condição do apego ficamos vulneráveis e diluídos, confundimos o que percebemos como realidade, quando é uma interpretação da realidade.

Os (as) xamãs insistem muito nisso, há uma interpretação que fazemos da realidade, que gera nossa percepção de mundo e a percepção de mundo tem uma relação dialética com nosso estado de consciência.

Percebemos, isto é um fato, mas o que percebemos é uma descrição.

ESTa sacada dos(as) xamãs é uma chave importante, a meu entender.

Tudo que temos por realidade só o é, porque acreditamos coletivamente nisso, fomos levados a isso "formados" , "moldados" e a programação se reforça todos os dias na Matrix, na Tv, nos jornais, nos lugares da moda, no "jeito de ser" e por aí vai o hipnotismo profundo que mantém o homem e a mulher tidos por civilizados , como robôs servis a este sistema que lança humano contra humano.

MAs uma coisa é saber disso intelectualmente , outra é praticar isso e nessa diferença sútil tá uma chave de viver a vida ou sobreviver a vida, fazer a história da tua vida ou sofrer a história da tua vida.

O xamanismo sendo um caminho nativo é agudamente consciente da tremenda manipulação que o conquistador colocou sobre os povos dominados ( nós, tem gentes que esquece que somos exatamente os descendentes dos dominados, vivendo na mesma colônia de sempre, administrada por guildas e bancos a serviços mercantilistas, com suas farsas de políticos e regentes para disfarçar quem realmente exerce o poder).
Por ter tal consciência nossa busca é ir além destes limites, não de forma "simbólica" ou "subjetiva" , mas em ato e presença.

Assistir "Instinto" neste momento levanta uns questionamentos interessantes.

Por que a humanidade não resolve seus problemas por outras vias que não a militar, o ataque , a morte, a dor, o sofrimento, a conquista, o DOMÏNIO?

Por que essa necessidade do ser humano de dominar outro ser humano?

Por que o diálogo não existe mais, sendo a política um campo de interesses
e os homens tidos por líderes dos países meros facilitadores dos processos mercantilistas que ainda dominam as relações entre as nações?

Tudo foi coisificado, virou mercadoria, inclusive o ser humano.
Isto é terrível e o que é o terror que assistimos e nos assustamos senão a resposta a este estado de coisas.

A cultura nativa oferece outra interpretação da realidade, outra realidade portanto e precisamos ter muita coragem para acreditar no que nos é oferecido.

A maior parte das pessoas vai sorrir e deixar de lado o que os povos nativos tem a oferecer, pois desconhecem a amplitude da ETERNIDADE foram confinadas a uma estreita interpretação da realidade e tudo que desconhecem ao invés de dizerem : "não sei" , dizem "não existe".

Os poetas costumam ter a percepção da realidade favorecida, Fernando Pessoa, a meu ler, fala mais a minha alma pagã que quilos de outros "especialistas simbólicos" .

Me parece que a atual civilição foi limitada a uma percepção estreita da realidade, por isso quando falamos de mudanças, de transformações sociais e politícas e econômicas estamos apenas rearrumando as mesmas peças fundamentais.


Vejam o estado do mundo.
Em choque pelo recente atentado nos EUA, em todo o mundo só se fala nisso, há uma comoção mundial, intensa, formatada pela net, tvs por satélite e tal o mundo inteiro só fala numa coisa, só comenta isso.

A alma do mundo ficou pesada por estes dias, é sensível isso, só abrir os ouvidos e ouvir do que se fala em todos os cantos do mundo.

ESsa capacidade de focalizar a atenção mundial num evento e levar todo o mundo a reagir a ele é algo que só agora começa a ser avaliada em toda sua extensão.

O ponto pragmático, existe essa possibilidade a quase totalidade do mundo focada em uma idéia.

O que os povos nativos apresentam como caminho opcional a esta realidade existencial que temos por única é uma mudança muito mais radical que a mudança de moeda, de partido, de sistema econômico, social , é uma mudança mais profunda que transforma os paradigmas de forma radical.

Se observarmos a realidade do mundo a nossa volta vamos perceber que é de uma crise em todos os setores.

Social, político, econômico, instituiçòes, papéis na sociedade, o ser humano com ele mesmo, a relação com a natureza e a preservação de condições dignas de vida as futuras gerações, em todos esses campos e mais tantos outros o
ser humano está em profunda e insolúvel crise.

É só abrir olhos, ouvidos, cheirar e degustar o mundo, sentir a agressão dos raios solares pela ausência ( crescente) da camada de ozônio.

TEm uma área do tamanho do estado de Sergipe queimando agora na Amazônia, espécies que nem sabemos que existem estão, AGORA, se extinguindo e extinção é prá sempre...

Os caras lá na estação espacial já falaram, o mundo tá ficando cinza e tem gente que ainda acha que dá prá esperar pelas "mudanças progressivas" propostas pelos estados industrializados.

Por isso a proposta nativa é tão radical, não se trata de mudar o sistema , de mudar isso ou aquilo, mas de "mudarmos" daqui.

Sim, nós mudarmos, ao invés de mudarmos o mundo vamos nos "mudar" do mundo, deixar nele quem quer nele viver, quem quer continuar nessa descrição da realidade.

Há dois mundos existindo paralelamente, um que está acabando e outro que está começando.

A proposta do mundo nativo é que nos mudemos para o que está começando e deixemos a destruição dar cabo de suas crias.

É loucura bater de frente com os complexos sistemas militares e de inteligências que os poderes dominantes criaram para manter sua supremacia, a luta pelo poder envolve manipulação de armas nucleares, químicas e biológicas, doenças estão sendo desenvolvidas agora, em laboratórios vários do mundo, para serem usadas como armas.

Nossos antepassados resolveram o enigma da mesma forma, quando o in\vasor tomou tudo no mundo conhecido eles ousaram se aventurar onde o conquistador nem sabia existir, o "desconhecido" .

É desse desconhecido que voltam alguns desses povos agora, com suas sofisticadas tecnologias que tentam de todo jeito despistar, fingir se outra coisa, confundir e amedrontar para que não percebamos os fatos.

Eles (As) estão voltando, como garantiram que fariam.

Cada um é livre para escolher seu caminho, mas eu e vc que não combinamos com esse jeito de sobreviver, de implorar por migalhas de um todo que na realidade nos pertence temos uma opção.

Os Maias estão voltando.

Eles(as) podem voltar prá cá ou para um planeta gêmeo nosso que esta próxima a estrela dupla de Sírius.

E tudo uma questão do estado de consciência de cada mundo.

Os Maias são viajantes cósmicos habilidosos, manipulam com a realidade de uma forma que só podemos definir como "mágica" .

Há um risco, confundir o retorno dos Maias como messianismos, com "salvação" e outras bobeiras afins.

A volta dos Maias é a ponta de um Iceberg.

PAra nós do xamanismo a volta dos Maias , dos Asgardianos, dos de Tule, de Tula, de Matatu Araracanga, dos Anassazi, o misterioso povo próximo ao rio Congo que lendas ancestrais contam terem ido embora e prometido voltar, povo que teria originado o saber no qual mais tarde os sacerdotes egipcios beberiam.

Todos esses povos ancestrais foram para outras realidades, partiram, continuaram a grande aventura de ser livre e consciente neste vasto mar da existência.

O tempo da conquista havia chegado.

SEres humanos conquistavam seres humanos e os subjugavam por armas e crenças, forçando-os(as) a serem estranhos(As) a si mesmos(As).

Antes dos Íberos neste continente os povos daqui mesmo já se dividiam em "Conquistadores " e ""Conquistados" .

MAs agora há uma mudança no horiznte, podemos levar a Terra para outro estado de consciência, se a realidade é uma função do estado de consciência podemos auxiliara a consciência da Terra a sonhar outro sonho, pois cada realidade é um sonho, e sonhando juntos, um sonho de mil gatos (As) o mundo pode apenas ser maneiro de se viver, só isso.
Como já foi um dia, mas nos fizeram esquecer disso para que servíssemos melhor desconhecendo que perdemos o paraíso aqui e agora ao acreditarmos na promessa de um futuro.

Agora o conceito de mudança me parece muito atrapalhado nesta civilização.

Mudar, transformar, transmutar, são gradações de uma energia.

Eu procuro sentir os planetas como "Chacras" , como pontas de cone, o momentum onde o cone, originalmente elipse infinita se torna ponto.

Um planeta está assim emanando energia, que captamos como a forma do planeta, como a sua existência.

O que chamamos tangibilidade, realidade, no xamanismo a gente observa como emanação, como algo que é a "ponta do iceberg" de algo mais amplo.

Mas não estamos indo para um "platonismo" com mundos das idéias e tal.
SEria legal deixar isso claro para poder ser claro quando chegar no tema que quero abordar.

PRos referenciais que to usando para avaliar o que vou dizer em seguida, creio que é importante reinterpretar uma questão fundamental.

O ocidente tem vários movimentos "espirituais", várias "ondas" de religiosidade.

Podemos começar com a religiosidade mais fundamental, a que chamamos, "popular" .
Há sempre uma religiosidade "popular' uma religiosidade singular em cadaindividuo, se notarmos de fato o comportamento religioso das pessoas veremos que cada uma está tecendo uma interpretação bem pessoal dos conceitos e formas de culto que sua religião lhe ensina.

Os sincretismos, as pessoas que se ligam ao cristianismo, budismo, islamismo, Vedanta, e outros caminhos de massas, mas praticam um lado "esotérico" desse caminho, assim passando despercebidas para as pessoas que estão "de fora" desse caminho estreito.

Essa amplitude de possibilidades, se nós sabemos com certeza que existem sim mestres(as) vivos, que existe este tal plano esotérico da humanidade onde seres despertos tentam harmonizar esse caótico mundo, vitima de condição alheia, vinda da natureza mesmo da Eternidade, mas agora já em condiç`~oes de reequilibrio.
Ai se convencionou dizer que há um mundo espiritual, geralmente para depois da morte.

PAra o xamanismo o mundo do além é a outra parte deste mundo, muito mais vasto, mais amplo, mas apenas a outra parte, nem superior nem inferior, outro mundo, com maravilhas e coisas assustadoras.
Por isso essa idéia de ir para outro mundo não é "fugir" desse mundo mas trabalhar por um sonho coletivo de uma nova realidade e isso só é possível por atos.


Muito mais ameaçador que vários ataques a bomba para o sistema dominante, é quando começamos a agir com consciência, com foco, lembrando de nós mesmos.

Quando começamos a agir prazeirosamente e vamos ousando transformar nossas vidas, em pequenas coisas no ínicio, pois temos que lembrar que temos de treinar a habilidade de fazer, de agir, pois é uma mentira que agimos, quando na maior parte das vezes "reagimos" a estímulos diversos que recebemos e a maior parte nem notamos.

Muito mais ameaçador que armas e bombas para o sistema dominante, que nefastamente ganha com a produção de armas e bombas, que mantém laboratórios e seres humanos, agora, gerando tecnologia para matar em massa, é agir com foco onde estamos, é estar presente e por em cada ato, de lavar um copo a realizar um ritual, uma intenção plena, presente, que faz com um tipo diferente de energia se manfeste nessa realidade.

Por isso os povos nativos em várias ocasiões e encontros que foram realizados nesse continente e em outros tem proposto esse caminho, mudar de mundo, vamos ousar, ter a coragem de estar no mundo sem ser dele e sutilmente, em cada ato, agir de forma consciente e focada, isso é revolucionário e ao contrário dos atentados não mata, ajuda outros a despertarem tambem, pela força da energia da Vida, da Consciência que sempre se manifesta em ondas, irradiando-se.

Vou voltar ao tema.