---
layout: texto
tags: [pérola, mapa]
texto_number: 79
category: ventania
---
Date:Sáb Set 22, 2001 12:00 am
Texto:79
Assunto: Re: [ventania] Destino...
Mensagem:1276

É um questionamento muito interessante. 
Destino; 
ESTará o nosso traçado? 
ESTará tudo em nossa vida traçado, nós só representamos um papel, apenas realizamos um script que nos dão? 
Ou existem tendências, tendências que podemos seguir ou não? 
Um mapa astral, uma pessoa realmente capacitada em ler um mapa astral vai contar sobre tua vida de uma forma que te espanta. 
Como ela pode ler tudo ali? 
Então tudo já estava "registrado" , por ter nascido num certo momento e num certo lugar tu ganhastes uma programação que viestes cumprindo , julgando que eras tu que governavas tua vida, que fazia tuas escolhas, mas agora, descobres que uma pessoa estranha pega teu mapa e te conta tua vida, até com detalhes as vezes. 
Eu lido com TAROT. 
TEm pessoas que atendo há mais de 10 anos. 
É interessante acompanhar essas pessoas, os eventos em suas vidas e a forma como aparecem como possibilidades no TArot . 
Os que se realizam e, para mim o mais importante, os que conseguem ser mudados. 
Então eu diria que há uma linha de vida que cada pessoa parece receber ao nascer, é composta de muitas tendências, genéticas, astrológicas, os ancestrais, o lugar onde está, o pais, o momento que sua sociedade está vivendo, as informações que recebe da familia, do meio social, da escola , da religião, tudo isso vai sendo somado e atua sobre a pessoa. 
Creio mesmo que antes de nos trabalharmos somos só uma resultante de todos esses fatores, sem nenhuma individualidade. 
E se nem existimos de fato, somos apenas possibilidades, fica dificil dizer se temos ou não destino. 
Eu diria de outra forma, a ETERNIDADE para se conhecer lança sondas, lança "capsulas" de consciência, que somos nós e tudo que é vivo e consciente. 
Pela magia de estarmos vivos alimentamos e desenvolvemos essa consciência que recebemos da Eternidade, não somos os primeiros, esta consciência já esteve fluindo por esta realidade e outras, trás seus próprios registros. 
ASsim creio que estamos no meio de um jogo de vastas proporçòes onde somos ínfima peça. 
O que me interessa como guerreiro é que podemos ir além disso, podemos gerar a auto consciência, podemos nos tornar singulares e mudar assim toda a dinâmica de nossa existência. 
Por isso acredito que no CAminho temos que morrer e nascer de novo. 
O ser original, que nasceu e tem um nome e uma vida social, nasceu prá morrer, prá alimentar a consciência do vasto mar escuro que é nossa fonte, de onde emanamos e para onde voltamos. 
MAs nascendo de nós mesmos, por nós mesmos, para nós mesmos, podemos ousar ir além das determinações do destino e sonhar um sonho de liberdade de nós mesmos.