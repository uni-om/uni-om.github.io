---
layout: texto
tags: [mapa]
texto_number: 80
category: ventania
---
Date:Qua Out 10, 2001 10:39 am
Texto:80
Assunto: ComumNickação - 001mm
Mensagem:1315

Aloha lista; 
Chegamos aos tempos previstos pelos povos nativos , onde a vida estaria toda ameaçada, quando homens e mulheres guiados por seres perigosos iriam brigar pelo mundo, usando armas de grande poder de destruição. 
Mas também chegamos aos tempos da Tribo do Arco Íris e sua batalha, pacífica, bom combate, luta em essência, para que o Ser Terra que nos abriga sobreviva, se recupere e então plenamente consciente de novo, pois está em coma agora pelas agressões que tem sofrido, se auto regulará. 
Nós que seguimos os ciclos da Vida, que sentimos o pulsar da Terra e da Natureza temos um ritmo diferente de quem segue o ritmo das grandes cidades. 
Pode-se viver nas grandes cidades sem estar no ritmo delas, depende muito de tua postura existencial. 
Essa é a primeira manobra radical que podemos fazer no nosso surf do Zuvuya. 
Estar no mundo, mas não ser dele. 
"Se algo lá fora pegou fogo, deixe o fogo só onde ele está, não incendei o seu coração" 
"Se há inundação, deixe que alague apenas o que está a sua volta, não alague tua mente. " 
São ditos budistas, falam do desapego. 
O desapego é que nos permite entrar num estado de não ressonância às programações impostas do sistema. 
Respirar tranquilamente, procure prestar atenção na tua respiração, só prestar atenção, sem interferir. 
O apego, a posse, o controle, o domínio sobre o exterior são bases poderosas nesse sistema que aí está. 
O desapego é uma postura revolucionária porque vem de uma constatação de nossa efemeridade frente a vastidão da existência. 
A tremenda importância pessoal das pessoas hoje vem do medo de assumirem o nada que somos, a efemeridade de nossa condição, por não resolverem suas carências interiores ficam com medo de sentir o absoluto vazio da ETERNIDADE desprovido de emoções, o Olho do Dragão, puro INTENTO. 
E o medo leva a refugiarem-se em elaboradas imagens de importância pessoal e se alguém ameaça esta imagem podem fazer de tudo , loucuras, para salvaguardar algo que em si já é falso. 
Vejam a "guerra" que hoje está acontecendo no mundo, as pessoas tidas como chaves do conflito, é patético ver personagens tão estereotipados no comando de forças tão poderosas. 
A TRibo do Arco Íris vai partilhar alguns ritos especiais durante esta Primavera que visam principalmente curar a Terra. 
A solicitação é que sejam o mais amplamente divulgados para outros lugares do mundo, pois a proposta é termos uma teia acontecendo e se sincronizando, via Web, para no Solstício de Verão realizarmos um trabalho sincronizado em todo o mundo. 
É um desafio e um primeiro experimento usando a WEB , nossa teia, para nos auxiliar como Aranha Dourada, a tecer complexa teia, que não nos enreda, mas nos põe em contato e nos permite " comum - nick -AÇÃO " . 
O mundo é resultado do estado de consciência coletivo, a maior parte das pessoas não quer a guerra e os conflitos que estão aí, eles são mantidos por forças artificiais, como as politicas internacionais que favorecem conflitos , fortalecendo diferenças e ódios, com nítidos fins de provocar conflitos e de alguma forma ganhar com isso. 
Essa lógica perversa que vem alimentando o mundo conquistado não precisa ser a nossa lógica existencial. 
Cada um de nós pode se trabalhar pessoalmente e deixar de expressar em si os "tiques" do sistema, estas formas de estar no mundo dominadoras, agressivas, desequilibradas e violentas. 
E isso é possível em todas as esferas, mas precisamos começar isso no aqui e agora. 
Esta é a proposta da Tribo do Arco Íris, aqui começa o nosso combate, não indo lutar com alguém só porque tem uma cor de pele ou uniforme diferente, só porque adora outra face da Divindade, só porque me mandaram matar . 
O(a) guerreiro(a) interior que carregamos em nosso interior não pode ser corrompido(a) em mercenário(a). 
Existe um abismo entre o(a) guerreiro (a) e o(a) mercenário(a) 
O Dalai Lama me parece o único líder poliético de fato desse mundo tomado por guerras que acontecem apenas para continuar defendendo o direito de Roma e das Companhias das Indias Ocidentais e Orientais terem fornecedores de matéria prima barata e consumidores de seus manufaturados, agora feitos na própria colônia. 
VEjam o desapego de sua luta quase solitária, enfrentando pressões internas de outras facções , pois a luta pelo poder existe em toda parte, mas ali, sereno, transmitindo suas mensagens. 
Ali temos um de nós, ali está um guerreiro do Arco Íris na plenitude de seu potencial, agindo pelo não agir e a cada momento aproveitando para fazer cada um que dele se aproxima um pouco menos escravo, um pouco mais livre, sem proselitismo, como quem canta sua canção, crendo que almejando estrelas, atravessará com mais vigor o pântano lamacento das relações internacionais e levará o mundo a entender que o Tibet é livre, é inconcebível que em nossa Era a comunidade internacional ainda admita isso, obviamente por interesses econômicos. 
O mesmo acontece com os povos nativos, que continuam tendo seus direitos violados, suas terras invadidas, culturas sofisticadas, com respostas para muitos de nossos questionamentos, desde os surgidos nos aceleradores de partículas até os de saúde e qualidade de vida, estão sendo dizimadas, por mineradores, criadores de gado e madeireiras, principalmente. 
ESte modelo de destruição, de tomar lugares, matar quem está ali, destruir culturas para colocar as "pessoas que estão sobrando" dentro do país é um método que precisa ser repensado. 
É irônico que tal ato vil seja realizado na ancestral China, a China que viu Confúcio e Lao tse nascerem e manifestarem sua sabedoria. 
A China do Taoismo, da Acupuntura, das Artes Marciais, a China que descobriu a pólvora, mas quando os navios ingleses a tomaram com a força dos canhões, tinham apenas fogos de artíficio para responder, a China onde uma mulher, mestra em Shao Lin um dia disse: Quando criaram as armas, os covardes tomaram o mundo" . 
Estas forças que dominam o mundo são herdeiras diretas das que invadiram estas terras que hoje vivemos e destruiram as culturas que aqui existiam, quase completamente. 
Nós somos herdeiros dos Conquistadores, é muito séria a resposta efetiva , isto é em atos, que vamos dar nesse momento histórico. 
A questão é simples, com quem vão se alinhar? 
Com quem vão ser "sócios da descrição da realidade"? 
É uma pergunta profunda, porque podemos nos alinhar justamente com este sistema que criticamos e sabemos ser destruidor da Vida. 
E o pior é que a destruição continua agora e o que estamos fazendo por isso? 
Checamos se nossos deputados e senadores no Congresso tem ajudado na questão da demarcação das Terra indígenas? 
Algo tão mínimo, mas vital, é como separar lixo orgânico de inorgânico em sua casa, cada postura do dia a dia é um ato significativo nessa rebelião. 
Essa é a sutileza e a força da ação proposta pela Tribo do Arco Íris. 
Não precisamos brigar com os que são pagos para defender o SISTEMA, entrar em luta armada é tolice, só vamos dar capital para os "senhores do progresso" que tem na fábrica de armas um de seus grandes negócios lucrativos. 
Cada míssil lançado é comemorado na industria de armas, vai ser reposto, devem ter ouvido falar dos preços desses mísseis. 
Todo esse capital destinado a produção de armas para destruir pessoas, cada vez mais fortes, mais perigosas a todos nós. 
Todo esse capital destinado a industria de armas é sangrado de países como o Brasil, nos eternos juros das dívidas que continua fazendo, vejam quantos empréstimos a FMI e tal, 
Estamos preparados para uma contaminação global com vírus ou bactérias mutadas , algo que pode acontecer, já aconteceu vazamento de material biológico mutado para fins militares matando dezenas de civis? 
E o mundo podia estar investindo isso na pesquisa cientifica, no sanar das necessidades fundamentais , mas está investindo em guerra. 
Frente a total falência do sistema político, que em todos os países revela suas mazelas, corrupção e malversação do dinheiro público , frente a falência da sociedade como um todo para administrar suas crises sociais, políticas, econômicas e ecológicas , falência constatável pelo simples observar da situação do mundo nos últimos 5 anos. 
Observe sua situação de vida nestes últimos 5 anos? 
Até quando o Brasil vai estar exposto ao jogo internacional comandado pelo G7? 
As crises geradas na Ásia e outros mercados desestabilizaram o que era um plano razoável de equilibrio monetário interno, assim continuamos na tal crise, que torna o dinheiro o foco das pessoas e a vida é entregue, cada gota de suor, para alguns lágrimas e sangue, tudo para ter dinheiro, para poder sobreviver. 
De que forma resolvemos essa questão? 
Como vivemos? 
É uma questão fundamental, pois a forma que vivemos declara muito sobre como estamos respondendo ao desafio da vida dentro deste contexto social. 
Um contexto que é francamente desfavorável a vida, só permitindo a sobrevivência, para que as pessoas sirvam de extensões biológicas das máquinas e sistemas organizacionais que dominam objetivamente o mundo. 
Os povos nativos tem outra abordagem da realiadade. 
As lendas e tradições dos povos nativos tem uma característica interessante, são histórias muito ancestrais, que caminharam com alto grau de fidelidade até nossos tempos. 
Parte dessas histórias só podem mesmo ser compreendidas se nos tornarmos "sócios" da visão de mundo que têm. 
Vamos falar sobre esta proposta de sociedade nos próximos mails.