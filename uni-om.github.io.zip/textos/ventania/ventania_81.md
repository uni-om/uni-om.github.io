---
layout: texto
tags: []
texto_number: 81
category: ventania
---
Date:Dom Out 28, 2001 10:34 pm
Texto:81
Assunto: Um novo ciclo
Mensagem:1363

Aloha lista; 
Sugeriria que antes da leitura do mail fizessem o rito do cocar, para quem não conhece o rito do cocar é uma antiga proposta desta lista que cada vez que fossemos ler os mails da lista, ou escrever para a lista "sentíssemos" em nós um vasto cocar de penas de energia, das aves que sentimos afinidade. 
Vocês tem feito esse rito para ler os mails? 
A triste sina do ser humano é esquecer e ser mais ou menos, desde os relacionamentos até os vários setores da vida, dá uma atenção maior na fase que está empolgado, depois vai ' empurrando com a barriga" . 
O xamanismo não pode ser uma proposta "mais ou menos" , é uma realidade viva de harmonia conosco mesmo e com condições da realidade completamente distintas das que nos descreveram. 
Isto faz parte da proposta desta lista, que nunca foi apenas uma lista de debates ou troca de assuntos, mas um experimento virtual com várias facetas. 
A lista atingiu uma fase de maturidade interessante , temos pessoas aqui com várias abordagens do xamanismo, todas convivendo em harmonia, conseguimos manter uma harmonia ímpar nesta lista, apesar dos elementos que vivem para a desordem terem tentado se infiltrar a energia da própria egrégora da lista os(as) desorientou. 
E isto aconteceu porque a "egrégora " da lista se mostrou harmônica. 
Por isso sou tão chato : sem spams, sem propagandas e vou mais longe agora, sem " divulgação de eventos xamânicos" , sem " off tópics de qualquer tipo". 
Este mail marca uma nova fase desta lista. 
Estamos nos focando em duas frentes. 
Com os textos excelentes da Zoe, Meinkaká, Lobo do Cerrado entre outros que se considerem citados, temos vários aspectos do estudo e valorização da cultura nativa postos em estudo, os textos do Fernando, Márcio e Morgana tem trazido uma enriquecedora abordagem do xamanismo Tolteca. 
Os comentários e questionamentos de tantos(as) outros da lista estão mantendo essa qualidade de nossas mensagens, que pode ter períodos de menor, ou mesmo nenhum envio de mensagem, só as pessoas ansiosas precisam ter sempre algo o que falar , o Silêncio é um caminho ainda mais amplo à SAbedoria muitas vezes. 
Existe um movimento mundial acontecendo, um movimento chamado de " Ação da Tribo do Arco íris". 
Esse movimento é muito complexo, ele envolve ação em vários níveis, estamos envolvidos com a proposta de gerar uma "massa crítica" que ajude a humanidade a se afastar desse estado sonambúlico e robótico no qual se encontra, se afastar dessa rota de auto destruição evidente que está sendo trilhada , condenando a todos nós. 
Irmandades ancestrais, nesta e noutras realidades estão nos auxiliando. 
Não é nenhum messianismo, nem " alguém virá nos salvar" é algo complexo, cheio de nuances que temos de abordar com muita propriedade para podermos mesmo entender e quiçá participar de forma efetiva. 
Dentro das complexas teias de inter-relações que marcam a vida é tanto do interesse deles(as) como nosso que este estado de coisas que aí está mude. 
Houve uma primeira "chamada" para esta ação em todo o mundo nos anos 60. 
Depois uma segunda nos anos 80, entrei aí no processo. 
Nestes últimos anos ,algumas pessoas foram sondadas e contactadas , certos conhecimentos e práticas foram transmitidas, se tiverem paciência e "A essência" for mais forte do que "o que fizeram delas" quando 2012 chegar terão seu papel. 
O xamanismo sabe que o ser humano deve ser emgamelado, enganado mesmo, a mente de predador é contrária a qualquer ação dessa natureza, assim creio que muitas poucas pessoas podem mesmo, nesta altura se lembrar ou podem dizer que entenderam sequer 0,1 % do que lhes foi realmente passado, de acordo com a natureza de cada pessoa uma fantasia foi criada para distrair a mente predadora enquando a informação vital era apresentada, agora a informaçao está lá e levam-se anos para resgatar esse tipo de informes. 
Os contatos individuais acabaram, agora estou focando o trabalho via lista para certas práticas relacioanadas a este complexo tema, que pode até mesmo significar se vamos continuar caminhando para a completa extinção como espécie ou vamos aceitar a alternativa dos povos nativos. 
Passarei as próximas semanas falando sobre esse tema na lista , algo que na postura sempre algo jocoza e não sectária dos xamãs se convencionou chamar de "o sonho de mil gatos(as)".