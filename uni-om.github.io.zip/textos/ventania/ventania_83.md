---
layout: texto
tags: [mapa, prática]
texto_number: 83
category: ventania
---
Date:Sáb Nov 10, 2001 10:32 am
Texto:83
Assunto: Outras realidades
Mensagem:1399

ALoha lista; 
Tempos atrás o Fernando enviou um mail dando um toque prá que fosse abordado o tema da nação arco íris, dos povos do arco íris e da volta do maias, da mudança de consciênca coletiva que se fazem necessárias hoje para esta "curvatura" do espaço tempo " a fim de entrarmos nesta sintonia completamente diferente da atual. 
SEm dúvida é fundamental essa mudança da consciência coletiva, podemos sem nenhuma dúvida dizer que a sobrevivência da humanidade e do próprio planeta TErra como um todo dependem desta mudança. 
O tema é complexo , estes temas assim não escrevo na forma : " sento agora diante do computador e vou escrever isso". 
Uso outro método, deixo que o tema se escreva através de mim, vou reunindo dados, insights, informes que caem na minha mão, pessoas que citam coisas, sinais e de repente sinto que é o momento, aí coloco meu cocar , sento ao computador e o tema flui. 
Uma das reclamações que as vezes ouço é que meus textos são muito longos. 
Paciência, não pretendo mudar isso, não por arrogância, mas porque quando escrevo mergulho no "espirito" de escrever, não me vejo como um articulista ou jornalista escrevendo um texto para ser lido por tal público alvo, mas me sinto um canal do espírito que deseja ser claro e preciso no que está expondo. 
Nossa civilização foi acostumada a preguiça e a superficialidade, não acredito nesses valores, acredito na disciplina e no trabalho, assim , por coerência, não vou escrever algo com menos dados só para ser lido, vou escrever o que sinto , até esgotar o tema. 
Escrevo para o "Intento" , creio realmente que nossos atos devem ser atos de abandono e presença para o Intento, nossa testemunha oculta , o mais é detalhe. 
PAra o xamanismo nós fomos trancafiados dentro de uma estrutura cognitiva bastante limitada, que chamamos de realidade. 
ESta é a sacada genial do xamanismo tolteca, estamos presos em celas perceptivas, a liberdade que precisamos é a liberdade perceptiva. 
ESta realidade nos limita e nos permite participar de uma esfera apenas da ETernidade, quando existem infinitas. 
A migração para esta condição limitada teve suas razões e embora se acredite que no decorrer dos tempos isto acabou nos colocando a mercê de forças predadoras, no começo, quando as primeiras nações migraram para este estado de ser , o fizeram mesmo para se proteger. 
A Eternidade é muito ampla e , nós seres novos , muito vulneráveis. 
Os seres encantados são um tema recorrente em várias mitologias nativas, seres que vivem ao lado deste mundo e podem atrair os humanos para irem viver com eles e após certo tempo, os que vão não conseguem mais voltar . 
Sob este tema a Zoey tá com um texto excelente na sua coluna na pagina  . 
Vale a pena ler o texto para entender essa " vulnerabilidade" que tínhamos no passado, justamente pela amplitude e facilidade de mover nossos pontos de aglutinação. 
Ela aborda o tema ali pelo lado da sensualidade, mas eu pegaria o texto e faria outra leitura, a participação desses seres inorgÂnicos no nosso mundo, seu poder de atrair tribos inteiras para ir viver com eles. 
CAda povo ancestral tem essas histórias, do povo encantado, povo das fadas, povo das montanhas e outros termos, seres encantadores que atraiam pessoas ou grupos e que ofereciam estadia e alimento e recompensas. 
Interessante que em todas essas narrativas há a ênfase que se for partilhado o alimento fica quem ali vai prisioneiro. 
Do povo das fadas na Europa ao conto que a Zoey transcreve no seu artigo , vamos encontrar esta mesma referência, alimentar-se no outro mundo pode nos prender lá, acrescente-se ainda o papel da relaçao sexual, que também é considerada fator "de ënvolvimento" com estes seres encantados. 
Vivemos numa camada da vasta cebola da Eternidade, somos seres novos e imaturos ainda, existem seres muito mais ancestrais e espertos que nós, assim o xamanismo é um caminho de muito zelo e cuidado pra que não caíamos nas armadilhas várias que nele existem. 
No xamanismo não temos a ilusao que "somos protegidos" , "seres superiores vão nos salvar" , a relação é outra, portanto ninguém espere que o tema da volta dos Maias e similares tenham conotações messiânicas, "eles" vem para nos salvar. 
É outra abordagem, co participativa, só haverá a presença dessas linhagens neste nosso mundo se fizermos a nossa parte . 
Xamanismo é um caminho selvagem e só quem já viveu na condição de selva sabe que ali o que conta é de fato "o poder pessoal" a "energia acumulada" de cada um. 
Não adianta rezar, implorar, a mata, a selva se revela com seu pleno poder e depende de suas habildades e poder pessoal ali sobreviver. 
O mesmo vale para entrar em outras realidades. 
Estamos presos culturalmente por muito tempo neste modelo de realidade, assim não é em um curso de xamanismo em 7 lições sem mestre que vamos nos destrelar de todo o lixo que nos impuseram, da prisão perceptiva que nos restringiram. 
E aí , tem outro ponto, este mundo é um limite, mas é também uma proteção. 
EStamos "treinados" a lidar com ele, ampliar a percepção deve ser algo realizado de forma muito tranquila e sóbria, ou nos veremos inundados por dados cognitivos além de nossa possibilidade de metabolizá-los.