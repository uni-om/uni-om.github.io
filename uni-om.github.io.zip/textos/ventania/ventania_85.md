---
layout: texto
tags: [pérola, mapa, prática]
texto_number: 85
category: ventania
---
Date:Dom Nov 11, 2001 10:01 am
Texto:85
Assunto: Duas perguntas. - uma resposta
Mensagem:1405

Aloha lista; 
Vou direto ao segundo tema: 
"Os (as) guerreiros só aceitam cuidados e companhia dos que estã mortos como eles." 
"Desde aquele dia, aceitei apenas a companhia ou 
os cuidados de PESSOAS ou guerreiros que estão mortos como eu." 
Há várias vertentes de xamanismo, nenhuma é superior ou inferior, cada uma é para um tipo de pessoa. 
Da mesma forma que na Arte temos pintura, música, escultura, cênicas e seria ridículo dizer que uma manifestação artística é "mais melhor" que a outra, no Xamanismo temos caminhos diversos e cada um se adequa a tipos de pessoas diferentes. 
O Xamanismo Tolteca Guerreiro é extremamente exigente. 
Ele foi gerado em condições de máxima pressão, por isso tem propostas muito radicais, exigentes e é uma loucura querer "seguir" o caminho tolteca se não houve um claro sinal de chamado, mais loucura ainda é querer converter alguém a este caminho. 
Podemos usar as pistas do saber xamânico tolteca, mas daí a trilhar o caminho do (a) guerreiro(a) tolteca vai uma grande distância. 
Há um rigor intenso mesmo, por isso a prática das propostas dessa linha de xamanismo tem de ser abordadas com muito cuidado. 
Não há mestres no caminho tolteca, no sentido de pessoas que ficam procurando outras para ensinar, como no nosso conceito moderno de mestre e aprendizado. 
A proposta num caminho Tolteca é permanência do conhecimento, assim um grupo formal após estar pronto encontra pessoas com as mesmas "características" energéticas para dar sequência a mesma "forma tradicional" que viviam. 
É uma velha regra iniciática, antes de passar para outro momento da existência , como indo a outro degrau, se colocam pessoas no degrau onde se estava, para que o equilibrio cósmico seja mantido. 
O xamanismo guerreiro tolteca nos presenteou com práticas como a Tensigridade, que redistribui e equilibra a energia em nosso corpo, nos presenteou com a recapitulação que nos livra do peso de nossas vivências , do "eu" , 'eu" , 'eu" que costumamos ser. 
Mas estes "presentes" não fazem por si só o todo da prática do Xamanismo Tolteca Guerreiro. 
A prática profunda do Xamanismo Tolteca guerreiro tem implicaçòes devastadoras. 
Uma delas é que a entrada para o "mundo" do Xamanismo Tolteca Guerreiro se dá com a morte, uma morte real, efetiva, que nos coloca noutra condição da realidade. 
Existem relatos em muitos outros caminhos dessa mesma forma de transição, o (a) aprendiz 'morre" para o mundo antigo, para tudo que era e se torna uma nova pessoa. 
No Egito por exemplo ao dedicar-se aos mistérios maiores o (a) aprendiz sabia que nao tinha mais volta, ou ele ia completar o ciclo ou nunca mais saíria do templo, ali ficando como escravo. 
No caminho Tolteca ocorre o mesmo, há uma transição radical chamada "morte" que resulta na transformação completa do aprendiz, deixando o mundo antigo e entrando num mundo novo . 
TEmos uma "continuidade" que é nossa vida comum, pessoas, eventos, tudo que conosco existe desde o nascimento, a MORTE do xamã rompe com todos esses padrões. 
Índo mais fundo é importante entender que a pessoa social que somos nasceu para ter um papel no contexto da vida, quando vemos a 'carta astral" por exemplo, ali mostra como tem pontos da vida que já estão determinados, nascemos para desempenhar um papel na vasta cadeia cósmica de eventos na qual estamos inseridos. 
Morrer é romper com tudo isso e começar do 0. 
Tal morte não é "simbólica" é real, efetiva, acaba uma vida de tal forma que , mesmo que leve um tempo, o (a) aprendiz acaba percebendo que não tem mais como manter a antiga continuidade. 
Estar morto é não ter mais o mundo como ilusão, é não estar preso aos valores do mundo, é efetivamente saber-se no mundo mas sem ser do mundo. 
Não é um estado que pode ser fabricado e ficar obsedado com este estado é uma das piores coisas que se pode fazer, como tudo no caminho do(A) Guerreiro (a) tem que ser natural, fluído e sem fixações . 
É um resultado, resultado do caminho. 
Mas quem nem está vivo pode morrer? 
Por isso antes de entrar neste tema me parece mais sensato um estudo bem profundo do livro "Viagem a Ixtlan" , pois ali existe um caminho para " estar vivo" e só quem está vivo pode morrer. 
O Caminho tolteca não se presta a abordagens intelectuais, elas falseiam o caminho, para o Caminho guerreiro Tolteca só a prática tem valor. 
O sentido da frase neste contexto do Poder do Silêncio é que um (a) guerreiro(a) só pode estar com os que estão mortos como ele (a) . é impossível e perigoso estar com outros. 
Perigoso para ele (a) e perigoso para estas pessoas.