---
layout: texto
tags: [mapa, prática]
texto_number: 88
category: ventania
---
Date:Seg Dez 3, 2001 10:04 pm
Texto:88
Assunto: Agir por agir
Mensagem:1470

Aloha lista 
O Caminho do Xamanismo Tolteca é eminentemente prático, toda aproposta do Xamanismo Tolteca vem da observação direta dos(as) Xamãs da nossa real condição de vida . 
Uma das melhores definiçòes da "vida comum" que a maior parte de nós vive vem do velho nagual . Disse ele a seu aprendiz : "Os seres humanos podem ser navegadores no vasto mar escuro da consciência, mas esta viagem foi interrompida e estamos num rodamoinho, indo ao fundo e crendo que isto é a viagem". 
Meditem atentamente nesta imagem , vale a pena, ela é forte, ela nos coloca numa perspectiva muito clara do que é a nossa "vida normal" e nos dá uma idéia da urgência que precisamos ter em nos transformar, em sair desses "trilhos"da vida normal e voltar a nossa condição de "navegadores (as) da ETernidade. 
Mas este processo de transformação não é fácil, ele exige disciplina, vontade e energia e estes atributos foram muito sabotados em nós. 
Disciplina foi confundida com pressão, com autoritarismo externo nos mandando fazer algo e assim criamos reações das mais diversas a sermos disciplinados e existem várias pseudo liberdades por aí que nada mais são que a fuga de um agir disciplinado. 
Vontade é algo que precisamos desenvolver, para os (as) xamãs Vontade é como um músculo, precisa ser treinada e desenvolvida, não temos VOntade , temos que desenvolve-la, vontade faz parte das coisas que fingimos ter, como liberdade e individualidade e acabamos perdendo a chance de trabalhar para nela chegar. 
Energia é outro problema, gastamos energia demais com preocupações egóicas: 
"oh será que ele (a) gosta de mim" . " O que pensam de mim? " e por aí vaí, com preocupações tolas gastamos uma energia imensa para corresponder a imagens que queremos que as pessoas tenham, fora os outros gastos de energia como rompantes emocionais, raiva, ira, emoções negativas, repetir atitudes que não levam a nada e por aí vai. 
A primeira proposta do Xamanismo Tolteca é que economizemos energia, nada pode ser realizado no Caminho sem energia. 
Podemos ficar cheios de teoria, repetir de cor e salteado trechos de livros, especialmente os livros do novo nagual, mas a prática que é o que importa só pode acontecer quando temos energia. 
O primeiro passo é parar de gastar energia, depois é recanalizar esta energia para que ela se expresse de forma diferente e então teremos condição de ampliar a energia. 
É muito importante essa sequência, se eu começo a ampliar a energia antes de recanaliza-la vou ter apenas mais energia para gastar com indiossincrasias e bobagens existencias as quais estamos acostumados. 
Por isso a recapitulação ajuda tanto, ela vai nos mostrando como passamos a vida gastando energias bobamente. 
É extremamente importante para quem busca trilhar o caminho do (a) guerreiro(a) Tolteca que comece pelo "agir sem esperar recompensas", agir sem acreditar, agir só pelo agir. 
ISto é muito complexo, nós fomos educados para agir por alguma recompensa. 
É uma mudança radical quando agimos só pelo prazer de agir, isto muda nosso foco de energia, muda toda a disposição da energia em nós. 
Aí vamos ter que prestar atenção em nossas vidas, trabalhar pelo prazer de trabalhar, estudar pelo prazer de estudar, estar nos lugares que estamos pelo prazer de estar, relacionarmos com as pessoas que relacionamos pelo prazer de tal relaçào, enfim, um caminho com coração é isso, não ficarmos fazendo as coisas a espera de alguma recompensa. 
Não é simples gerar este estilo de vida, mas garanto que é possível. 
As vezes podem levar anos ajustando nosso Intento e nossas situações de vida para chegar nisso, mas vale a pena, os resultados nos colocam em outra linha de vida, nos tiram da sobrevivência e nos colocam na "VIDA ' de fato. 
Ë importante notar que os (as) guerreiros (as) tem um propósito ulterior para seus atos, mas este propósito não se enquadra numa "recompensa" , não tem nada a ver com ganho pessoal. Uma pessoa comum age apenas se há oportunidade de ganho, de lucro, mas um (a) guerreiro(a) age pelo Espírito e isto muda tudo. 
É bem forte este estado, a medida que progredimos no Caminho Tolteca vamos notando o nada que somos e como a tal LIBERDADE TOTAL é algo muito, muito díficil, então embora continuemos intentando a cada segundo esta meta , perdemos toda e qualquer expectativa de alcança-la. 
Este estado é uma resultante de energia acumulada, do agir sem esperar benefícios, não pode ser forjado, mas quando surge em nós nos dá um "amor calado pela vida" algo que é o êxtase a cada instante, quando os mais ínfimos detalhes da vida ganham a proporção de um presente enorme. 
Este trabalho tá diretamente ligado ao DESAPEGO. 
Desapego pelo mundo, desapego total, já morremos, já não temos nada a perder, entao nada há que se apegar, estamos livres, estamos soltos, isto dá uma força tremenda que nos permite entao começar a sair do rodamoinho que nos levava a destruiçào, nos leva a chance de retornar a condição de navegantes da Eternidade. 
Vamos nos transformando a medida que intentamos estes estados de ser e o mais importante é nos atrevermos, mesmo sem acreditar que seja possível , a mudar, a nos transformarmos. 
Agir pelo prazer de agir, agir sem esperar recompensas, colocar toda nossa energia no ato em si, sem ficarmos com expectativas, esse é o primeiro passo para o poder, para mexermos com nossa energia pessoal. 
Este estado de agir plenamente, como se cada ato fosse o último é a implacabilidade, que precisa permear todos nossos atos, de lavar um copo, abrir uma janela até estar em outros mundos, não existem atos maiores ou menores, menos ou mais importantes, quando a Morte está ao nosso lado e pode nos tocar a qualquer instante.