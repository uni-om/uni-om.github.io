---
layout: texto
tags: [mapa, prática]
texto_number: 89
category: ventania
---
Date:Qua Dez 5, 2001 2:59 pm
Texto:89
Assunto: Práticas de Sintonia com o núcleo galáctico
Mensagem:1482

ALoha 
Os ritos que seguem são práticas recomendadas para estes dias até o Solstício de Verão. 
Os trabalhos da Tribo do Arco Íris tem se intensificado nestes últimos meses e a proposta é que este rito seja realizado pelo maior número de pessoas possível, dentro da proposta de cura da Terra. 
Um alerta , a ação da TRibo do Arco Íris tem duas linhas, uma a mágica , outra a ação incisiva no cotidiano : 
O importante no trabalho individual é observarmos de que formas estamos "não concordando" com o sistema, evitando entrar nas neuroses coletivas que ele promove via midia, nos modismos, isto já ajuda a evitarmos estar presos na consciência coletiva dessa sociedade que é nitidamente desequilibrada. 
Em segundo lugar nossa atitude consciente como "consumidores conscientes" evitando adquirir produtos que em qualquer fase , desde a coleta de matéria prima até sua venda, agridam a natureza, isto não é simples, exige pesquisa e nem sempre temos esses produtos a mão, mas o máximo que fizermos para agir neste sentido e orientar outras pessoas nesta mesma linha já ajuda muito. 
Depois vem a questão do uso racional dos recursos naturais, como água e energia elétrica 'que ajudam muito. 
Outra ação importante é nossa pressão e acompanhamento frente aos deputados, senadores e poder executivo no sentido de leis e ações que protejam as populações nativas, a biodiversidade, que continua sendo abusivamente roubada deste país e a adoção de políticas de desenvolvimento sustentável. 
O apoio a toda ação de reciclagem, começando em casa, com divisão do lixo e entrega de pets, latas de aluminio, papelão e vidro em postos de arrecadação que existem em quase todas cidades. 
Se na sua cidade nada é feito neste sentido , bom campo para começar a trabalhar, é de ações concretas que precisamos agora, não de teoria. 
O trabalho mágico e ritualistico é a outra face da moeda destas açoes concretas, apenas um deles ser feito é meio trabalho, o estado que o planeta se encontra precisa das duas linhas de ação. 
Primeira prática : 
Os Maias estavam conscientes que o centro da Galáxia emite um tipo de energia muito importante, uma energia que regula todo o "organismo galáctico". 
Essa energia é reverberada por cada estrela, assim esta prática está ligada a este aspecto do Sol, reverberador da energia do centro galáctico. 
!Todos os dias ao nascer do Sol, ao meio e ao por do sol parar com o que estiver fazendo e se sintonizar alguns instantes com o Sol, sentindo que o mesmo é um portal de energia, que ele te coloca em conexão com as energias de Hunab Ku, o centro galático. 
Inspire e expire várias vezes sentindo a energia do Sol, entrando em seu corpo e ativando todas as células, colocando seu corpo em sintonia com a energia do Sol e através dele com a energia do centro galáctico. 
É importante sentir a luz solar como filamentos que unem você ao Sol e sentir também que o Sol está te colocando em contato com o centro galáctico, ter essa INTENÇÃO vai ajustar canais sutis que temos, mas estão adormecidos. 
Pela manhã o foco é na energia do Sol nascente, na força que nasce, que surge, que estímula, captar a energia pela respiração, depois sentir a energia que vem dos astros entrando pelo alto da cabeça e junto com a energia do Sol, entram na Terra , como se você fosse uma agulha de acupuntura, depois a energia que vem do núcleo da Terra, entra pelos seus pés, passa por você e saí pelo alto da cabeça e pelos dedos das mãos, que devem estar erguidas como antenas e vai para o Sol, através dele para o Centro galáctico, reestabelecendo assim essa conexão. 
Meio dia : Cuidado, no horário de verão meio dia não é o meio dia do relógio, estamos falando do Meio dia mesmo, sol a pino, basta perceber que neste momento você vai estar exatamente em cima da sua sombra. 
O mesmo procedimento da manhã, apenas mudando que neste momento é o Sol no máximo de seu poder que é sentido, os atributos do Sol em sua energia mais intensa, captar a energia solar fundir com a energia dos planetas e então "acupunturar" a Terra com estas energias, sentir tais energias entrando na Terra como um feixe concentrado e indo até o núcleo da Terra. 
Então sai uma energia da própria Terra em resposta, entra pela sola dos pés sobe pelas pernas, ativa os chacras e subindo sai pelo alto da cabeça e dos dedos das mãos, indo ao Sol, conectando a Terra ao Sol e ao mesmo tempo, através do Sol ao núcleo galáctico. 
Ao por do Sol : Repetir a mesma prática, apenas o aspecto do Sol muda aqui, é o Sol ancião, a força da Sabedoria do Sol. 
Quando o último raio do Sol estiver sumindo sinta que ele leva toda a energia desequilibrada que estiver em você , mas também a sua volta, no lugar onde você está. 
ESta é uma primeira prática de uma sequência destinada a ampliar a relação da Terra com o Sol e com o núcleo galáctico. 
Os antigos tinham esse culto diário de sintonia com o Sol e através dele com o núcleo galáctico, numa interpretação apressada os pesquisadores modernos chamam essas práticas de "adoração ao Sol " mas não é isso que realmente acontecia, uma adoração e sim esta sintonia, esta prática de harmonizar a Terra ao Sol e ao Centro galáctico, através de nós, sensíveis condutores dessa energia.