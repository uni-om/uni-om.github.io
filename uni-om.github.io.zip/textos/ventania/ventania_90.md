---
layout: texto
tags: []
texto_number: 90
category: ventania
---
Date:Qua Dez 5, 2001 3:29 pm
Texto:90
Assunto: Borboletas
Mensagem:1483

Olá lista;

Concordo com a Zoe que a história do pó da borboleta cegar vai pelo caminho que ela citou, pois esses dias mesmo vi uma mãe ameaçando a criança, "para de brincar com essa borboleta que ela solta um pó que pode te deixar cego" . 
A borboleta tem um simbolismo forte na nossa cultura, psiquê, borboleta, com suas fases passando do ovo a lagarta, depois o recolhimento ao casulo e então o surgir da borboleta, é um simbolismo muito interessante para nosso próprio processo existencial. 
No caminho Tolteca são as mariposas que carregam nas asas o pó do conhecimento. 
Creio que a beleza das borboletas também impressionam muito. 
Os insetos em geral são fantásticos , inquietantes em sua complexidade organizacional. 
Existe um vídeo da série de Tensigridade que trabalha com movimentos destinados a enviar uma fibra e nos podermos perceber o mundo não como humanos , mas como os insetos o fazem, uma das sequências é a da borboleta. 
Borboletas, formigas, abelhas, cada inseto tem sua maravilha, toda a vida é maravilhosa, creio que se identificar com um ou com outro é uma questão de predileção pessoal.