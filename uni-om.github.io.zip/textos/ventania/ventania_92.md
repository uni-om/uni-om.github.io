---
layout: texto
tags: [pérola, mapa]
texto_number: 92
category: ventania
---
Date:Sex Dez 14, 2001 12:00 am
Texto:92
Assunto: Re: [ventania] Qual a origem do mal?
Mensagem:1501

ALoha lista 
ALoha Guardião do Portal 
Vou responder dentro da linha de xamanismo que estudo, como toda resposta para assuntos tão amplos é apenas um ponto de vista, uma abordagem. 
O Xamanismo tolteca considera que não há mal nem bem, isso é criação humana, há apenas energia impessoal, que em nosso condicionamento damos forma. 
Como diz o velho nagual, existe a estupidez humana e esta estupidez tem uma sinistra conexão com a morbidez o que gera muitas vezes, atitudes do ser humano que podem parecer MAL, mas são apenas atitudes de desequilibrio. 
PAra várias linhagens não há Mal, há "Avydya" ignorância, isso gera o que chamamos de MAl. 
Um Hitler , um Himmler podem parecer arautos do mal, mas se formos avaliar suas vidas, suas idéias, suas propostas, veremos pessoas confusas, com vidas pessoais em crise, presas na velha armadilha, dominar a tudo e a todos, acreditando que o fim justifica os meios. 
Essa idéia de "Deus criou" não existe no Xamanismo, o Xamanismo não trabalha com estas idéias de um Deus criando , temos outra abordagem, tudo que existe "emanou" , emanou de uma Fonte, que está hoje em tudo, assim não temos essa divisão das religiões : isto é divino e sagrado, isto é profano . 
Para nós tudo é sagrado, tudo é mágico, tudo é maravilhoso. 
O corpo não é inferior ao espirito, o espirito nao é superior ao corpo, sao duas faces da mesma moeda, todos os aspectos de um ser sao importantes, sem trabalhar profundamente o corpo e o corpo de energia juntos não atingimos a meta da liberdade, assim nao há superior, inferior, isto tudo é criação da mente humana. 
Deus é só um conceito do Tonal dos tempos, não podemos chamar o TAo de Deus, nem a FOnte que o xamanismo se refere de Deus, nem tão pouco comparar a Deusa do Paganismo com esse conceito de Deus que anda por aí, pois esse conceito de Deus tem uma historicidade, aliás péssima. 
Se um ET chegasse agora na Terra e fosse estudar a história conhecida humana ( conhecida porque há outras histórias uq enão sao contadas) com certeza definiria como o Mal , Deus e teria pena do Diabo, pois o diabo é sempre perseguido e caluniado, mas quantas guerras e atrocidades foram feitas em nome de Deus? 
Desde Hitler a Bush estes loucos militaristas que usam das armas para compensar suas impotências existênciais, sempre usam o nome de Deus e se consideram seus "agentes" . 
O Xamanismo está diretamente ligado a natureza e como o Budhismo nem se preocupa com o conceito de Deus, considera que primeiro temos de trabalhar nós mesmos, resolver nossas questões existenciais pessoais, para depois irmos questionar sobre outras coisas mais amplas. 
Temos um elo de conexão com a Eternidade, esse elo está enferrujado, precisamos trabalhar arduamente para limpar esse elo e só então vamos poder começar a conceber o que é essa Fonte da Qual emanamos e a qual vamos voltar ao final da vida. 
Assim, essa pergunta carece de sentido no xamanismo, pois para o Xamanismo este Deus criador é o deus do conquistador, que foi imposto por armas e ameaça, por tortura e morte, assim é de triste figura, esse deus fora do mundo, que culpa, que castiga, que julga, que gera medo. 
Para o xamanismo esse deus existe na cabeça das pessoas porque quando crianças sempre temos adultos por perto nos protegendo, basta gritar e vem alguém ajudar, depois, crescemos e notamos que nossos pais não são tão onipotentes assim, a tremenda carência que isso gera é superada por poucos, poucas pessoas amadurecem e assumem nossa solidao e efemeridade frente a Eternidade, a maioria cai em sucedâneos, como Deus. 
E as religiões, que precisam de gente para manter seus dirigentes com poder, precisam do jogo " se não está comigo, está contra mim" e se "comigo " é deus, então 'contramigo" é o demo, o "mal" o "bicho papão" . 
O xamanismo diz, na Eternidade existe apenas energia impessoal, nossos medos, nossos condicionamentos é que transformam tudo isso em demônios, monstros, quando perdemos a forma humana, quando vamos além destes condicionamentos, percebemos fatos, não fantasias. 
Os Xamãs Toltecas alertam que nossa crença neste deus das religiòes é uma das coisas mais inuteis que existem, dedicamos porçoes imensas de energia a algo que não existe em si, é só uma convenção humana, e estar atento é conseguir parar de dizer frases do tipo " graças a Deus" , "meu deus" e coisas do gênero, pois tais dizeres implicam que nossa mente ainda está presa no condicionamento desse deus das religiões que é algo que sabota nossa totalidade, pois todos os conceitos desse deus foram gerados para levar o ser humano a ser algo menor do que ele é. 
Por isso, "mal" é apenas mais uma interpretação da mente humana, precisamos é ir além desses limites e entender que existe energia impessoal~.