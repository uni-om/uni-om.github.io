---
layout: texto
tags: [pérola, prática]
texto_number: 94
category: ventania
---
Date:Dom Dez 23, 2001 9:28 pm
Texto:94
Assunto: Re: [ventania] Sintaxe
Mensagem:1550

Aloha lista 
Aloha Jorge Esperanza 
Algumas vezes escrevo para a lista num papel que não gosto muito, mas necessário, de moderador, pedindo para evitar tal ou qual texto que não tem a ver com o escopo da lista. 
É uma satisfação escrever pedindo que continue com estes excelentes textos que tem nos brindado, ao menos para mim eles tem chegado em momentos excelentes e motivado profundos insights, o texto anterior que enviastes é impregnado do intento do Caminho, lê-lo foi sentir de forma vibrante este "guarda chuva do intento" sobre nós, foi impulsionar ainda mais este experimento virtual que é esta lista. 
As reflexões oportunas sobre estarmos num novo ciclo, um ciclo que a coragem e o intento impecável de Charles Spider teceu para nós, esse homem corajoso que ao invés de partir e fechar a porta deixou uma porta aberta pelo afeto abstrato e o mistério do Intento pode tocar nossas percepções . 
A reflexão mais que oportuna que temos de parar de "messianismos" de esperar por "naguais" , por "líderes" e "mestres" e ousar intentar nosso elo límpido com o INTENTO para que possamos de fato ir ao abstrato, compreender os cernes abstratos que a obra do novo nagual nos legou. 
Os temas correlatos ao caminho Tolteca são sempre bem vindos, inclusive gostaria de aproveitar para solicitar as pessoas da lista que estão só de leitores que participassem mais, não vejo função em ficar só lendo, aliás é mesmo uma falha numa proposta do Caminho ficar só absorvendo sem colaborar. 
Por exemplo, quem está na lista e não participa diretamente podia pesquisar sobre "fenomenologia" , é um tema muito importnte, outro tema importante é "semiótica" e as obras gerais de C.S. Pierce, ele explora profundamente a questão da linguagem e sabemos que somos criaturas de sintaxe, precisamos estudar isso também. 
O Nagual Mariano Aureliano alertava que só uma mente bem treinada pode servir de escudo aos ataques da ETERNIDADE, vamos transformar esta lista neste espaço de treino, que tenhamos subsídios aqui, portanto gostaria de propor esse intento, que não houvessem mais na lista pessoas que só leem, que nunca participam, isso é um contra senso e , a meu ver, uma postura contraditória a proposta deste experimento virtual que é complexo e vai além de nossa compreensão. 
Todos tem algo para colaborar, prá mim é uma forma disfarçada de vaidade dizer que não tem nada . 
Nem dúvidas? 
Ou tem vergonha que riam de suas dúvidas? 
Logo tá localizada a vaidade. 
A lista tem dezenas de participantes e sempre as mesmas pessoas que escrevem, tem tantos sites sobre xamanismo por aí, porque não pesquisar e trazer temas, sempre com o bom senso ligado, para que sejam temas do escopo da lista. 
É momento de ampliarmos nosso sonho. 
É momento de nos prepararmos para ousar um sonho em conjunto , onde requisitamos essa herança que nos foi legada. 
E para isso precisamos de participantes, não de observadores(as). 
Se não conseguimos manter um intento inflexível nem de participar ativamente de forma efetiva, em uma lista, me parece muita ilusão crer que vamos a metas mais amplas como as propostas pelo caminho. 
Como bem colocava o velho nagual, é resolvendo os desafios desse mundo que nos tornamos aptos a enfrentar a ETernidade, não o contrário