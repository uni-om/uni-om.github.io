---
layout: texto
tags: []
texto_number: 95
category: ventania
---
Date:Dom Dez 23, 2001 10:13 pm
Texto:95
Assunto: Uma proposta e um desafio
Mensagem:1552

Aloha lista
Aloha Vi do Vento

Seu sonho foi prá mim um presságio de uma nova fase em nossa lista.
Já faz algum tempo que tenho sentido o intento de muitos da lista no sentido
de encontrarmos no sonhar, o intento de tecer um sonho conjunto para darmos
um passo a mais no desconhecido e instigante caminho que o nagual nos deixou
com seus atos impecáveis.

Como bem nos lembra o texto enviado pelo Jorge Esperanza temos agora o
desconhecido, o imponderável a nossa frente, não sabemos quais serão os
resultados da divulgação ampla destes cernes abstratos e das práticas
Toltecas em nosso tempo, não sabemos o que vai resultar a prática conjunta
dos passes mágicos, o que essa massa crítica continua , vai gerar.

A simbologia das roupas feitas de palha é muito interessante, porque também
oculta as "pessoas' deixando que as essências se comuniquem além das formas,
como nós fazemos aqui na lista, aqui não temos faces, não temos "aparência"
, nem tom de voz temos, somos idéias navegando pela TEIA, pela WEB, numa
analogia interessante de nossa condição de aprendizes e postulantes a
condição de guerreiros e guerreiras viajantes.

Como apenas algumas pessoas da lista se conhecem pessoalmente o contato no
sonhar tem alguns empecilhos.
Mas podíamos criar um teste e desafio.
As pessoas que estiverem afins de começar esse experimento de sonhar em
conjunto poderiam se alinhar em uma mesma vibração.
Como?

Podemos, ao encerrar todas nossas atividades, inclusive a recapitulação do
dia, intentar que estamos nos vestindo com esta roupa de palha, uma roupa de
palha que nos cobre inteiro e o cocar que usamos para ler os artigos da
lista.
O cocar já tem uma força intensa com a egrégora da lista.
Então nosso intento pode ser formulado nas seguintes palavras : "Esta noite
quero sonhar junto com outras pessoas da lista ventania que estão também
intentando a mesma proposta".

É uma experiência, não tenho a mínima idéia do que vai acontecer e isso é
maneiro.

O que acham da proposta?

Gostaria que quem topasse escrevesse para a lista dizendo.

Assim como a prática conjunta por centenas de pessoas dos passes ma'gicos é
um dado completamente novo na trilha , esta interação por NEt também é nova,
não sabemos o que pode acontecer, assim, vale a pena treinar e trabalhar os
desafios , pois como dizia o velho nagual : 'quem mistérios esperam por nós?
"