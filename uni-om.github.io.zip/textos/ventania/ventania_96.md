---
layout: texto
tags: [prática]
texto_number: 96
category: ventania
---
Date:Qua Dez 26, 2001 5:20 pm
Texto:96
Assunto: Sonho Conjunto - Considerações importantes
Mensagem:1581

ALoha lista
Aloha Outsider

Uma das maiores dificuldades para agir no mundo dos paradigmas Toltecas é ir
além de nossa mente racional, que é a mente do predador.
A mente analítica que planeja e depois fica esperando resultados concretos.
Sua proposta parece muito lógica e realista e é por isso que está fora dos
paradigmas do Sonhar, tal qual estamos jogando aqui.

Este experimento é para ser realizado dentro da ideologia dos feiticeiros,
portanto os procedimentos da mente racional não entram aqui.

Essa "CERTEZA" que tu colocas com letras maíusculas é uma busca da mente
racional, que está ligada a um tipo de concretude e de resultados.

Um experimento como este não funciona assim.

A proposta é nos alinharmos num Intento conjunto, Sonhar juntos, só isso,
limitar isso em regras, dia tal sim, dia tal não, tudo isso já seria limitar
a paradigmas que não estão no jogo que estamos pretendendo jogar, é a mente
concreta , a mente do predador, querendo tomar parte num jogo para o qual
não foi convidada.

Quando trabalhamos com a primeira atenção, com a limpeza da ilha do tonal é
um procedimento.
Por exemplo, existia uma lista que debatia temas e exercícios relacionados a
esse ajuste do Tonal, uma lista ligada a procedimentos do Quarto Caminho de
Gurdjieff, ali tínhamos uma postura inversa, tudo muito planejado, muito
exato, exigências claras.

Aqui , neste experimento, estamos jogando com outras regras, com o nagual,
com o abstrato, então somem as indicações racionais.

O lance do cocar e da roupa de palha vieram como auxiliares para estarmos
numa mesma sintonia, já que muitos de nós não nos conhecemos .
Se vamos ou não nos encontrar, se vai ou não acontecer não pode ser
determinado por dias fixos, horários fixos, por expectativas da mente
racional.
Vai acontecer se estamos sendo impecáveis em nossas vidas, vai acontecer se
tivermos energia, vai acontecer se nosso INTENTO for sincero e constante, se
toda noite intentarmos a proposta, o INTENTO firme , mas sem esperar
resultados, sem esperar respostas, que é o "agir pelo agir" tao necessário
, sobre o qual já falamos aqui.

Lancei o desafio, para nós e também para o Intento .
É tudo que podemos fazer.
Usando o poder da palavra expressei um intento sincero para a ETERNIDADE.
As pessoas que querem participar do desafio escrevem se alinhando com a
proposta, escrevem dando seu sim .
SAbem que precisam formular em voz alta este INTENTO, pois o ESPÍRITO não
ouve pensamentos, apenas palavras e atos.

Intentem individualmente e deixam acontecer.

O SONHAR é muito delicado, assim este INTENTO é algo prá ser focado só antes
de dormir, não pode se tornar uma obsessão, durante o dia devemos banir
estes pensamentos de nossa mente, pois na leitura da mente estaremos apenas
, na maior parte das vezes, falseando o experimento, que não é para a esfera
da primeira atenção.

Muito menos devemos encher essa lista com os "relatos" de cada sonho que
tivermos e que
''acharmos" que tem a ver com a experiência, pois isto seria deturpar o
processo além de outros problemas energéticos que geraria.

Uma das bases do ensinamento TOLTECA é ter uma linha de treinamento no corpo
de energia, ( segunda atenção) e outra no aqui e agora, o Sonhar faz parte
da segunda atenção, leva anos para termos a primeira atenção madura e livre
dos falsos condicionamentos que recebeu da educação formal, para podermos a
fundir com a segunda atenção .

Assim é tolice ficar com expectativas de lembrança do que "aconteceu no
sonhar" logo no começo e mesmo quando estas acontecerem devemos ser
tranquilos e sóbrios e evitar ficarmos 'fascinados" pela experiência.

Como nosso contato é por aqui, pela NET , a usei para lançar um apelo
energético, um desafio, um Intento de feiticeiro para as segundas atenções
de todos que estão nesta lista.

É com o corpo energético que a resposta deve ser dada e a resposta, como
tudo no corpo energético é "apenas" agir, funcionar, fazer acontecer, mesmo
que a primeira atenção de nada se lembre, como é o mais provável e , no
começo, até o mais desejável, visando um desenvolvimento harmônico e
progressivo.

Quem vai decidir como a situação vai acontecer, se vai acontecer, quando vai
acontecer, não somos nós, mas os sinais, os augurios virão, não importa se
hoje, amanhã, daqui um mês, nunca, o importante é que cada um tenha sua
proposta clara , tenha sua resposta presente.