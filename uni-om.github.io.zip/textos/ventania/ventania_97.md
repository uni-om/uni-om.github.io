---
layout: texto
tags: [prática]
texto_number: 97
category: ventania
---
Date:Qui Dez 27, 2001 2:44 pm
Texto:97
Assunto: Re: [ventania] Lembrar dos sonhos
Mensagem:1590

Aloha lista 
Aloha Ambrósio 
Ter ou não um caderno, anotar sonhos ou não, tudo isto é muito pessoal, no sonhar estamos sempre sózinhos, o importante é traçar o intento de ser um sonhador, no mais cada um vai achar seu caminho, de acordo com a sinceridade da busca e seu alinhamento com o Intento. 
Existe uma recomendação do velho nagual, quando estiver do lado de "lá" feche a porteira e seja plena ação, como devemos ser na segunda atenção, quando estivermos do lado de "cá" , novamente feche a porteira e seja pleno Tonal. 
Eu concordo com isso, antes de dormir é hora de recapitular o dia, parte por parte, recuperar a energia dissipada, então dizer firmemento boa noite pro dia, isto é, deixar de lado tudo que é desta realidade, desta atenção do tonal e intentar firmemente , com todas as células de nosso corpo que somos sonhadores, que nossos sonhos são lúcidos , ter "certeza " disso e neste estado,buscando estar em silêncio interior, adormecer. 
Ao acordar se lembramos de algo, ótimo, se não, não, o importante é que o dia não é o campo do sonhar, a menos que já estejamos no estágio do sonhar acordado, que ainda assim não é o SÖNHAR de quando estamos dormindo. 
Pelo que sei a primeira atenção e a segunda atenção são campos completos em si mesmo e devemos desenvolve-los independentemente, ESpreitando e Sonhando , até que muitos, muitos anos depois estaremos prontos para 'fundir" as duas estâncias da atenção que é algo muito sério e complexo. 
Como na primeira atenção estamos sob o poder da mente do predador temos de primeiro trabalhar para ter esta liberdade fundamental, com muita disciplina e propósitos claros e inflexíveis. 
Existem alguns Intentos fundamentais que precisamos expressar diariamente , sempre em voz alta, pois é um fato que o ESPIRITO não ouve pensamentos, só palavras e atos, é um paradigma dos Toltecas que vais encontrar em várias partes dos relatos do novo nagual. 
O fato que somos seres a caminho da morte e então " assumo a responsabilidade de viver cada instante como alguém que caminha para a morte" . 
"tudo está relacionado com o mistério do ponto de aglutinação e sua posição" 
"Sou um sonhador, cada célula de meu corpo sabe disso" . 
Dizer isso faz vibrar a energia que nos circunda e acena para o INTENTO para que reforce nosso poder pessoal no sentido proclamado. 
A mente racional só alimenta os predadores , que tornam os seres humanos confusos e beligerantes , incomodados com tudo que não corresponde a suas expectativas. 
O velho nagual dizia que no caminho Tolteca nada é tão exato e preciso como gostaríamos que fosse, que precisamos de imaginação e criatividade para atingir nossos objetivos, que são abstratos .