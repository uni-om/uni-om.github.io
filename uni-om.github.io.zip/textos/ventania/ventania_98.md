---
layout: texto
tags: []
texto_number: 98
category: ventania
---
Date:Sex Dez 28, 2001 11:48 pm
Texto:98
Assunto: Re: [ventania] Uma Proposta: Alternativas A Um Mundo Artificializado
Mensagem:1606

ALoha lista
Aloha Wagner

Excelente colocações, temos que reconhecer que a ação tem que acontecer na
esfera de nossas vidas práticas e toda colocação quanto ao tema "Ser TERRa"
como ser vivo só tem valor se corroborada pela nossa ação.

Isto ocorre em muitas frentes e sem dúvida a participação de cada um é
vital.

Nossas posturas em diversos momentos revelam muito qual nossa efetiva
ligação com o Ser Terra que nos alimenta e vivifica.

Existe um ditado numa certa ordem iniciática muito interessante :
" A esperança da colheita reside na semente" .

E é fato, o que adianta o Sol da primavera voltar se as sementes não
estiverem prontas para tal energia?

Creio que precisamos de mais atitudes neste campo, atitudes práticas mesmo.

Um campo muito bom de trabalho é junto a escolas, o efeito multiplicador de
crianças e adolescentes em idade escolar é tremendo, temos notado isso aqui
no Sul de Minas, onde estamos com um projeto de Eco Cidadania, com efeitos
muito interessantes, apesar dos problemas que enfrentamos com a
administração pública que não fazendo sua parte mínima, coleta seletiva,
muitas vezes frusta alguns segmentos, mas temos trabalhado para superar isso
.

Estamos ta'mbém começando um trabalho aqui envolvendo a mídia local e as
escolas sobre "consumidor consciente" que é uma postura importante, além de
saber lidar com os efeitos de um mundo artificializado podemos , na condição
de consumidores, já minimizar o problema no momento da compra, dando
preferencia por produtos que tenham sua existência, desde a fase de coleta
de matéria prima, até irem prá venda, pautada por normas do desenvolvimento
sustentável.

É um tema muito importante, atitudes sao sempre importantes.